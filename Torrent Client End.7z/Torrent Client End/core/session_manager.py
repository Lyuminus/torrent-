"""
SESSION MANAGER - Менеджер сессии libtorrent

Отвечает за инициализацию, конфигурацию и управление основной сессией libtorrent.
Обеспечивает сетевые соединения, обработку алертов и базовую функциональность.
"""

import libtorrent as lt
import threading
import time
import logging
from typing import Dict, Any, Optional, List
from threading import Event, RLock
from dataclasses import dataclass
from enum import Enum

from ..models.exceptions import SessionError, ConfigurationError

logger = logging.getLogger(__name__)


class SessionStatus(Enum):
    """Статусы сессии"""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"


@dataclass
class SessionStats:
    """Статистика сессии"""
    download_rate: int = 0
    upload_rate: int = 0
    total_download: int = 0
    total_upload: int = 0
    dht_nodes: int = 0
    num_peers: int = 0
    num_unchoked: int = 0
    num_torrents: int = 0
    up_bandwidth_queue: int = 0
    down_bandwidth_queue: int = 0


class SessionManager:
    """
    Менеджер сессии libtorrent с расширенным функционалом
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.session: Optional[lt.session] = None
        self.status = SessionStatus.INITIALIZING

        # Потокобезопасные структуры
        self._alerts_handlers = {}
        self._lock = RLock()
        self._stop_event = Event()
        self._alerts_thread: Optional[threading.Thread] = None

        # Статистика
        self._stats = SessionStats()
        self._last_stats_update = 0

        self._initialize_session()

    def _initialize_session(self) -> None:
        """Инициализация сессии libtorrent с расширенными настройками"""
        try:
            logger.info("Инициализация сессии libtorrent...")

            # Создание параметров сессии
            session_params = self._create_session_params()

            # Создание сессии
            self.session = lt.session(session_params)

            # Настройка расширенных параметров
            self._configure_session_settings()

            # Запуск обработки алертов
            self._start_alerts_processing()

            # Применение начальных настроек
            self._apply_initial_settings()

            self.status = SessionStatus.RUNNING
            logger.info("Сессия libtorrent успешно инициализирована")

        except Exception as e:
            self.status = SessionStatus.STOPPED
            logger.error(f"Ошибка инициализации сессии: {e}")
            raise SessionError(f"Не удалось инициализировать сессию: {e}")

    def _create_session_params(self) -> lt.session_params:
        """Создание параметров сессии"""
        params = lt.session_params()

        # Базовые настройки из конфигурации
        settings = params.settings

        # Сетевые настройки
        settings["listen_interfaces"] = self.config.get(
            'listen_interfaces',
            f"0.0.0.0:{self.config.get('listen_port', 6881)}"
        )

        # Включение/выключение функций
        settings["enable_dht"] = self.config.get('enable_dht', True)
        settings["enable_upnp"] = self.config.get('enable_upnp', True)
        settings["enable_lsd"] = self.config.get('enable_lsd', True)
        settings["enable_natpmp"] = self.config.get('enable_natpmp', True)

        # Лимиты соединений
        settings["connections_limit"] = self.config.get('max_connections', 200)
        settings["unchoke_slots_limit"] = self.config.get('max_uploads', 10)
        settings["active_downloads"] = self.config.get('max_downloads', 5)
        settings["active_limit"] = self.config.get('max_connections', 200)

        # Лимиты скорости (в байтах/сек)
        download_limit = self.config.get('download_rate_limit', 0) * 1024
        upload_limit = self.config.get('upload_rate_limit', 0) * 1024
        settings["download_rate_limit"] = download_limit
        settings["upload_rate_limit"] = upload_limit

        # Настройки кэша и производительности
        settings["cache_size"] = self.config.get('cache_size', 512)
        settings["file_pool_size"] = self.config.get('file_pool_size', 40)
        settings["checking_mem_usage"] = self.config.get('checking_mem_usage', 256)

        # Дополнительные оптимизации
        settings["send_buffer_watermark"] = 512 * 1024
        settings["send_buffer_low_watermark"] = 128 * 1024
        settings["connection_speed"] = 500
        settings["mixed_mode_algorithm"] = 0  # Prefer TCP

        return params

    def _configure_session_settings(self) -> None:
        """Дополнительная конфигурация сессии"""
        if not self.session:
            return

        try:
            # Настройка DHT если включен
            if self.config.get('enable_dht', True):
                self._configure_dht()

            # Применение дополнительных флагов сессии
            self._apply_session_flags()

        except Exception as e:
            logger.warning(f"Ошибка дополнительной конфигурации сессии: {e}")

    def _configure_dht(self) -> None:
        """Конфигурация DHT сети"""
        try:
            # Добавление bootstrap узлов DHT
            dht_bootstrap_nodes = [
                "router.bittorrent.com:6881",
                "dht.transmissionbt.com:6881",
                "router.utorrent.com:6881",
                "dht.aelitis.com:6881"
            ]

            for node in dht_bootstrap_nodes:
                self.session.add_dht_node(("router.bittorrent.com", 6881))

            # Запуск DHT
            self.session.start_dht()
            self.session.start_lsd()
            self.session.start_natpmp()
            self.session.start_upnp()

            logger.info("DHT сеть инициализирована")

        except Exception as e:
            logger.warning(f"Ошибка конфигурации DHT: {e}")

    def _apply_session_flags(self) -> None:
        """Применение флагов сессии"""
        if not self.session:
            return

        try:
            # Установка флагов для улучшения производительности
            flags = (
                    lt.session_flags.enable_dht |
                    lt.session_flags.enable_lsd |
                    lt.session_flags.enable_upnp |
                    lt.session_flags.enable_natpmp
            )

            # Применение флагов
            self.session.apply_settings({"flags": flags})

        except Exception as e:
            logger.warning(f"Ошибка применения флагов сессии: {e}")

    def _apply_initial_settings(self) -> None:
        """Применение начальных настроек"""
        if not self.session:
            return

        try:
            # Настройка proxy если указан
            if self.config.get('proxy_host'):
                self._configure_proxy()

            # Установка user agent
            user_agent = self.config.get('user_agent', 'Torrent Client 8.0')
            settings = {"user_agent": user_agent}
            self.session.apply_settings(settings)

        except Exception as e:
            logger.warning(f"Ошибка применения начальных настроек: {e}")

    def _configure_proxy(self) -> None:
        """Конфигурация прокси-сервера"""
        try:
            proxy_settings = {
                "proxy_type": self.config.get('proxy_type', lt.proxy_type_t.none),
                "proxy_hostname": self.config.get('proxy_host'),
                "proxy_port": self.config.get('proxy_port', 8080),
                "proxy_username": self.config.get('proxy_username'),
                "proxy_password": self.config.get('proxy_password')
            }

            # Применение настроек прокси
            for key, value in proxy_settings.items():
                if value is not None:
                    self.session.set_proxy(value)

        except Exception as e:
            logger.warning(f"Ошибка конфигурации прокси: {e}")

    def _start_alerts_processing(self) -> None:
        """Запуск обработки алертов в отдельном потоке"""

        def alerts_worker():
            logger.info("Запуск обработчика алертов")

            while not self._stop_event.is_set():
                try:
                    if not self.session:
                        time.sleep(0.1)
                        continue

                    # Ожидание алертов с таймаутом
                    alert = self.session.wait_for_alert(1000)  # 1 секунда

                    if alert:
                        alerts = self.session.pop_alerts()
                        for alert_obj in alerts:
                            self._handle_alert(alert_obj)

                except Exception as e:
                    logger.error(f"Ошибка в обработчике алертов: {e}")
                    time.sleep(0.1)

            logger.info("Обработчик алертов остановлен")

        self._alerts_thread = threading.Thread(
            target=alerts_worker,
            daemon=True,
            name="AlertsProcessor"
        )
        self._alerts_thread.start()

    def _handle_alert(self, alert) -> None:
        """Обработка отдельных алертов"""
        try:
            alert_type = type(alert).__name__

            # Логирование важных алертов
            if alert_type in ['listen_failed_alert', 'portmap_error_alert', 'file_error_alert']:
                logger.warning(f"Alert: {alert_type} - {alert.message()}")
            elif alert_type in ['add_torrent_alert', 'torrent_finished_alert']:
                logger.info(f"Alert: {alert_type} - {alert.message()}")

            # Вызов зарегистрированных обработчиков
            if alert_type in self._alerts_handlers:
                for handler in self._alerts_handlers[alert_type]:
                    try:
                        handler(alert)
                    except Exception as e:
                        logger.error(f"Ошибка в обработчике алерта {alert_type}: {e}")

        except Exception as e:
            logger.error(f"Ошибка обработки алерта: {e}")

    def register_alert_handler(self, alert_type: str, handler: callable) -> None:
        """Регистрация обработчика для конкретного типа алертов"""
        with self._lock:
            if alert_type not in self._alerts_handlers:
                self._alerts_handlers[alert_type] = []
            self._alerts_handlers[alert_type].append(handler)

    def unregister_alert_handler(self, alert_type: str, handler: callable) -> None:
        """Удаление обработчика алертов"""
        with self._lock:
            if alert_type in self._alerts_handlers:
                if handler in self._alerts_handlers[alert_type]:
                    self._alerts_handlers[alert_type].remove(handler)

    def get_session_stats(self) -> SessionStats:
        """Получение статистики сессии"""
        if not self.session:
            return SessionStats()

        try:
            status = self.session.status()

            # Обновление статистики
            self._stats.download_rate = status.download_rate
            self._stats.upload_rate = status.upload_rate
            self._stats.total_download = status.total_download
            self._stats.total_upload = status.total_upload
            self._stats.dht_nodes = status.dht_nodes
            self._stats.num_peers = status.num_peers
            self._stats.num_unchoked = status.num_unchoked

            self._last_stats_update = time.time()

            return self._stats

        except Exception as e:
            logger.error(f"Ошибка получения статистики сессии: {e}")
            return SessionStats()

    def update_settings(self, new_settings: Dict[str, Any]) -> None:
        """Обновление настроек сессии"""
        if not self.session:
            raise SessionError("Сессия не инициализирована")

        try:
            # Обновление конфигурации
            self.config.update(new_settings)

            # Применение настроек к сессии
            lt_settings = {}

            # Маппинг наших настроек на настройки libtorrent
            setting_mapping = {
                'download_rate_limit': 'download_rate_limit',
                'upload_rate_limit': 'upload_rate_limit',
                'max_connections': 'connections_limit',
                'max_uploads': 'unchoke_slots_limit',
                'max_downloads': 'active_downloads'
            }

            for our_key, lt_key in setting_mapping.items():
                if our_key in new_settings:
                    value = new_settings[our_key]
                    # Конвертация KB/s в bytes/s для лимитов скорости
                    if 'rate_limit' in our_key:
                        value = value * 1024
                    lt_settings[lt_key] = value

            if lt_settings:
                self.session.apply_settings(lt_settings)
                logger.info("Настройки сессии обновлены")

        except Exception as e:
            logger.error(f"Ошибка обновления настроек сессии: {e}")
            raise SessionError(f"Не удалось обновить настройки: {e}")

    def pause_session(self) -> None:
        """Приостановка сессии"""
        if self.session and self.status == SessionStatus.RUNNING:
            self.session.pause()
            self.status = SessionStatus.PAUSED
            logger.info("Сессия приостановлена")

    def resume_session(self) -> None:
        """Возобновление сессии"""
        if self.session and self.status == SessionStatus.PAUSED:
            self.session.resume()
            self.status = SessionStatus.RUNNING
            logger.info("Сессия возобновлена")

    def is_paused(self) -> bool:
        """Проверка, приостановлена ли сессия"""
        return self.status == SessionStatus.PAUSED

    def get_listen_port(self) -> int:
        """Получение порта прослушивания"""
        if not self.session:
            return 0

        try:
            # Получение информации о прослушивающих портах
            listen_interfaces = self.session.get_settings()["listen_interfaces"]
            # Парсинг строки интерфейсов для извлечения порта
            parts = listen_interfaces.split(':')
            return int(parts[-1]) if parts else 0

        except Exception as e:
            logger.error(f"Ошибка получения порта прослушивания: {e}")
            return 0

    def shutdown(self) -> None:
        """Корректное завершение работы сессии"""
        logger.info("Завершение работы SessionManager...")

        self.status = SessionStatus.STOPPING

        # Остановка обработки алертов
        self._stop_event.set()

        if self._alerts_thread and self._alerts_thread.is_alive():
            self._alerts_thread.join(timeout=5)

        # Остановка сессии libtorrent
        if self.session:
            try:
                # Сохранение состояния сессии
                self.session.pause()

                # Очистка обработчиков
                self._alerts_handlers.clear()

                # Освобождение ресурсов
                # Note: libtorrent session автоматически очищается при удалении

            except Exception as e:
                logger.error(f"Ошибка при завершении сессии: {e}")

        self.status = SessionStatus.STOPPED
        logger.info("SessionManager завершен")

    def __enter__(self):
        """Поддержка контекстного менеджера"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Автоматическое завершение при выходе из контекста"""
        self.shutdown()

    def __del__(self):
        """Деструктор для гарантированного освобождения ресурсов"""
        if self.status != SessionStatus.STOPPED:
            self.shutdown()