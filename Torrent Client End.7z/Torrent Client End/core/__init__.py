"""
CORE MODULE - Основной модуль торрент-клиента

Содержит фундаментальные компоненты для работы с libtorrent и управления торрентами.
"""

__version__ = "8.0"
__author__ = "Torrent Client Team"

from .session_manager import SessionManager
from .torrent_manager import TorrentManager
from .file_manager import FileManager
from .peer_manager import PeerManager
from .statistics_engine import StatisticsEngine


# Основные исключения ядра
class CoreError(Exception):
    """Базовое исключение для ошибок ядра"""
    pass


class SessionError(CoreError):
    """Ошибка инициализации или работы сессии"""
    pass


class TorrentError(CoreError):
    """Ошибка работы с торрентами"""
    pass


class ConfigurationError(CoreError):
    """Ошибка конфигурации"""
    pass


# Экспорт основных классов для удобного импорта
__all__ = [
    'SessionManager',
    'TorrentManager',
    'FileManager',
    'PeerManager',
    'StatisticsEngine',
    'CoreError',
    'SessionError',
    'TorrentError',
    'ConfigurationError'
]

# Инициализация логгера для core модуля
import logging

logger = logging.getLogger(__name__)


def init_core_module():
    """Инициализация core модуля"""
    logger.info("Инициализация core модуля v%s", __version__)


def shutdown_core_module():
    """Корректное завершение work модуля"""
    logger.info("Завершение core модуля")