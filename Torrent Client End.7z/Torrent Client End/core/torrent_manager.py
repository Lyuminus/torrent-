"""
TORRENT MANAGER - Менеджер торрентов

Отвечает за управление торрентами: добавление, удаление, приостановка, возобновление.
Обеспечивает работу с файлами и магнет-ссылками, управление приоритетами и состоянием торрентов.
"""

import libtorrent as lt
import time
import logging
import hashlib
from typing import Dict, List, Optional, Any, Union, Tuple
from pathlib import Path
from threading import RLock
from dataclasses import dataclass, asdict
from enum import Enum

from ..models.exceptions import TorrentError, SecurityError
from ..models.torrent import TorrentStatus, Priority, TorrentStats
from ..utils.validators import validate_torrent_file, safe_path_join

logger = logging.getLogger(__name__)


class AddTorrentResult(Enum):
    """Результаты добавления торрента"""
    SUCCESS = "success"
    ALREADY_EXISTS = "already_exists"
    INVALID_FILE = "invalid_file"
    ERROR = "error"


@dataclass
class AddTorrentParams:
    """Параметры для добавления торрента"""
    save_path: str
    storage_mode: int = lt.storage_mode_t.storage_mode_sparse
    paused: bool = False
    flags: int = 0
    category: str = "default"
    tags: List[str] = None
    priority: Priority = Priority.NORMAL
    sequential_download: bool = False

    def __post_init__(self):
        if self.tags is None:
            self.tags = []


class TorrentManager:
    """
    Менеджер торрентов с расширенным функционалом
    """

    def __init__(self, session_manager, config: Dict[str, Any]):
        self.session_manager = session_manager
        self.config = config

        # Потокобезопасные структуры для хранения торрентов
        self._handles: Dict[str, lt.torrent_handle] = {}
        self._torrent_info: Dict[str, Dict[str, Any]] = {}
        self._lock = RLock()

        # Очередь для отложенных операций
        self._pending_operations = []

        # Регистрация обработчиков алертов
        self._register_alert_handlers()

        logger.info("TorrentManager инициализирован")

    def _register_alert_handlers(self) -> None:
        """Регистрация обработчиков алертов"""
        self.session_manager.register_alert_handler('add_torrent_alert', self._on_add_torrent)
        self.session_manager.register_alert_handler('torrent_finished_alert', self._on_torrent_finished)
        self.session_manager.register_alert_handler('torrent_error_alert', self._on_torrent_error)
        self.session_manager.register_alert_handler('torrent_paused_alert', self._on_torrent_paused)
        self.session_manager.register_alert_handler('torrent_resumed_alert', self._on_torrent_resumed)
        self.session_manager.register_alert_handler('save_resume_data_alert', self._on_save_resume_data)
        self.session_manager.register_alert_handler('state_changed_alert', self._on_state_changed)

    def _on_add_torrent(self, alert) -> None:
        """Обработка добавления торрента"""
        try:
            handle = alert.handle
            info_hash = str(handle.info_hash())

            with self._lock:
                if info_hash not in self._handles:
                    self._handles[info_hash] = handle
                    logger.info(f"Торрент добавлен в сессию: {handle.status().name}")

        except Exception as e:
            logger.error(f"Ошибка обработки добавления торрента: {e}")

    def _on_torrent_finished(self, alert) -> None:
        """Обработка завершения загрузки торрента"""
        try:
            handle = alert.handle
            info_hash = str(handle.info_hash())

            logger.info(f"Торрент завершен: {handle.status().name}")

            # Вызов пользовательских обработчиков
            if hasattr(self, '_completion_handlers'):
                for handler in self._completion_handlers:
                    try:
                        handler(info_hash, handle)
                    except Exception as e:
                        logger.error(f"Ошибка в обработчике завершения: {e}")

        except Exception as e:
            logger.error(f"Ошибка обработки завершения торрента: {e}")

    def _on_torrent_error(self, alert) -> None:
        """Обработка ошибок торрента"""
        try:
            handle = alert.handle
            error_msg = alert.error.message()

            logger.error(f"Ошибка торрента {handle.status().name}: {error_msg}")

        except Exception as e:
            logger.error(f"Ошибка обработки ошибки торрента: {e}")

    def _on_torrent_paused(self, alert) -> None:
        """Обработка приостановки торрента"""
        try:
            handle = alert.handle
            logger.debug(f"Торрент приостановлен: {handle.status().name}")
        except Exception as e:
            logger.error(f"Ошибка обработки приостановки торрента: {e}")

    def _on_torrent_resumed(self, alert) -> None:
        """Обработка возобновления торрента"""
        try:
            handle = alert.handle
            logger.debug(f"Торрент возобновлен: {handle.status().name}")
        except Exception as e:
            logger.error(f"Ошибка обработки возобновления торрента: {e}")

    def _on_save_resume_data(self, alert) -> None:
        """Обработка сохранения данных возобновления"""
        try:
            logger.debug("Данные возобновления сохранены")
        except Exception as e:
            logger.error(f"Ошибка обработки сохранения резюме: {e}")

    def _on_state_changed(self, alert) -> None:
        """Обработка изменения состояния торрента"""
        try:
            # Можно добавить логику реакции на изменения состояния
            pass
        except Exception as e:
            logger.error(f"Ошибка обработки изменения состояния: {e}")

    def add_torrent_from_file(self, torrent_path: str, params: AddTorrentParams) -> AddTorrentResult:
        """
        Добавление торрента из файла

        Args:
            torrent_path: Путь к .torrent файлу
            params: Параметры добавления

        Returns:
            Результат операции добавления
        """
        try:
            # Валидация файла
            if not validate_torrent_file(torrent_path):
                return AddTorrentResult.INVALID_FILE

            # Создание информации о торренте
            info = lt.torrent_info(torrent_path)
            info_hash = str(info.info_hash())

            # Проверка существования
            if self._has_torrent(info_hash):
                return AddTorrentResult.ALREADY_EXISTS

            # Безопасное создание пути
            save_path = safe_path_join(params.save_path, info.name())

            # Создание параметров добавления
            add_params = {
                'ti': info,
                'save_path': str(save_path),
                'storage_mode': params.storage_mode
            }

            # Установка флагов
            if params.paused:
                add_params['flags'] = lt.torrent_flags.paused

            # Добавление в сессию
            session = self.session_manager.session
            if not session:
                raise TorrentError("Сессия не доступна")

            handle = session.add_torrent(add_params)

            # Настройка торрента
            self._configure_torrent(handle, params)

            # Сохранение информации
            with self._lock:
                self._handles[info_hash] = handle
                self._torrent_info[info_hash] = {
                    'name': info.name(),
                    'torrent_path': torrent_path,
                    'save_path': str(save_path),
                    'added_time': time.time(),
                    'params': asdict(params)
                }

            logger.info(f"Торрент добавлен из файла: {info.name()}")
            return AddTorrentResult.SUCCESS

        except Exception as e:
            logger.error(f"Ошибка добавления торрента из файла: {e}")
            return AddTorrentResult.ERROR

    def add_torrent_from_magnet(self, magnet_link: str, params: AddTorrentParams) -> AddTorrentResult:
        """
        Добавление торрента из магнет-ссылки

        Args:
            magnet_link: Магнет-ссылка
            params: Параметры добавления

        Returns:
            Результат операции добавления
        """
        try:
            # Парсинг магнет-ссылки
            magnet_params = lt.parse_magnet_uri(magnet_link)

            if not magnet_params.info_hash:
                raise TorrentError("Неверная магнет-ссылка: отсутствует info_hash")

            info_hash = str(magnet_params.info_hash)

            # Проверка существования
            if self._has_torrent(info_hash):
                return AddTorrentResult.ALREADY_EXISTS

            # Создание безопасного пути
            torrent_name = getattr(magnet_params, 'name', f"magnet_{info_hash}")
            save_path = safe_path_join(params.save_path, torrent_name)

            # Создание параметров добавления
            add_params = {
                'info_hash': magnet_params.info_hash,
                'save_path': str(save_path),
                'storage_mode': params.storage_mode
            }

            # Добавление имени если есть
            if hasattr(magnet_params, 'name') and magnet_params.name:
                add_params['name'] = magnet_params.name

            # Установка флагов
            if params.paused:
                add_params['flags'] = lt.torrent_flags.paused

            # Добавление в сессию
            session = self.session_manager.session
            if not session:
                raise TorrentError("Сессия не доступна")

            handle = session.add_torrent(add_params)

            # Настройка торрента
            self._configure_torrent(handle, params)

            # Сохранение информации
            with self._lock:
                self._handles[info_hash] = handle
                self._torrent_info[info_hash] = {
                    'name': torrent_name,
                    'magnet_link': magnet_link,
                    'save_path': str(save_path),
                    'added_time': time.time(),
                    'params': asdict(params)
                }

            logger.info(f"Торрент добавлен из магнет-ссылки: {torrent_name}")
            return AddTorrentResult.SUCCESS

        except Exception as e:
            logger.error(f"Ошибка добавления торрента из магнет-ссылки: {e}")
            return AddTorrentResult.ERROR

    def _configure_torrent(self, handle: lt.torrent_handle, params: AddTorrentParams) -> None:
        """Настройка добавленного торрента"""
        try:
            # Последовательная загрузка
            if params.sequential_download:
                handle.set_sequential_download(True)

            # Установка приоритета
            self.set_torrent_priority(str(handle.info_hash()), params.priority)

            # Настройка лимитов если указаны
            if hasattr(params, 'download_limit'):
                handle.set_download_limit(params.download_limit)
            if hasattr(params, 'upload_limit'):
                handle.set_upload_limit(params.upload_limit)

        except Exception as e:
            logger.warning(f"Ошибка конфигурации торрента: {e}")

    def _has_torrent(self, info_hash: str) -> bool:
        """Проверка существования торрента"""
        with self._lock:
            return info_hash in self._handles

    def remove_torrent(self, info_hash: str, delete_files: bool = False) -> bool:
        """
        Удаление торрента

        Args:
            info_hash: Хеш торрента
            delete_files: Удалять ли файлы

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]
                session = self.session_manager.session

                if session:
                    session.remove_torrent(handle, int(delete_files))

                # Удаление из внутренних структур
                del self._handles[info_hash]
                if info_hash in self._torrent_info:
                    del self._torrent_info[info_hash]

            logger.info(f"Торрент удален: {info_hash}")
            return True

        except Exception as e:
            logger.error(f"Ошибка удаления торрента {info_hash}: {e}")
            return False

    def pause_torrent(self, info_hash: str) -> bool:
        """Приостановка торрента"""
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]
                handle.pause()

                logger.debug(f"Торрент приостановлен: {info_hash}")
                return True

        except Exception as e:
            logger.error(f"Ошибка приостановки торрента {info_hash}: {e}")
            return False

    def resume_torrent(self, info_hash: str) -> bool:
        """Возобновление торрента"""
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]
                handle.resume()

                logger.debug(f"Торрент возобновлен: {info_hash}")
                return True

        except Exception as e:
            logger.error(f"Ошибка возобновления торрента {info_hash}: {e}")
            return False

    def pause_all(self) -> None:
        """Приостановка всех торрентов"""
        try:
            with self._lock:
                for info_hash in list(self._handles.keys()):
                    self.pause_torrent(info_hash)

            logger.info("Все торренты приостановлены")

        except Exception as e:
            logger.error(f"Ошибка приостановки всех торрентов: {e}")

    def resume_all(self) -> None:
        """Возобновление всех торрентов"""
        try:
            with self._lock:
                for info_hash in list(self._handles.keys()):
                    self.resume_torrent(info_hash)

            logger.info("Все торренты возобновлены")

        except Exception as e:
            logger.error(f"Ошибка возобновления всех торрентов: {e}")

    def get_torrent_status(self, info_hash: str) -> Optional[TorrentStats]:
        """
        Получение статуса торрента

        Args:
            info_hash: Хеш торрента

        Returns:
            Статистика торрента или None если не найден
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return None

                handle = self._handles[info_hash]
                status = handle.status()

                # Расчет ETA
                eta = 0
                if status.download_rate > 0 and status.total_wanted > status.total_wanted_done:
                    eta = (status.total_wanted - status.total_wanted_done) / status.download_rate

                # Получение информации о файлах
                files = []
                if handle.has_metadata():
                    torrent_info = handle.get_torrent_info()
                    file_progress = handle.file_progress()

                    for i in range(torrent_info.num_files()):
                        file_entry = torrent_info.files().at(i)
                        file_size = file_entry.size
                        file_prog = file_progress[i] if i < len(file_progress) else 0

                        files.append({
                            'path': str(file_entry.path),
                            'size': file_size,
                            'progress': file_prog / file_size if file_size > 0 else 0,
                            'priority': handle.file_priorities()[i] if handle.file_priorities() else 4
                        })

                # Определение статуса
                lt_status = self._map_lt_status(status)

                # Получение дополнительной информации
                info = self._torrent_info.get(info_hash, {})

                return TorrentStats(
                    info_hash=info_hash,
                    name=status.name,
                    progress=status.progress,
                    download_rate=status.download_rate,
                    upload_rate=status.upload_rate,
                    total_downloaded=status.total_download,
                    total_uploaded=status.total_upload,
                    peers=status.num_peers,
                    seeds=status.num_seeds,
                    status=lt_status,
                    eta=int(eta),
                    piece_size=torrent_info.piece_length() if handle.has_metadata() else 0,
                    pieces_done=status.num_pieces,
                    pieces_total=torrent_info.num_pieces() if handle.has_metadata() else 0,
                    files=files,
                    download_path=info.get('save_path', ''),
                    added_time=info.get('added_time', 0),
                    category=info.get('params', {}).get('category', 'default'),
                    tags=info.get('params', {}).get('tags', []),
                    priority=Priority(info.get('params', {}).get('priority', 1))
                )

        except Exception as e:
            logger.error(f"Ошибка получения статуса торрента {info_hash}: {e}")
            return None

    def _map_lt_status(self, status) -> TorrentStatus:
        """Маппинг статуса libtorrent на наш enum"""
        if status.is_seeding:
            return TorrentStatus.SEEDING
        elif status.paused:
            return TorrentStatus.PAUSED
        elif status.progress >= 1.0:
            return TorrentStatus.COMPLETED
        elif status.state == lt.torrent_status.checking_files:
            return TorrentStatus.CHECKING
        elif status.state == lt.torrent_status.downloading:
            return TorrentStatus.DOWNLOADING
        elif status.state == lt.torrent_status.finished:
            return TorrentStatus.COMPLETED
        elif status.state == lt.torrent_status.seeding:
            return TorrentStatus.SEEDING
        else:
            return TorrentStatus.DOWNLOADING

    def get_all_torrents_status(self) -> List[TorrentStats]:
        """Получение статуса всех торрентов"""
        try:
            with self._lock:
                status_list = []

                for info_hash in list(self._handles.keys()):
                    stats = self.get_torrent_status(info_hash)
                    if stats:
                        status_list.append(stats)

                return status_list

        except Exception as e:
            logger.error(f"Ошибка получения статуса всех торрентов: {e}")
            return []

    def set_torrent_priority(self, info_hash: str, priority: Priority) -> bool:
        """
        Установка приоритета торрента

        Args:
            info_hash: Хеш торрента
            priority: Приоритет

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]

                # Маппинг приоритетов
                priority_map = {
                    Priority.LOW: 1,
                    Priority.NORMAL: 4,
                    Priority.HIGH: 6,
                    Priority.MAXIMUM: 7
                }

                lt_priority = priority_map.get(priority, 4)
                handle.set_priority(lt_priority)

                # Обновление информации
                if info_hash in self._torrent_info:
                    if 'params' not in self._torrent_info[info_hash]:
                        self._torrent_info[info_hash]['params'] = {}
                    self._torrent_info[info_hash]['params']['priority'] = priority.value

                logger.debug(f"Приоритет торрента {info_hash} установлен на {priority}")
                return True

        except Exception as e:
            logger.error(f"Ошибка установки приоритета {info_hash}: {e}")
            return False

    def set_file_priorities(self, info_hash: str, priorities: List[int]) -> bool:
        """
        Установка приоритетов файлов

        Args:
            info_hash: Хеш торрента
            priorities: Список приоритетов для каждого файла

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]

                if not handle.has_metadata():
                    return False

                # Проверка количества файлов
                torrent_info = handle.get_torrent_info()
                if len(priorities) != torrent_info.num_files():
                    logger.warning("Количество приоритетов не совпадает с количеством файлов")
                    return False

                handle.prioritize_files(priorities)
                logger.debug(f"Приоритеты файлов установлены для {info_hash}")
                return True

        except Exception as e:
            logger.error(f"Ошибка установки приоритетов файлов {info_hash}: {e}")
            return False

    def force_recheck(self, info_hash: str) -> bool:
        """
        Принудительная проверка целостности торрента

        Args:
            info_hash: Хеш торрента

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]
                handle.force_recheck()

                logger.info(f"Проверка целостности запущена для {info_hash}")
                return True

        except Exception as e:
            logger.error(f"Ошибка запуска проверки целостности {info_hash}: {e}")
            return False

    def get_torrent_files(self, info_hash: str) -> List[Dict[str, Any]]:
        """
        Получение списка файлов торрента

        Args:
            info_hash: Хеш торрента

        Returns:
            Список файлов с информацией
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return []

                handle = self._handles[info_hash]

                if not handle.has_metadata():
                    return []

                torrent_info = handle.get_torrent_info()
                file_progress = handle.file_progress()
                file_priorities = handle.file_priorities()

                files = []
                for i in range(torrent_info.num_files()):
                    file_entry = torrent_info.files().at(i)
                    file_size = file_entry.size
                    progress = file_progress[i] if i < len(file_progress) else 0
                    priority = file_priorities[i] if file_priorities and i < len(file_priorities) else 4

                    files.append({
                        'index': i,
                        'path': str(file_entry.path),
                        'size': file_size,
                        'progress': progress / file_size if file_size > 0 else 0,
                        'priority': priority,
                        'offset': file_entry.offset
                    })

                return files

        except Exception as e:
            logger.error(f"Ошибка получения файлов торрента {info_hash}: {e}")
            return []

    def get_peers_info(self, info_hash: str) -> List[Dict[str, Any]]:
        """
        Получение информации о пирах

        Args:
            info_hash: Хеш торрента

        Returns:
            Список пиров с информацией
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return []

                handle = self._handles[info_hash]
                peers = handle.get_peer_info()

                peers_info = []
                for peer in peers:
                    peers_info.append({
                        'ip': peer.ip[0],
                        'port': peer.ip[1],
                        'client': peer.client,
                        'flags': str(peer.flags),
                        'down_speed': peer.down_speed,
                        'up_speed': peer.up_speed,
                        'progress': peer.progress,
                        'total_download': peer.total_download,
                        'total_upload': peer.total_upload,
                        'country': getattr(peer, 'country', ''),
                        'connection_type': getattr(peer, 'connection_type', '')
                    })

                return peers_info

        except Exception as e:
            logger.error(f"Ошибка получения информации о пирах {info_hash}: {e}")
            return []

    def move_storage(self, info_hash: str, new_path: str) -> bool:
        """
        Перемещение файлов торрента

        Args:
            info_hash: Хеш торрента
            new_path: Новый путь

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if info_hash not in self._handles:
                    return False

                handle = self._handles[info_hash]

                # Безопасное создание пути
                safe_path = safe_path_join(new_path)

                handle.move_storage(str(safe_path))

                # Обновление информации о пути
                if info_hash in self._torrent_info:
                    self._torrent_info[info_hash]['save_path'] = str(safe_path)

                logger.info(f"Файлы торрента {info_hash} перемещены в {safe_path}")
                return True

        except Exception as e:
            logger.error(f"Ошибка перемещения файлов {info_hash}: {e}")
            return False

    def get_torrent_count(self) -> int:
        """Получение количества торрентов"""
        with self._lock:
            return len(self._handles)

    def get_active_torrent_count(self) -> int:
        """Получение количества активных торрентов"""
        try:
            count = 0
            with self._lock:
                for info_hash in self._handles:
                    status = self.get_torrent_status(info_hash)
                    if status and status.status in [TorrentStatus.DOWNLOADING, TorrentStatus.SEEDING]:
                        count += 1

            return count

        except Exception as e:
            logger.error(f"Ошибка подсчета активных торрентов: {e}")
            return 0

    def add_completion_handler(self, handler: callable) -> None:
        """Добавление обработчика завершения загрузки"""
        if not hasattr(self, '_completion_handlers'):
            self._completion_handlers = []

        self._completion_handlers.append(handler)

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы TorrentManager...")

        # Отмена регистрации обработчиков
        self.session_manager.unregister_alert_handler('add_torrent_alert', self._on_add_torrent)
        self.session_manager.unregister_alert_handler('torrent_finished_alert', self._on_torrent_finished)
        self.session_manager.unregister_alert_handler('torrent_error_alert', self._on_torrent_error)
        self.session_manager.unregister_alert_handler('torrent_paused_alert', self._on_torrent_paused)
        self.session_manager.unregister_alert_handler('torrent_resumed_alert', self._on_torrent_resumed)
        self.session_manager.unregister_alert_handler('save_resume_data_alert', self._on_save_resume_data)
        self.session_manager.unregister_alert_handler('state_changed_alert', self._on_state_changed)

        # Очистка структур
        with self._lock:
            self._handles.clear()
            self._torrent_info.clear()

        if hasattr(self, '_completion_handlers'):
            self._completion_handlers.clear()

        logger.info("TorrentManager завершен")