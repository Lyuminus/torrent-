"""
SECURITY SERVICE - Сервис безопасности и валидации

Отвечает за проверку безопасности торрент-файлов, магнет-ссылок, путей доступа.
Обеспечивает защиту от вредоносного контента, проверку целостности данных
и управление черными списками источников.
"""

import hashlib
import logging
import re
import tempfile
from typing import Dict, List, Optional, Any, Set, Tuple
from pathlib import Path
from threading import RLock
from dataclasses import dataclass, field
from enum import Enum
import ipaddress
import urllib.parse

import libtorrent as lt

from ..models.exceptions import SecurityError
from ..utils.validators import validate_path, safe_path_join, validate_ip_address

logger = logging.getLogger(__name__)


class SecurityLevel(Enum):
    """Уровни безопасности"""
    TRUSTED = "trusted"
    SUSPICIOUS = "suspicious"
    MALICIOUS = "malicious"
    UNKNOWN = "unknown"


class ThreatType(Enum):
    """Типы угроз"""
    MALWARE = "malware"
    PHISHING = "phishing"
    SPAM = "spam"
    EXPLOIT = "exploit"
    UNWANTED_SOFTWARE = "unwanted_software"
    SUSPICIOUS_CONTENT = "suspicious_content"
    PATH_TRAVERSAL = "path_traversal"
    EXECUTABLE_IN_ARCHIVE = "executable_in_archive"


@dataclass
class SecurityScanResult:
    """Результат проверки безопасности"""
    security_level: SecurityLevel
    threats: List[ThreatType] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0  # Уверенность в результате (0.0 - 1.0)


@dataclass
class BlacklistEntry:
    """Запись в черном списке"""
    identifier: str
    entry_type: str  # 'ip', 'hash', 'domain', 'tracker'
    reason: str
    added_time: float
    expires_at: Optional[float] = None
    severity: SecurityLevel = SecurityLevel.MALICIOUS


class SecurityService:
    """
    Сервис безопасности с расширенными возможностями проверки
    """

    def __init__(self, config_service):
        self.config_service = config_service
        self._lock = RLock()

        # Черные списки
        self._ip_blacklist: Set[str] = set()
        self._hash_blacklist: Set[str] = set()
        self._domain_blacklist: Set[str] = set()
        self._tracker_blacklist: Set[str] = set()

        # Белые списки (доверенные источники)
        self._trusted_trackers: Set[str] = set()
        self._trusted_hashes: Set[str] = set()

        # Кэш результатов проверок
        self._scan_cache: Dict[str, SecurityScanResult] = {}
        self._cache_ttl: Dict[str, float] = {}

        # Паттерны для обнаружения угроз
        self._malware_patterns = self._load_malware_patterns()
        self._suspicious_extensions = self._load_suspicious_extensions()

        # Статистика
        self._scan_stats = {
            'total_scans': 0,
            'threats_detected': 0,
            'false_positives': 0
        }

        # Инициализация
        self._load_blacklists()
        self._load_trusted_sources()

        logger.info("SecurityService инициализирован")

    def _load_malware_patterns(self) -> List[re.Pattern]:
        """Загрузка паттернов для обнаружения вредоносного ПО"""
        patterns = [
            # Паттерны для распространенных имен вредоносных файлов
            re.compile(r'(trojan|virus|malware|ransomware|spyware|keylogger)', re.IGNORECASE),
            re.compile(r'(cryptolocker|wannacry|petya|notpetya)', re.IGNORECASE),

            # Подозрительные комбинации в именах
            re.compile(r'.*\.exe\.(scr|pif|com)$', re.IGNORECASE),
            re.compile(r'^[a-f0-9]{32}\.(exe|scr)$', re.IGNORECASE),

            # Маскирующиеся имена
            re.compile(r'^document\.(pdf|doc)\.exe$', re.IGNORECASE),
            re.compile(r'^invoice_.*\.zip$', re.IGNORECASE),
        ]
        return patterns

    def _load_suspicious_extensions(self) -> Set[str]:
        """Загрузка списка подозрительных расширений"""
        return {
            '.exe', '.scr', '.pif', '.com', '.bat', '.cmd', '.msi',
            '.jar', '.js', '.vbs', '.ps1', '.sh', '.app', '.dmg',
            '.apk', '.deb', '.rpm', '.scr', '.hta'
        }

    def _load_blacklists(self) -> None:
        """Загрузка черных списков из конфигурации"""
        try:
            blacklists = self.config_service.get('security.blacklists', {})

            # Загрузка IP черного списка
            self._ip_blacklist.update(blacklists.get('ips', []))

            # Загрузка хеш-черного списка
            self._hash_blacklist.update(blacklists.get('hashes', []))

            # Загрузка доменного черного списка
            self._domain_blacklist.update(blacklists.get('domains', []))

            # Загрузка трекер-черного списка
            self._tracker_blacklist.update(blacklists.get('trackers', []))

            logger.info(f"Загружены черные списки: {len(self._ip_blacklist)} IP, "
                        f"{len(self._hash_blacklist)} хешей, "
                        f"{len(self._domain_blacklist)} доменов, "
                        f"{len(self._tracker_blacklist)} трекеров")

        except Exception as e:
            logger.error(f"Ошибка загрузки черных списков: {e}")

    def _load_trusted_sources(self) -> None:
        """Загрузка доверенных источников"""
        try:
            trusted = self.config_service.get('security.trusted_sources', {})

            self._trusted_trackers.update(trusted.get('trackers', []))
            self._trusted_hashes.update(trusted.get('hashes', []))

            logger.info(f"Загружены доверенные источники: {len(self._trusted_trackers)} трекеров, "
                        f"{len(self._trusted_hashes)} хешей")

        except Exception as e:
            logger.error(f"Ошибка загрузки доверенных источников: {e}")

    def scan_torrent_file(self, file_path: str) -> SecurityScanResult:
        """
        Проверка безопасности торрент-файла

        Args:
            file_path: Путь к торрент-файлу

        Returns:
            Результат проверки безопасности
        """
        try:
            # Проверка кэша
            file_hash = self._calculate_file_hash(file_path)
            cache_key = f"torrent_file_{file_hash}"

            cached_result = self._get_cached_result(cache_key)
            if cached_result:
                return cached_result

            result = SecurityScanResult(security_level=SecurityLevel.UNKNOWN)

            # Базовые проверки
            if not self._validate_torrent_file_path(file_path):
                result.security_level = SecurityLevel.MALICIOUS
                result.threats.append(ThreatType.PATH_TRAVERSAL)
                result.warnings.append("Небезопасный путь к торрент-файлу")
                return result

            # Проверка содержимого торрент-файла
            torrent_info = self._analyze_torrent_file(file_path)
            if torrent_info:
                result = self._scan_torrent_content(torrent_info)
            else:
                result.security_level = SecurityLevel.SUSPICIOUS
                result.warnings.append("Не удалось проанализировать торрент-файл")

            # Сохранение в кэш
            self._cache_result(cache_key, result)
            self._update_stats(result)

            return result

        except Exception as e:
            logger.error(f"Ошибка проверки торрент-файла {file_path}: {e}")
            return SecurityScanResult(
                security_level=SecurityLevel.UNKNOWN,
                warnings=[f"Ошибка проверки: {str(e)}"]
            )

    def scan_magnet_link(self, magnet_uri: str) -> SecurityScanResult:
        """
        Проверка безопасности магнет-ссылки

        Args:
            magnet_uri: Магнет-ссылка

        Returns:
            Результат проверки безопасности
        """
        try:
            # Проверка кэша
            cache_key = f"magnet_{hash(magnet_uri)}"
            cached_result = self._get_cached_result(cache_key)
            if cached_result:
                return cached_result

            result = SecurityScanResult(security_level=SecurityLevel.UNKNOWN)

            # Парсинг магнет-ссылки
            parsed = lt.parse_magnet_uri(magnet_uri)

            # Проверка info_hash
            info_hash = str(parsed.info_hash) if parsed.info_hash else None
            if info_hash:
                if self._is_hash_blacklisted(info_hash):
                    result.security_level = SecurityLevel.MALICIOUS
                    result.threats.append(ThreatType.MALWARE)
                    result.details['blacklisted_hash'] = info_hash

                elif self._is_hash_trusted(info_hash):
                    result.security_level = SecurityLevel.TRUSTED
                    result.details['trusted_hash'] = info_hash

            # Проверка трекеров
            suspicious_trackers = []
            for tracker in parsed.trackers:
                if self._is_tracker_blacklisted(tracker):
                    suspicious_trackers.append(tracker)
                elif self._is_tracker_trusted(tracker):
                    result.confidence += 0.3  # Повышаем уверенность за доверенные трекеры

            if suspicious_trackers:
                result.security_level = SecurityLevel.SUSPICIOUS
                result.threats.append(ThreatType.SPAM)
                result.details['suspicious_trackers'] = suspicious_trackers
                result.warnings.append(f"Обнаружены подозрительные трекеры: {suspicious_trackers}")

            # Проверка доменов в трекерах
            for tracker in parsed.trackers:
                domain = self._extract_domain_from_url(tracker)
                if domain and self._is_domain_blacklisted(domain):
                    result.security_level = SecurityLevel.MALICIOUS
                    result.threats.append(ThreatType.PHISHING)
                    result.details['blacklisted_domain'] = domain
                    break

            # Если угроз не обнаружено, повышаем уровень безопасности
            if result.security_level == SecurityLevel.UNKNOWN and result.confidence > 0.5:
                result.security_level = SecurityLevel.TRUSTED

            # Сохранение в кэш
            self._cache_result(cache_key, result)
            self._update_stats(result)

            return result

        except Exception as e:
            logger.error(f"Ошибка проверки магнет-ссылки: {e}")
            return SecurityScanResult(
                security_level=SecurityLevel.UNKNOWN,
                warnings=[f"Ошибка проверки: {str(e)}"]
            )

    def _analyze_torrent_file(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Анализ содержимого торрент-файла"""
        try:
            info = lt.torrent_info(file_path)
            files = info.files()

            torrent_data = {
                'name': info.name(),
                'info_hash': str(info.info_hash()),
                'total_size': info.total_size(),
                'num_files': info.num_files(),
                'files': [],
                'trackers': [],
                'creation_date': info.creation_date(),
                'comment': info.comment() or '',
                'creator': info.creator() or ''
            }

            # Информация о файлах
            for i in range(files.num_files()):
                file_entry = files.at(i)
                torrent_data['files'].append({
                    'path': str(file_entry.path),
                    'size': file_entry.size,
                    'extension': Path(file_entry.path).suffix.lower()
                })

            # Информация о трекерах
            for tracker in info.trackers():
                torrent_data['trackers'].append(tracker.url)

            return torrent_data

        except Exception as e:
            logger.error(f"Ошибка анализа торрент-файла {file_path}: {e}")
            return None

    def _scan_torrent_content(self, torrent_info: Dict[str, Any]) -> SecurityScanResult:
        """Проверка содержимого торрента на угрозы"""
        result = SecurityScanResult(security_level=SecurityLevel.TRUSTED)

        # Проверка info_hash
        info_hash = torrent_info.get('info_hash', '')
        if self._is_hash_blacklisted(info_hash):
            result.security_level = SecurityLevel.MALICIOUS
            result.threats.append(ThreatType.MALWARE)
            result.details['blacklisted_hash'] = info_hash
            return result

        if self._is_hash_trusted(info_hash):
            result.security_level = SecurityLevel.TRUSTED
            result.confidence = 1.0
            return result

        # Проверка имени торрента
        name = torrent_info.get('name', '')
        name_threats = self._check_name_for_threats(name)
        if name_threats:
            result.security_level = SecurityLevel.SUSPICIOUS
            result.threats.extend(name_threats)
            result.warnings.append(f"Подозрительное имя торрента: {name}")

        # Проверка файлов
        file_threats = self._check_files_for_threats(torrent_info.get('files', []))
        if file_threats:
            result.security_level = max(result.security_level, SecurityLevel.SUSPICIOUS)
            result.threats.extend(file_threats)

        # Проверка трекеров
        tracker_threats = self._check_trackers_for_threats(torrent_info.get('trackers', []))
        if tracker_threats:
            result.security_level = max(result.security_level, SecurityLevel.SUSPICIOUS)
            result.threats.extend(tracker_threats)

        # Проверка комментария и создателя
        comment = torrent_info.get('comment', '')
        creator = torrent_info.get('creator', '')
        if self._check_text_for_threats(comment) or self._check_text_for_threats(creator):
            result.security_level = SecurityLevel.SUSPICIOUS
            result.threats.append(ThreatType.SPAM)

        # Расчет уверенности
        result.confidence = self._calculate_confidence(torrent_info, result)

        return result

    def _check_name_for_threats(self, name: str) -> List[ThreatType]:
        """Проверка имени на угрозы"""
        threats = []

        for pattern in self._malware_patterns:
            if pattern.search(name):
                threats.append(ThreatType.MALWARE)
                break

        return threats

    def _check_files_for_threats(self, files: List[Dict]) -> List[ThreatType]:
        """Проверка файлов на угрозы"""
        threats = []
        executable_count = 0
        total_files = len(files)

        for file_info in files:
            file_path = file_info.get('path', '')
            extension = file_info.get('extension', '')

            # Проверка на исполняемые файлы
            if extension in self._suspicious_extensions:
                executable_count += 1

            # Проверка пути на traversal
            if self._has_path_traversal(file_path):
                threats.append(ThreatType.PATH_TRAVERSAL)

            # Проверка имени файла
            file_name = Path(file_path).name
            for pattern in self._malware_patterns:
                if pattern.search(file_name):
                    threats.append(ThreatType.MALWARE)
                    break

        # Проверка соотношения исполняемых файлов
        if total_files > 0 and executable_count / total_files > 0.3:
            threats.append(ThreatType.EXECUTABLE_IN_ARCHIVE)

        return threats

    def _check_trackers_for_threats(self, trackers: List[str]) -> List[ThreatType]:
        """Проверка трекеров на угрозы"""
        threats = []

        for tracker in trackers:
            # Проверка черного списка
            if self._is_tracker_blacklisted(tracker):
                threats.append(ThreatType.SPAM)
                continue

            # Проверка домена
            domain = self._extract_domain_from_url(tracker)
            if domain and self._is_domain_blacklisted(domain):
                threats.append(ThreatType.PHISHING)
                continue

            # Проверка IP адреса
            ip = self._extract_ip_from_url(tracker)
            if ip and self._is_ip_blacklisted(ip):
                threats.append(ThreatType.MALWARE)

        return threats

    def _check_text_for_threats(self, text: str) -> bool:
        """Проверка текста на угрозы"""
        if not text:
            return False

        text_lower = text.lower()
        suspicious_keywords = [
            'crack', 'keygen', 'serial', 'patch', 'nulled',
            'warez', 'torrent', 'download', 'free', 'full version'
        ]

        return any(keyword in text_lower for keyword in suspicious_keywords)

    def _calculate_confidence(self, torrent_info: Dict[str, Any],
                              scan_result: SecurityScanResult) -> float:
        """Расчет уверенности в результате проверки"""
        confidence = 0.5  # Базовая уверенность

        # Положительные факторы
        if torrent_info.get('creation_date', 0) > 0:
            confidence += 0.1

        if len(torrent_info.get('trackers', [])) > 2:
            confidence += 0.1

        if torrent_info.get('comment'):
            confidence += 0.05

        # Отрицательные факторы
        if scan_result.threats:
            confidence -= len(scan_result.threats) * 0.2

        if scan_result.warnings:
            confidence -= len(scan_result.warnings) * 0.1

        return max(0.0, min(1.0, confidence))

    def _validate_torrent_file_path(self, file_path: str) -> bool:
        """Проверка безопасности пути к торрент-файлу"""
        try:
            safe_path = safe_path_join(file_path)
            return safe_path.is_file() and safe_path.suffix.lower() == '.torrent'
        except Exception:
            return False

    def _has_path_traversal(self, path: str) -> bool:
        """Проверка на path traversal атаки"""
        traversal_patterns = [
            '../', '..\\', '~/', '~\\',
            '/etc/passwd', '/etc/shadow',
            'C:\\Windows\\System32'
        ]

        normalized_path = Path(path).as_posix().lower()
        return any(pattern in normalized_path for pattern in traversal_patterns)

    def _extract_domain_from_url(self, url: str) -> Optional[str]:
        """Извлечение домена из URL"""
        try:
            parsed = urllib.parse.urlparse(url)
            return parsed.hostname
        except Exception:
            return None

    def _extract_ip_from_url(self, url: str) -> Optional[str]:
        """Извлечение IP адреса из URL"""
        try:
            parsed = urllib.parse.urlparse(url)
            hostname = parsed.hostname

            if hostname and validate_ip_address(hostname):
                return hostname

            return None
        except Exception:
            return None

    def _calculate_file_hash(self, file_path: str) -> str:
        """Вычисление хеша файла"""
        try:
            hasher = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception as e:
            logger.error(f"Ошибка вычисления хеша файла {file_path}: {e}")
            return ""

    # Методы работы с черными списками

    def add_to_blacklist(self, identifier: str, entry_type: str,
                         reason: str, duration_hours: int = None) -> bool:
        """
        Добавление в черный список

        Args:
            identifier: Идентификатор (IP, хеш, домен, URL трекера)
            entry_type: Тип записи ('ip', 'hash', 'domain', 'tracker')
            reason: Причина добавления
            duration_hours: Длительность блокировки в часах

        Returns:
            Успешность операции
        """
        try:
            expires_at = None
            if duration_hours:
                expires_at = time.time() + (duration_hours * 3600)

            entry = BlacklistEntry(
                identifier=identifier,
                entry_type=entry_type,
                reason=reason,
                added_time=time.time(),
                expires_at=expires_at
            )

            with self._lock:
                if entry_type == 'ip':
                    self._ip_blacklist.add(identifier)
                elif entry_type == 'hash':
                    self._hash_blacklist.add(identifier)
                elif entry_type == 'domain':
                    self._domain_blacklist.add(identifier)
                elif entry_type == 'tracker':
                    self._tracker_blacklist.add(identifier)
                else:
                    raise SecurityError(f"Неизвестный тип записи: {entry_type}")

            # Сохранение в конфигурацию
            self._save_blacklists()

            logger.info(f"Добавлено в черный список: {identifier} ({entry_type}) - {reason}")
            return True

        except Exception as e:
            logger.error(f"Ошибка добавления в черный список: {e}")
            return False

    def remove_from_blacklist(self, identifier: str, entry_type: str) -> bool:
        """
        Удаление из черного списка

        Args:
            identifier: Идентификатор для удаления
            entry_type: Тип записи

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if entry_type == 'ip' and identifier in self._ip_blacklist:
                    self._ip_blacklist.remove(identifier)
                elif entry_type == 'hash' and identifier in self._hash_blacklist:
                    self._hash_blacklist.remove(identifier)
                elif entry_type == 'domain' and identifier in self._domain_blacklist:
                    self._domain_blacklist.remove(identifier)
                elif entry_type == 'tracker' and identifier in self._tracker_blacklist:
                    self._tracker_blacklist.remove(identifier)
                else:
                    return False

            # Сохранение в конфигурацию
            self._save_blacklists()

            logger.info(f"Удалено из черного списка: {identifier} ({entry_type})")
            return True

        except Exception as e:
            logger.error(f"Ошибка удаления из черного списка: {e}")
            return False

    def _is_ip_blacklisted(self, ip: str) -> bool:
        """Проверка IP в черном списке"""
        with self._lock:
            return ip in self._ip_blacklist

    def _is_hash_blacklisted(self, info_hash: str) -> bool:
        """Проверка хеша в черном списке"""
        with self._lock:
            return info_hash in self._hash_blacklist

    def _is_domain_blacklisted(self, domain: str) -> bool:
        """Проверка домена в черном списке"""
        with self._lock:
            return domain in self._domain_blacklist

    def _is_tracker_blacklisted(self, tracker_url: str) -> bool:
        """Проверка трекера в черном списке"""
        with self._lock:
            return tracker_url in self._tracker_blacklist

    def _is_hash_trusted(self, info_hash: str) -> bool:
        """Проверка хеша в белом списке"""
        with self._lock:
            return info_hash in self._trusted_hashes

    def _is_tracker_trusted(self, tracker_url: str) -> bool:
        """Проверка трекера в белом списке"""
        with self._lock:
            return tracker_url in self._trusted_trackers

    def _save_blacklists(self) -> None:
        """Сохранение черных списков в конфигурацию"""
        try:
            blacklists = {
                'ips': list(self._ip_blacklist),
                'hashes': list(self._hash_blacklist),
                'domains': list(self._domain_blacklist),
                'trackers': list(self._tracker_blacklist)
            }

            self.config_service.set('security.blacklists', blacklists)

        except Exception as e:
            logger.error(f"Ошибка сохранения черных списков: {e}")

    def _get_cached_result(self, cache_key: str) -> Optional[SecurityScanResult]:
        """Получение результата из кэша"""
        try:
            with self._lock:
                if (cache_key in self._scan_cache and
                        cache_key in self._cache_ttl and
                        time.time() - self._cache_ttl[cache_key] < 3600):  # 1 час TTL
                    return self._scan_cache[cache_key]
                else:
                    # Удаление устаревших записей
                    if cache_key in self._scan_cache:
                        del self._scan_cache[cache_key]
                    if cache_key in self._cache_ttl:
                        del self._cache_ttl[cache_key]
            return None
        except Exception as e:
            logger.debug(f"Ошибка получения из кэша: {e}")
            return None

    def _cache_result(self, cache_key: str, result: SecurityScanResult) -> None:
        """Сохранение результата в кэш"""
        try:
            with self._lock:
                self._scan_cache[cache_key] = result
                self._cache_ttl[cache_key] = time.time()
        except Exception as e:
            logger.debug(f"Ошибка сохранения в кэш: {e}")

    def _update_stats(self, result: SecurityScanResult) -> None:
        """Обновление статистики проверок"""
        with self._lock:
            self._scan_stats['total_scans'] += 1
            if result.threats:
                self._scan_stats['threats_detected'] += 1

    def get_security_stats(self) -> Dict[str, Any]:
        """Получение статистики безопасности"""
        with self._lock:
            stats = self._scan_stats.copy()
            stats.update({
                'ip_blacklist_size': len(self._ip_blacklist),
                'hash_blacklist_size': len(self._hash_blacklist),
                'domain_blacklist_size': len(self._domain_blacklist),
                'tracker_blacklist_size': len(self._tracker_blacklist),
                'cache_size': len(self._scan_cache)
            })
            return stats

    def clear_cache(self) -> None:
        """Очистка кэша проверок"""
        with self._lock:
            self._scan_cache.clear()
            self._cache_ttl.clear()
        logger.info("Кэш безопасности очищен")

    def validate_download_path(self, path: str) -> Tuple[bool, str]:
        """
        Проверка безопасности пути для загрузки

        Args:
            path: Путь для проверки

        Returns:
            (Успешность, сообщение об ошибке)
        """
        try:
            safe_path = safe_path_join(path)

            # Проверка на системные директории
            system_dirs = [
                '/etc', '/bin', '/sbin', '/usr', '/var', '/lib',
                'C:\\Windows', 'C:\\Program Files', 'C:\\System32'
            ]

            path_str = str(safe_path).lower()
            for system_dir in system_dirs:
                if system_dir.lower() in path_str:
                    return False, f"Путь находится в системной директории: {system_dir}"

            # Проверка прав доступа
            if not safe_path.parent.exists():
                return False, f"Родительская директория не существует: {safe_path.parent}"

            if not os.access(safe_path.parent, os.W_OK):
                return False, f"Нет прав на запись в директорию: {safe_path.parent}"

            return True, "Путь безопасен"

        except Exception as e:
            return False, f"Ошибка проверки пути: {e}"

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы SecurityService...")

        # Сохранение черных списков
        self._save_blacklists()

        # Очистка кэша
        self.clear_cache()

        # Очистка структур
        with self._lock:
            self._ip_blacklist.clear()
            self._hash_blacklist.clear()
            self._domain_blacklist.clear()
            self._tracker_blacklist.clear()
            self._trusted_trackers.clear()
            self._trusted_hashes.clear()
            self._malware_patterns.clear()
            self._suspicious_extensions.clear()

        logger.info("SecurityService завершен")


# Вспомогательные функции
import time
import os


def time() -> float:
    """Получение текущего времени (для переопределения в тестах)"""
    return time.time()