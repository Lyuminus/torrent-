"""
INTEGRATION SERVICE - Сервис внешних интеграций

Отвечает за интеграцию с внешними системами: уведомления, медиа-серверы,
сторонние API, экспорт данных. Обеспечивает унифицированный интерфейс
для всех внешних взаимодействий.
"""

import logging
import smtplib
import requests
import json
import time
from typing import Dict, List, Optional, Any, Union, Callable
from threading import RLock, Thread
from dataclasses import dataclass, asdict, field
from enum import Enum
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import socket
import platform

from ..models.exceptions import IntegrationError
from ..utils.formatters import format_size, format_speed, format_duration

logger = logging.getLogger(__name__)


class NotificationType(Enum):
    """Типы уведомлений"""
    TORRENT_ADDED = "torrent_added"
    TORRENT_COMPLETED = "torrent_completed"
    TORRENT_ERROR = "torrent_error"
    DOWNLOAD_SPEED_LOW = "download_speed_low"
    DISK_SPACE_LOW = "disk_space_low"
    AUTOMATION_RULE_TRIGGERED = "automation_rule_triggered"
    SYSTEM_STARTUP = "system_startup"
    SYSTEM_SHUTDOWN = "system_shutdown"
    CUSTOM = "custom"


class MediaServerType(Enum):
    """Типы медиа-серверов"""
    PLEX = "plex"
    JELLYFIN = "jellyfin"
    EMBY = "emby"
    KODI = "kodi"


@dataclass
class NotificationConfig:
    """Конфигурация уведомлений"""
    enabled: bool = False
    email_enabled: bool = False
    push_enabled: bool = False
    desktop_enabled: bool = False
    webhook_enabled: bool = False

    # Email настройки
    smtp_server: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    email_from: str = ""
    email_to: str = ""

    # Push настройки (Pushbullet, Pushover и т.д.)
    push_service: str = ""
    push_token: str = ""
    push_user_key: str = ""

    # Webhook настройки
    webhook_url: str = ""
    webhook_headers: Dict[str, str] = field(default_factory=dict)

    # Шаблоны сообщений
    message_templates: Dict[str, str] = field(default_factory=dict)


@dataclass
class MediaServerConfig:
    """Конфигурация медиа-сервера"""
    server_type: MediaServerType
    enabled: bool = False
    base_url: str = ""
    api_key: str = ""
    username: str = ""
    password: str = ""
    library_paths: List[str] = field(default_factory=list)
    auto_scan: bool = False
    scan_delay: int = 30  # Задержка перед сканированием в секундах


@dataclass
class WebhookConfig:
    """Конфигурация вебхука"""
    name: str
    url: str
    enabled: bool = True
    headers: Dict[str, str] = field(default_factory=dict)
    template: str = ""
    events: List[str] = field(default_factory=list)
    timeout: int = 30


class IntegrationService:
    """
    Сервис интеграций с внешними системами
    """

    def __init__(self, config_service):
        self.config_service = config_service

        # Потокобезопасные структуры
        self._lock = RLock()
        self._notification_config: Optional[NotificationConfig] = None
        self._media_servers: Dict[str, MediaServerConfig] = {}
        self._webhooks: Dict[str, WebhookConfig] = {}

        # Очередь уведомлений
        self._notification_queue: List[Dict[str, Any]] = []
        self._notification_worker_running = False
        self._notification_thread: Optional[Thread] = None

        # Кэш состояний
        self._server_status: Dict[str, bool] = {}
        self._last_notification_time: Dict[str, float] = {}

        # Инициализация
        self._load_configurations()
        self._start_notification_worker()

        logger.info("IntegrationService инициализирован")

    def _load_configurations(self) -> None:
        """Загрузка конфигураций интеграций"""
        try:
            # Загрузка конфигурации уведомлений
            notification_data = self.config_service.get('integrations.notifications', {})
            self._notification_config = NotificationConfig(**notification_data)

            # Загрузка медиа-серверов
            media_servers_data = self.config_service.get('integrations.media_servers', {})
            for server_id, server_data in media_servers_data.items():
                server_data['server_type'] = MediaServerType(server_data['server_type'])
                self._media_servers[server_id] = MediaServerConfig(**server_data)

            # Загрузка вебхуков
            webhooks_data = self.config_service.get('integrations.webhooks', {})
            for webhook_id, webhook_data in webhooks_data.items():
                self._webhooks[webhook_id] = WebhookConfig(**webhook_data)

            logger.info(f"Загружено интеграций: {len(self._media_servers)} медиа-серверов, "
                        f"{len(self._webhooks)} вебхуков")

        except Exception as e:
            logger.error(f"Ошибка загрузки конфигураций интеграций: {e}")

    def _save_configurations(self) -> None:
        """Сохранение конфигураций интеграций"""
        try:
            # Сохранение уведомлений
            if self._notification_config:
                self.config_service.set(
                    'integrations.notifications',
                    asdict(self._notification_config)
                )

            # Сохранение медиа-серверов
            media_servers_data = {
                server_id: asdict(config)
                for server_id, config in self._media_servers.items()
            }
            self.config_service.set('integrations.media_servers', media_servers_data)

            # Сохранение вебхуков
            webhooks_data = {
                webhook_id: asdict(config)
                for webhook_id, config in self._webhooks.items()
            }
            self.config_service.set('integrations.webhooks', webhooks_data)

            logger.debug("Конфигурации интеграций сохранены")

        except Exception as e:
            logger.error(f"Ошибка сохранения конфигураций интеграций: {e}")

    def _start_notification_worker(self) -> None:
        """Запуск фонового обработчика уведомлений"""

        def notification_worker():
            logger.info("Обработчик уведомлений запущен")

            while self._notification_worker_running:
                try:
                    # Обработка очереди уведомлений
                    if self._notification_queue:
                        notification = self._notification_queue.pop(0)
                        self._process_notification(notification)

                    time.sleep(1)  # Проверка каждую секунду

                except Exception as e:
                    logger.error(f"Ошибка в обработчике уведомлений: {e}")
                    time.sleep(5)

            logger.info("Обработчик уведомлений остановлен")

        self._notification_worker_running = True
        self._notification_thread = Thread(
            target=notification_worker,
            daemon=True,
            name="NotificationWorker"
        )
        self._notification_thread.start()

    def send_notification(self, notification_type: NotificationType,
                          title: str, message: str, data: Dict[str, Any] = None) -> bool:
        """
        Отправка уведомления

        Args:
            notification_type: Тип уведомления
            title: Заголовок уведомления
            message: Текст уведомления
            data: Дополнительные данные

        Returns:
            Успешность постановки в очередь
        """
        try:
            if not self._notification_config or not self._notification_config.enabled:
                return False

            # Проверка частоты уведомлений (анти-спам)
            notification_key = f"{notification_type.value}_{title}"
            current_time = time.time()

            if notification_key in self._last_notification_time:
                time_since_last = current_time - self._last_notification_time[notification_key]
                if time_since_last < 300:  # 5 минут между одинаковыми уведомлениями
                    logger.debug(f"Уведомление подавлено (анти-спам): {title}")
                    return False

            self._last_notification_time[notification_key] = current_time

            # Создание уведомления
            notification = {
                'type': notification_type,
                'title': title,
                'message': message,
                'data': data or {},
                'timestamp': current_time,
                'attempts': 0
            }

            # Добавление в очередь
            with self._lock:
                self._notification_queue.append(notification)

            logger.debug(f"Уведомление добавлено в очередь: {title}")
            return True

        except Exception as e:
            logger.error(f"Ошибка создания уведомления: {e}")
            return False

    def _process_notification(self, notification: Dict[str, Any]) -> None:
        """Обработка уведомления из очереди"""
        try:
            notification['attempts'] += 1

            success_count = 0
            total_methods = 0

            # Отправка email
            if (self._notification_config.email_enabled and
                    self._notification_config.smtp_server):
                total_methods += 1
                if self._send_email_notification(notification):
                    success_count += 1

            # Отправка push-уведомлений
            if self._notification_config.push_enabled:
                total_methods += 1
                if self._send_push_notification(notification):
                    success_count += 1

            # Desktop уведомления
            if self._notification_config.desktop_enabled:
                total_methods += 1
                if self._send_desktop_notification(notification):
                    success_count += 1

            # Webhook уведомления
            if self._notification_config.webhook_enabled:
                total_methods += 1
                if self._send_webhook_notification(notification):
                    success_count += 1

            # Логирование результата
            if success_count > 0:
                logger.info(f"Уведомление отправлено: {notification['title']} "
                            f"({success_count}/{total_methods} методов)")
            else:
                logger.warning(f"Не удалось отправить уведомление: {notification['title']}")

                # Повторная попытка если не превышен лимит
                if notification['attempts'] < 3:
                    with self._lock:
                        self._notification_queue.append(notification)
                    logger.debug(f"Уведомление возвращено в очередь: {notification['title']}")

        except Exception as e:
            logger.error(f"Ошибка обработки уведомления: {e}")

    def _send_email_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка email уведомления"""
        try:
            config = self._notification_config

            # Создание сообщения
            msg = MIMEMultipart()
            msg['From'] = config.email_from
            msg['To'] = config.email_to
            msg['Subject'] = notification['title']

            # Форматирование тела сообщения
            body = self._format_notification_message(notification, 'email')
            msg.attach(MIMEText(body, 'plain', 'utf-8'))

            # Отправка
            with smtplib.SMTP(config.smtp_server, config.smtp_port) as server:
                server.starttls()
                if config.smtp_username and config.smtp_password:
                    server.login(config.smtp_username, config.smtp_password)
                server.send_message(msg)

            logger.debug(f"Email уведомление отправлено: {notification['title']}")
            return True

        except Exception as e:
            logger.error(f"Ошибка отправки email уведомления: {e}")
            return False

    def _send_push_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка push уведомления"""
        try:
            config = self._notification_config

            if config.push_service == "pushbullet":
                return self._send_pushbullet_notification(notification)
            elif config.push_service == "pushover":
                return self._send_pushover_notification(notification)
            else:
                logger.warning(f"Неизвестный push сервис: {config.push_service}")
                return False

        except Exception as e:
            logger.error(f"Ошибка отправки push уведомления: {e}")
            return False

    def _send_pushbullet_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка уведомления через Pushbullet"""
        try:
            config = self._notification_config

            payload = {
                'type': 'note',
                'title': notification['title'],
                'body': self._format_notification_message(notification, 'push')
            }

            headers = {
                'Access-Token': config.push_token,
                'Content-Type': 'application/json'
            }

            response = requests.post(
                'https://api.pushbullet.com/v2/pushes',
                json=payload,
                headers=headers,
                timeout=30
            )

            response.raise_for_status()
            logger.debug(f"Pushbullet уведомление отправлено: {notification['title']}")
            return True

        except Exception as e:
            logger.error(f"Ошибка отправки Pushbullet уведомления: {e}")
            return False

    def _send_pushover_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка уведомления через Pushover"""
        try:
            config = self._notification_config

            payload = {
                'token': config.push_token,
                'user': config.push_user_key,
                'title': notification['title'],
                'message': self._format_notification_message(notification, 'push'),
                'priority': 0  # Нормальный приоритет
            }

            response = requests.post(
                'https://api.pushover.net/1/messages.json',
                data=payload,
                timeout=30
            )

            response.raise_for_status()
            logger.debug(f"Pushover уведомление отправлено: {notification['title']}")
            return True

        except Exception as e:
            logger.error(f"Ошибка отправки Pushover уведомления: {e}")
            return False

    def _send_desktop_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка desktop уведомления"""
        try:
            # Определение платформы
            system = platform.system().lower()

            if system == 'windows':
                return self._send_windows_notification(notification)
            elif system == 'darwin':  # macOS
                return self._send_macos_notification(notification)
            elif system == 'linux':
                return self._send_linux_notification(notification)
            else:
                logger.warning(f"Desktop уведомления не поддерживаются на {system}")
                return False

        except Exception as e:
            logger.error(f"Ошибка отправки desktop уведомления: {e}")
            return False

    def _send_windows_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка уведомления на Windows"""
        try:
            from win10toast import ToastNotifier

            toaster = ToastNotifier()
            toaster.show_toast(
                notification['title'],
                notification['message'],
                duration=10,
                threaded=True
            )

            logger.debug(f"Windows уведомление отправлено: {notification['title']}")
            return True

        except ImportError:
            logger.warning("Библиотека win10toast не установлена")
            return False
        except Exception as e:
            logger.error(f"Ошибка отправки Windows уведомления: {e}")
            return False

    def _send_macos_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка уведомления на macOS"""
        try:
            import subprocess

            script = f'display notification "{notification["message"]}" with title "{notification["title"]}"'
            subprocess.run(['osascript', '-e', script], check=True)

            logger.debug(f"macOS уведомление отправлено: {notification['title']}")
            return True

        except Exception as e:
            logger.error(f"Ошибка отправки macOS уведомления: {e}")
            return False

    def _send_linux_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка уведомления на Linux"""
        try:
            import subprocess

            # Проверка наличия notify-send
            subprocess.run(['which', 'notify-send'], check=True, capture_output=True)

            subprocess.run([
                'notify-send',
                notification['title'],
                notification['message'],
                '-t', '10000'  # 10 секунд
            ], check=True)

            logger.debug(f"Linux уведомление отправлено: {notification['title']}")
            return True

        except Exception as e:
            logger.error(f"Ошибка отправки Linux уведомления: {e}")
            return False

    def _send_webhook_notification(self, notification: Dict[str, Any]) -> bool:
        """Отправка уведомления через webhook"""
        try:
            config = self._notification_config

            payload = {
                'type': notification['type'].value,
                'title': notification['title'],
                'message': notification['message'],
                'timestamp': notification['timestamp'],
                'data': notification['data']
            }

            response = requests.post(
                config.webhook_url,
                json=payload,
                headers=config.webhook_headers,
                timeout=30
            )

            response.raise_for_status()
            logger.debug(f"Webhook уведомление отправлено: {notification['title']}")
            return True

        except Exception as e:
            logger.error(f"Ошибка отправки webhook уведомления: {e}")
            return False

    def _format_notification_message(self, notification: Dict[str, Any],
                                     format_type: str) -> str:
        """Форматирование сообщения уведомления"""
        try:
            # Использование кастомного шаблона если есть
            config = self._notification_config
            template_key = f"{notification['type'].value}_{format_type}"

            if (config.message_templates and
                    template_key in config.message_templates):
                template = config.message_templates[template_key]
            else:
                # Стандартный шаблон
                template = "{title}\n\n{message}\n\nВремя: {timestamp}"

            # Замена переменных
            message = template.format(
                title=notification['title'],
                message=notification['message'],
                timestamp=datetime.fromtimestamp(notification['timestamp']).strftime('%Y-%m-%d %H:%M:%S'),
                type=notification['type'].value,
                **notification.get('data', {})
            )

            return message

        except Exception as e:
            logger.error(f"Ошибка форматирования сообщения: {e}")
            return f"{notification['title']}\n{notification['message']}"

    # Медиа-серверы

    def add_media_server(self, server_id: str, config: MediaServerConfig) -> bool:
        """
        Добавление медиа-сервера

        Args:
            server_id: ID сервера
            config: Конфигурация сервера

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                self._media_servers[server_id] = config
                self._save_configurations()

            logger.info(f"Добавлен медиа-сервер: {server_id} ({config.server_type.value})")
            return True

        except Exception as e:
            logger.error(f"Ошибка добавления медиа-сервера: {e}")
            return False

    def test_media_server_connection(self, server_id: str) -> Dict[str, Any]:
        """
        Тестирование подключения к медиа-серверу

        Args:
            server_id: ID сервера

        Returns:
            Результат тестирования
        """
        try:
            with self._lock:
                config = self._media_servers.get(server_id)
                if not config:
                    raise IntegrationError(f"Медиа-сервер {server_id} не найден")

            result = {
                'server_id': server_id,
                'server_type': config.server_type.value,
                'success': False,
                'response_time': 0,
                'error': None,
                'details': {}
            }

            start_time = time.time()

            if config.server_type == MediaServerType.PLEX:
                connection_result = self._test_plex_connection(config)
            elif config.server_type == MediaServerType.JELLYFIN:
                connection_result = self._test_jellyfin_connection(config)
            elif config.server_type == MediaServerType.EMBY:
                connection_result = self._test_emby_connection(config)
            elif config.server_type == MediaServerType.KODI:
                connection_result = self._test_kodi_connection(config)
            else:
                raise IntegrationError(f"Неизвестный тип сервера: {config.server_type}")

            result['response_time'] = time.time() - start_time
            result.update(connection_result)

            # Обновление статуса
            self._server_status[server_id] = result['success']

            return result

        except Exception as e:
            logger.error(f"Ошибка тестирования медиа-сервера {server_id}: {e}")
            return {
                'server_id': server_id,
                'success': False,
                'error': str(e),
                'response_time': 0
            }

    def _test_plex_connection(self, config: MediaServerConfig) -> Dict[str, Any]:
        """Тестирование подключения к Plex"""
        try:
            headers = {'X-Plex-Token': config.api_key}
            response = requests.get(
                f"{config.base_url}/status/sessions",
                headers=headers,
                timeout=10
            )

            response.raise_for_status()

            return {
                'success': True,
                'details': {
                    'version': response.headers.get('X-Plex-Version', 'Unknown'),
                    'server_name': 'Plex Media Server'
                }
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def _test_jellyfin_connection(self, config: MediaServerConfig) -> Dict[str, Any]:
        """Тестирование подключения к Jellyfin"""
        try:
            headers = {'X-Emby-Token': config.api_key}
            response = requests.get(
                f"{config.base_url}/System/Info",
                headers=headers,
                timeout=10
            )

            response.raise_for_status()
            data = response.json()

            return {
                'success': True,
                'details': {
                    'version': data.get('Version', 'Unknown'),
                    'server_name': data.get('ServerName', 'Jellyfin')
                }
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def _test_emby_connection(self, config: MediaServerConfig) -> Dict[str, Any]:
        """Тестирование подключения к Emby"""
        try:
            headers = {'X-Emby-Token': config.api_key}
            response = requests.get(
                f"{config.base_url}/System/Info",
                headers=headers,
                timeout=10
            )

            response.raise_for_status()
            data = response.json()

            return {
                'success': True,
                'details': {
                    'version': data.get('Version', 'Unknown'),
                    'server_name': data.get('ServerName', 'Emby')
                }
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def _test_kodi_connection(self, config: MediaServerConfig) -> Dict[str, Any]:
        """Тестирование подключения к Kodi"""
        try:
            payload = {
                'jsonrpc': '2.0',
                'method': 'JSONRPC.Ping',
                'id': 1
            }

            auth = None
            if config.username and config.password:
                auth = (config.username, config.password)

            response = requests.post(
                f"{config.base_url}/jsonrpc",
                json=payload,
                auth=auth,
                timeout=10
            )

            response.raise_for_status()
            data = response.json()

            return {
                'success': True,
                'details': {
                    'version': data.get('result', 'Unknown'),
                    'server_name': 'Kodi'
                }
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def notify_media_servers(self, file_path: str, server_ids: List[str] = None) -> Dict[str, Any]:
        """
        Уведомление медиа-серверов о новых файлах

        Args:
            file_path: Путь к новому файлу
            server_ids: Список ID серверов (все если None)

        Returns:
            Результаты уведомления
        """
        try:
            results = {}

            with self._lock:
                servers_to_notify = []
                if server_ids:
                    for server_id in server_ids:
                        if server_id in self._media_servers:
                            servers_to_notify.append((server_id, self._media_servers[server_id]))
                else:
                    servers_to_notify = list(self._media_servers.items())

            for server_id, config in servers_to_notify:
                if not config.enabled or not config.auto_scan:
                    continue

                try:
                    # Задержка если указана
                    if config.scan_delay > 0:
                        time.sleep(config.scan_delay)

                    if config.server_type == MediaServerType.PLEX:
                        result = self._scan_plex_library(config, file_path)
                    elif config.server_type == MediaServerType.JELLYFIN:
                        result = self._scan_jellyfin_library(config, file_path)
                    elif config.server_type == MediaServerType.EMBY:
                        result = self._scan_emby_library(config, file_path)
                    elif config.server_type == MediaServerType.KODI:
                        result = self._scan_kodi_library(config, file_path)
                    else:
                        result = {'success': False, 'error': 'Unknown server type'}

                    results[server_id] = result

                except Exception as e:
                    results[server_id] = {'success': False, 'error': str(e)}

            return results

        except Exception as e:
            logger.error(f"Ошибка уведомления медиа-серверов: {e}")
            return {}

    def _scan_plex_library(self, config: MediaServerConfig, file_path: str) -> Dict[str, Any]:
        """Сканирование библиотеки Plex"""
        try:
            headers = {'X-Plex-Token': config.api_key}

            # Поиск подходящей библиотеки по пути
            response = requests.get(
                f"{config.base_url}/library/sections",
                headers=headers,
                timeout=30
            )
            response.raise_for_status()

            # Здесь должна быть логика определения нужной библиотеки
            # Упрощенная реализация - сканируем все библиотеки
            import xml.etree.ElementTree as ET
            root = ET.fromstring(response.content)

            for section in root.findall('Directory'):
                section_id = section.get('key')

                # Запрос на сканирование
                scan_response = requests.get(
                    f"{config.base_url}/library/sections/{section_id}/refresh",
                    headers=headers,
                    timeout=30
                )
                scan_response.raise_for_status()

            return {'success': True, 'message': 'Plex libraries scanned'}

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def _scan_jellyfin_library(self, config: MediaServerConfig, file_path: str) -> Dict[str, Any]:
        """Сканирование библиотеки Jellyfin"""
        try:
            headers = {'X-Emby-Token': config.api_key}

            response = requests.post(
                f"{config.base_url}/Library/Refresh",
                headers=headers,
                timeout=30
            )
            response.raise_for_status()

            return {'success': True, 'message': 'Jellyfin library scanned'}

        except Exception as e:
            return {'success': False, 'error': str(e)}

    # Вебхуки

    def add_webhook(self, webhook_id: str, config: WebhookConfig) -> bool:
        """
        Добавление вебхука

        Args:
            webhook_id: ID вебхука
            config: Конфигурация вебхука

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                self._webhooks[webhook_id] = config
                self._save_configurations()

            logger.info(f"Добавлен вебхук: {webhook_id}")
            return True

        except Exception as e:
            logger.error(f"Ошибка добавления вебхука: {e}")
            return False

    def trigger_webhook(self, webhook_id: str, data: Dict[str, Any]) -> bool:
        """
        Активация вебхука

        Args:
            webhook_id: ID вебхука
            data: Данные для отправки

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                webhook = self._webhooks.get(webhook_id)
                if not webhook or not webhook.enabled:
                    return False

            # Форматирование данных
            if webhook.template:
                payload = self._format_webhook_payload(webhook.template, data)
            else:
                payload = data

            # Отправка
            response = requests.post(
                webhook.url,
                json=payload,
                headers=webhook.headers,
                timeout=webhook.timeout
            )

            response.raise_for_status()

            logger.debug(f"Вебхук активирован: {webhook_id}")
            return True

        except Exception as e:
            logger.error(f"Ошибка активации вебхука {webhook_id}: {e}")
            return False

    def _format_webhook_payload(self, template: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Форматирование данных вебхука по шаблону"""
        try:
            # Простая замена переменных в JSON шаблоне
            formatted_template = template

            for key, value in data.items():
                placeholder = f'${{{key}}}'
                if isinstance(value, (dict, list)):
                    # Для сложных структур используем JSON сериализацию
                    formatted_value = json.dumps(value, ensure_ascii=False)
                else:
                    formatted_value = str(value)

                formatted_template = formatted_template.replace(placeholder, formatted_value)

            return json.loads(formatted_template)

        except Exception as e:
            logger.error(f"Ошибка форматирования вебхука: {e}")
            return data

    # Экспорт данных

    def export_data(self, data_type: str, export_path: str,
                    options: Dict[str, Any] = None) -> bool:
        """
        Экспорт данных в различные форматы

        Args:
            data_type: Тип данных (torrents, history, statistics, etc.)
            export_path: Путь для экспорта
            options: Дополнительные опции

        Returns:
            Успешность операции
        """
        try:
            options = options or {}
            format_type = options.get('format', 'json')

            if data_type == 'torrents':
                return self._export_torrents_data(export_path, format_type, options)
            elif data_type == 'history':
                return self._export_history_data(export_path, format_type, options)
            elif data_type == 'statistics':
                return self._export_statistics_data(export_path, format_type, options)
            else:
                raise IntegrationError(f"Неизвестный тип данных: {data_type}")

        except Exception as e:
            logger.error(f"Ошибка экспорта данных {data_type}: {e}")
            return False

    def _export_torrents_data(self, export_path: str, format_type: str,
                              options: Dict[str, Any]) -> bool:
        """Экспорт данных о торрентах"""
        try:
            # Здесь будет интеграция с TorrentManager
            # Временная заглушка
            export_data = {
                'export_time': datetime.now().isoformat(),
                'data_type': 'torrents',
                'torrents': []  # Будет заполнено из TorrentManager
            }

            with open(export_path, 'w', encoding='utf-8') as f:
                if format_type == 'json':
                    json.dump(export_data, f, indent=2, ensure_ascii=False)
                elif format_type == 'csv':
                    # Конвертация в CSV
                    import csv
                    # Заглушка для CSV экспорта
                    pass

            logger.info(f"Данные торрентов экспортированы: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта данных торрентов: {e}")
            return False

    def _export_history_data(self, export_path: str, format_type: str,
                             options: Dict[str, Any]) -> bool:
        """Экспорт исторических данных"""
        try:
            # Интеграция с HistoryService
            export_data = {
                'export_time': datetime.now().isoformat(),
                'data_type': 'history',
                'history': []  # Будет заполнено из HistoryService
            }

            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Исторические данные экспортированы: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта исторических данных: {e}")
            return False

    def _export_statistics_data(self, export_path: str, format_type: str,
                                options: Dict[str, Any]) -> bool:
        """Экспорт статистических данных"""
        try:
            # Интеграция со StatisticsEngine
            export_data = {
                'export_time': datetime.now().isoformat(),
                'data_type': 'statistics',
                'statistics': {}  # Будет заполнено из StatisticsEngine
            }

            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Статистические данные экспортированы: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта статистических данных: {e}")
            return False

    def get_integration_status(self) -> Dict[str, Any]:
        """Получение статуса всех интеграций"""
        with self._lock:
            status = {
                'notifications': {
                    'enabled': self._notification_config.enabled if self._notification_config else False,
                    'email_enabled': self._notification_config.email_enabled if self._notification_config else False,
                    'push_enabled': self._notification_config.push_enabled if self._notification_config else False,
                    'desktop_enabled': self._notification_config.desktop_enabled if self._notification_config else False,
                    'webhook_enabled': self._notification_config.webhook_enabled if self._notification_config else False,
                    'queue_size': len(self._notification_queue)
                },
                'media_servers': {},
                'webhooks': {}
            }

            # Статус медиа-серверов
            for server_id, config in self._media_servers.items():
                status['media_servers'][server_id] = {
                    'type': config.server_type.value,
                    'enabled': config.enabled,
                    'connected': self._server_status.get(server_id, False),
                    'auto_scan': config.auto_scan
                }

            # Статус вебхуков
            for webhook_id, config in self._webhooks.items():
                status['webhooks'][webhook_id] = {
                    'enabled': config.enabled,
                    'url': config.url,
                    'events': config.events
                }

            return status

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы IntegrationService...")

        # Остановка обработчика уведомлений
        self._notification_worker_running = False

        if self._notification_thread and self._notification_thread.is_alive():
            self._notification_thread.join(timeout=5)

        # Сохранение конфигураций
        self._save_configurations()

        # Очистка структур
        with self._lock:
            self._notification_queue.clear()
            self._media_servers.clear()
            self._webhooks.clear()
            self._server_status.clear()
            self._last_notification_time.clear()

        logger.info("IntegrationService завершен")