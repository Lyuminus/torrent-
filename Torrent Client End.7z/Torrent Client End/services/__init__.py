"""
SERVICES MODULE - Сервисный слой торрент-клиента

Содержит высокоуровневые сервисы для управления конфигурацией, историей,
безопасностью, автоматизацией и интеграциями. Обеспечивает бизнес-логику
и координацию между компонентами ядра.
"""

__version__ = "8.0"
__author__ = "Torrent Client Team"

from .config_service import ConfigService
from .history_service import HistoryService
from .security_service import SecurityService
from .automation_service import AutomationService, AutomationRule, TriggerType, ActionType
from .integration_service import IntegrationService


# Сервисные исключения
class ServiceError(Exception):
    """Базовое исключение для ошибок сервисов"""
    pass


class ConfigError(ServiceError):
    """Ошибка конфигурации"""
    pass


class HistoryError(ServiceError):
    """Ошибка работы с историей"""
    pass


class SecurityError(ServiceError):
    """Ошибка безопасности"""
    pass


class AutomationError(ServiceError):
    """Ошибка автоматизации"""
    pass


class IntegrationError(ServiceError):
    """Ошибка интеграции"""
    pass


# Экспорт основных классов для удобного импорта
__all__ = [
    # Сервисы
    'ConfigService',
    'HistoryService',
    'SecurityService',
    'AutomationService',
    'IntegrationService',

    # Автоматизация
    'AutomationRule',
    'TriggerType',
    'ActionType',

    # Исключения
    'ServiceError',
    'ConfigError',
    'HistoryError',
    'SecurityError',
    'AutomationError',
    'IntegrationError'
]

# Инициализация логгера для services модуля
import logging

logger = logging.getLogger(__name__)


def init_services(core_components: dict, config: dict) -> dict:
    """
    Инициализация всех сервисов

    Args:
        core_components: Словарь с компонентами ядра
        config: Конфигурация приложения

    Returns:
        Словарь с инициализированными сервисами
    """
    logger.info("Инициализация сервисного слоя...")

    services = {}

    try:
        # Инициализация сервиса конфигурации
        services['config'] = ConfigService(config)
        logger.info("✓ ConfigService инициализирован")

        # Инициализация сервиса истории
        services['history'] = HistoryService(services['config'])
        logger.info("✓ HistoryService инициализирован")

        # Инициализация сервиса безопасности
        services['security'] = SecurityService(services['config'])
        logger.info("✓ SecurityService инициализирован")

        # Инициализация сервиса автоматизации
        services['automation'] = AutomationService(
            services['config'],
            services['history']
        )
        logger.info("✓ AutomationService инициализирован")

        # Инициализация сервиса интеграций
        services['integration'] = IntegrationService(services['config'])
        logger.info("✓ IntegrationService инициализирован")

        logger.info("Все сервисы успешно инициализированы")

    except Exception as e:
        logger.error(f"Ошибка инициализации сервисов: {e}")
        raise ServiceError(f"Не удалось инициализировать сервисы: {e}")

    return services


def shutdown_services(services: dict) -> None:
    """
    Корректное завершение работы всех сервисов

    Args:
        services: Словарь с сервисами
    """
    logger.info("Завершение работы сервисного слоя...")

    shutdown_order = [
        'integration',
        'automation',
        'security',
        'history',
        'config'
    ]

    for service_name in shutdown_order:
        if service_name in services:
            try:
                service = services[service_name]
                if hasattr(service, 'shutdown'):
                    service.shutdown()
                logger.info(f"✓ {service_name} завершен")
            except Exception as e:
                logger.error(f"Ошибка завершения {service_name}: {e}")

    logger.info("Все сервисы завершены")