"""
CONFIG SERVICE - Сервис управления конфигурацией

Отвечает за загрузку, сохранение, валидацию и миграцию конфигурации приложения.
Обеспечивает централизованное управление настройками, категориями и профилями.
Поддерживает версионность и автоматическую миграцию конфигураций.
"""

import json
import logging
import shutil
from typing import Dict, Any, List, Optional, Union
from pathlib import Path
from threading import RLock
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib

from ..models.exceptions import ConfigError
from ..utils.validators import validate_path, safe_path_join

logger = logging.getLogger(__name__)


class ConfigVersion(Enum):
    """Версии конфигурации"""
    V8_0 = "8.0"
    V8_1 = "8.1"
    LATEST = V8_1


@dataclass
class CategoryConfig:
    """Конфигурация категории"""
    name: str
    folder: str
    color: str
    download_limit: int = 0
    upload_limit: int = 0
    max_downloads: int = 5
    auto_management: bool = True


@dataclass
class NetworkConfig:
    """Сетевая конфигурация"""
    listen_port: int = 6881
    enable_dht: bool = True
    enable_upnp: bool = True
    enable_lsd: bool = True
    enable_natpmp: bool = True
    max_connections: int = 200
    max_uploads: int = 10
    download_rate_limit: int = 0
    upload_rate_limit: int = 0
    proxy_host: str = ""
    proxy_port: int = 0
    proxy_username: str = ""
    proxy_password: str = ""


@dataclass
class PerformanceConfig:
    """Конфигурация производительности"""
    cache_size: int = 512
    file_pool_size: int = 40
    checking_mem_usage: int = 256
    max_downloads: int = 5
    seed_ratio: float = 2.0
    auto_manage_interval: int = 30
    refresh_interval: int = 1


@dataclass
class UIConfig:
    """Конфигурация интерфейса"""
    theme: str = "default"
    language: str = "ru"
    default_category: str = "default"
    auto_start: bool = False
    notifications: bool = True
    sound_notifications: bool = False
    start_minimized: bool = False
    update_check: bool = True


class ConfigService:
    """
    Сервис управления конфигурацией с поддержкой миграций и валидации
    """

    def __init__(self, initial_config: Dict[str, Any] = None):
        self._lock = RLock()
        self._config: Dict[str, Any] = {}
        self._original_config: Dict[str, Any] = {}
        self._config_file: Optional[Path] = None
        self._backup_dir: Optional[Path] = None

        # Пути к файлам конфигурации
        self._categories_file: Optional[Path] = None
        self._profiles_dir: Optional[Path] = None

        # Кэш для быстрого доступа
        self._categories_cache: Dict[str, CategoryConfig] = {}
        self._network_config_cache: Optional[NetworkConfig] = None
        self._performance_config_cache: Optional[PerformanceConfig] = None
        self._ui_config_cache: Optional[UIConfig] = None

        # Инициализация
        self._initialize_paths()
        self._load_configuration(initial_config or {})

        logger.info("ConfigService инициализирован")

    def _initialize_paths(self) -> None:
        """Инициализация путей для конфигурации"""
        try:
            # Основная директория конфигурации
            config_dir = Path.home() / ".torrent_client"
            config_dir.mkdir(exist_ok=True)

            # Файлы конфигурации
            self._config_file = config_dir / "config.json"
            self._categories_file = config_dir / "categories.json"
            self._profiles_dir = config_dir / "profiles"
            self._backup_dir = config_dir / "backups"

            # Создание необходимых директорий
            self._profiles_dir.mkdir(exist_ok=True)
            self._backup_dir.mkdir(exist_ok=True)

        except Exception as e:
            logger.error(f"Ошибка инициализации путей конфигурации: {e}")
            raise ConfigError(f"Не удалось инициализировать пути конфигурации: {e}")

    def _load_configuration(self, initial_config: Dict[str, Any]) -> None:
        """Загрузка конфигурации"""
        try:
            with self._lock:
                if self._config_file.exists():
                    # Загрузка существующей конфигурации
                    self._load_from_file()
                else:
                    # Создание новой конфигурации
                    self._create_default_config(initial_config)

                # Загрузка категорий
                self._load_categories()

                # Инициализация кэшей
                self._initialize_caches()

                # Создание резервной копии
                self._create_backup()

        except Exception as e:
            logger.error(f"Ошибка загрузки конфигурации: {e}")
            raise ConfigError(f"Не удалось загрузить конфигурацию: {e}")

    def _load_from_file(self) -> None:
        """Загрузка конфигурации из файла"""
        try:
            with open(self._config_file, 'r', encoding='utf-8') as f:
                file_config = json.load(f)

            # Проверка версии и миграция если нужно
            file_version = file_config.get('version', '1.0')
            if file_version != ConfigVersion.LATEST.value:
                file_config = self._migrate_config(file_config, file_version)

            self._config = file_config
            self._original_config = file_config.copy()

            logger.info(f"Конфигурация загружена из {self._config_file} (v{file_version})")

        except json.JSONDecodeError as e:
            logger.error(f"Ошибка парсинга конфигурационного файла: {e}")
            raise ConfigError(f"Конфигурационный файл поврежден: {e}")
        except Exception as e:
            logger.error(f"Ошибка загрузки конфигурационного файла: {e}")
            raise ConfigError(f"Не удалось загрузить конфигурацию: {e}")

    def _migrate_config(self, config: Dict[str, Any], from_version: str) -> Dict[str, Any]:
        """Миграция конфигурации со старой версии на новую"""
        try:
            logger.info(f"Миграция конфигурации с v{from_version} на v{ConfigVersion.LATEST.value}")

            # Миграция с версии 8.0 на 8.1
            if from_version == "8.0":
                # Добавление новых полей
                config.setdefault('auto_manage_interval', 30)
                config.setdefault('refresh_interval', 1)
                config.setdefault('theme', 'default')
                config.setdefault('sound_notifications', False)

                # Структурные изменения
                if 'network' not in config:
                    config['network'] = {
                        'listen_port': config.get('listen_port', 6881),
                        'enable_dht': config.get('enable_dht', True),
                        'enable_upnp': config.get('enable_upnp', True)
                    }

            # Обновление версии
            config['version'] = ConfigVersion.LATEST.value

            # Сохранение мигрированной конфигурации
            self._save_to_file(config)

            logger.info("Миграция конфигурации завершена успешно")
            return config

        except Exception as e:
            logger.error(f"Ошибка миграции конфигурации: {e}")
            raise ConfigError(f"Не удалось мигрировать конфигурацию: {e}")

    def _create_default_config(self, initial_config: Dict[str, Any]) -> None:
        """Создание конфигурации по умолчанию"""
        try:
            default_config = {
                'version': ConfigVersion.LATEST.value,
                'downloads_path': str(Path.home() / "Downloads"),
                'torrents_path': str(Path.home() / "Torrents"),
                'temp_path': str(Path.home() / "Downloads" / "temp"),
                'incomplete_path': str(Path.home() / "Downloads" / "incomplete"),
                'data_path': str(Path.home() / ".torrent_client"),

                # Сетевые настройки
                'network': {
                    'listen_port': 6881,
                    'enable_dht': True,
                    'enable_upnp': True,
                    'enable_lsd': True,
                    'enable_natpmp': True,
                    'max_connections': 200,
                    'max_uploads': 10,
                    'download_rate_limit': 0,
                    'upload_rate_limit': 0
                },

                # Настройки производительности
                'performance': {
                    'cache_size': 512,
                    'file_pool_size': 40,
                    'checking_mem_usage': 256,
                    'max_downloads': 5,
                    'seed_ratio': 2.0,
                    'auto_manage_interval': 30,
                    'refresh_interval': 1
                },

                # Настройки интерфейса
                'ui': {
                    'theme': 'default',
                    'language': 'ru',
                    'default_category': 'default',
                    'auto_start': False,
                    'notifications': True,
                    'sound_notifications': False,
                    'start_minimized': False,
                    'update_check': True
                },

                # Дополнительные настройки
                'auto_check_integrity': False,
                'auto_delete_torrent_file': False,
                'sequential_download': False,
                'log_level': 'INFO',
                'statistics_retention_days': 365,
                'statistics_interval': 60
            }

            # Объединение с переданной конфигурацией
            default_config.update(initial_config)
            self._config = default_config
            self._original_config = default_config.copy()

            # Сохранение конфигурации по умолчанию
            self._save_to_file(self._config)

            logger.info("Создана конфигурация по умолчанию")

        except Exception as e:
            logger.error(f"Ошибка создания конфигурации по умолчанию: {e}")
            raise ConfigError(f"Не удалось создать конфигурацию по умолчанию: {e}")

    def _save_to_file(self, config: Dict[str, Any]) -> None:
        """Сохранение конфигурации в файл"""
        try:
            # Создание резервной копии перед сохранением
            if self._config_file.exists():
                backup_path = self._backup_dir / f"config_backup_{int(self._get_timestamp())}.json"
                shutil.copy2(self._config_file, backup_path)

            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Ошибка сохранения конфигурации: {e}")
            raise ConfigError(f"Не удалось сохранить конфигурацию: {e}")

    def _get_timestamp(self) -> float:
        """Получение временной метки (для переопределения в тестах)"""
        import time
        return time.time()

    def _load_categories(self) -> None:
        """Загрузка категорий из файла"""
        try:
            if self._categories_file.exists():
                with open(self._categories_file, 'r', encoding='utf-8') as f:
                    categories_data = json.load(f)

                # Конвертация в объекты CategoryConfig
                for category_id, category_info in categories_data.items():
                    self._categories_cache[category_id] = CategoryConfig(**category_info)
            else:
                # Создание категорий по умолчанию
                self._create_default_categories()

        except Exception as e:
            logger.error(f"Ошибка загрузки категорий: {e}")
            self._create_default_categories()

    def _create_default_categories(self) -> None:
        """Создание категорий по умолчанию"""
        default_categories = {
            "default": CategoryConfig(
                name="По умолчанию",
                folder="",
                color="white"
            ),
            "movies": CategoryConfig(
                name="Фильмы",
                folder="Movies",
                color="blue"
            ),
            "music": CategoryConfig(
                name="Музыка",
                folder="Music",
                color="green"
            ),
            "software": CategoryConfig(
                name="Программы",
                folder="Software",
                color="yellow"
            ),
            "games": CategoryConfig(
                name="Игры",
                folder="Games",
                color="magenta"
            ),
            "books": CategoryConfig(
                name="Книги",
                folder="Books",
                color="cyan"
            )
        }

        self._categories_cache = default_categories
        self._save_categories()

        logger.info("Созданы категории по умолчанию")

    def _save_categories(self) -> None:
        """Сохранение категорий в файл"""
        try:
            categories_data = {
                category_id: asdict(config)
                for category_id, config in self._categories_cache.items()
            }

            with open(self._categories_file, 'w', encoding='utf-8') as f:
                json.dump(categories_data, f, indent=4, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Ошибка сохранения категорий: {e}")
            raise ConfigError(f"Не удалось сохранить категории: {e}")

    def _initialize_caches(self) -> None:
        """Инициализация кэшей конфигурации"""
        try:
            # Кэш сетевой конфигурации
            network_data = self._config.get('network', {})
            self._network_config_cache = NetworkConfig(**network_data)

            # Кэш конфигурации производительности
            performance_data = self._config.get('performance', {})
            self._performance_config_cache = PerformanceConfig(**performance_data)

            # Кэш конфигурации интерфейса
            ui_data = self._config.get('ui', {})
            self._ui_config_cache = UIConfig(**ui_data)

        except Exception as e:
            logger.error(f"Ошибка инициализации кэшей конфигурации: {e}")
            raise ConfigError(f"Не удалось инициализировать кэши конфигурации: {e}")

    def _create_backup(self) -> None:
        """Создание резервной копии конфигурации"""
        try:
            if self._config_file.exists():
                timestamp = int(self._get_timestamp())
                backup_name = f"config_backup_{timestamp}.json"
                backup_path = self._backup_dir / backup_name

                shutil.copy2(self._config_file, backup_path)

                # Ограничение количества резервных копий (последние 10)
                self._cleanup_old_backups()

        except Exception as e:
            logger.warning(f"Не удалось создать резервную копию конфигурации: {e}")

    def _cleanup_old_backups(self) -> None:
        """Очистка старых резервных копий"""
        try:
            backups = list(self._backup_dir.glob("config_backup_*.json"))
            if len(backups) > 10:
                backups.sort(key=lambda x: x.stat().st_mtime)
                for old_backup in backups[:-10]:
                    old_backup.unlink()

        except Exception as e:
            logger.warning(f"Не удалось очистить старые резервные копии: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        """
        Получение значения конфигурации по ключу

        Args:
            key: Ключ конфигурации (может быть вложенным через точку)
            default: Значение по умолчанию

        Returns:
            Значение конфигурации или default
        """
        try:
            with self._lock:
                # Поддержка вложенных ключей через точку
                keys = key.split('.')
                value = self._config

                for k in keys:
                    if isinstance(value, dict) and k in value:
                        value = value[k]
                    else:
                        return default

                return value

        except Exception as e:
            logger.error(f"Ошибка получения конфигурации по ключу {key}: {e}")
            return default

    def set(self, key: str, value: Any, save: bool = True) -> None:
        """
        Установка значения конфигурации

        Args:
            key: Ключ конфигурации (может быть вложенным через точку)
            value: Новое значение
            save: Сохранять ли изменения в файл
        """
        try:
            with self._lock:
                # Поддержка вложенных ключей через точку
                keys = key.split('.')
                config = self._config

                # Проход по всем ключам кроме последнего
                for k in keys[:-1]:
                    if k not in config or not isinstance(config[k], dict):
                        config[k] = {}
                    config = config[k]

                # Установка значения
                last_key = keys[-1]
                config[last_key] = value

                # Обновление кэшей если нужно
                self._update_caches(key, value)

                # Сохранение если требуется
                if save:
                    self._save_to_file(self._config)

        except Exception as e:
            logger.error(f"Ошибка установки конфигурации {key}: {e}")
            raise ConfigError(f"Не удалось установить конфигурацию: {e}")

    def _update_caches(self, key: str, value: Any) -> None:
        """Обновление кэшей конфигурации при изменении"""
        try:
            # Обновление сетевой конфигурации
            if key.startswith('network.') and self._network_config_cache:
                network_key = key.replace('network.', '')
                if hasattr(self._network_config_cache, network_key):
                    setattr(self._network_config_cache, network_key, value)

            # Обновление конфигурации производительности
            elif key.startswith('performance.') and self._performance_config_cache:
                performance_key = key.replace('performance.', '')
                if hasattr(self._performance_config_cache, performance_key):
                    setattr(self._performance_config_cache, performance_key, value)

            # Обновление конфигурации интерфейса
            elif key.startswith('ui.') and self._ui_config_cache:
                ui_key = key.replace('ui.', '')
                if hasattr(self._ui_config_cache, ui_key):
                    setattr(self._ui_config_cache, ui_key, value)

        except Exception as e:
            logger.warning(f"Ошибка обновления кэшей конфигурации: {e}")

    def get_network_config(self) -> NetworkConfig:
        """Получение сетевой конфигурации"""
        with self._lock:
            return self._network_config_cache

    def get_performance_config(self) -> PerformanceConfig:
        """Получение конфигурации производительности"""
        with self._lock:
            return self._performance_config_cache

    def get_ui_config(self) -> UIConfig:
        """Получение конфигурации интерфейса"""
        with self._lock:
            return self._ui_config_cache

    def get_categories(self) -> Dict[str, CategoryConfig]:
        """Получение всех категорий"""
        with self._lock:
            return self._categories_cache.copy()

    def get_category(self, category_id: str) -> Optional[CategoryConfig]:
        """Получение конкретной категории"""
        with self._lock:
            return self._categories_cache.get(category_id)

    def add_category(self, category_id: str, category_config: CategoryConfig) -> None:
        """
        Добавление новой категории

        Args:
            category_id: Идентификатор категории
            category_config: Конфигурация категории
        """
        try:
            with self._lock:
                if category_id in self._categories_cache:
                    raise ConfigError(f"Категория {category_id} уже существует")

                self._categories_cache[category_id] = category_config
                self._save_categories()

            logger.info(f"Добавлена категория: {category_id}")

        except Exception as e:
            logger.error(f"Ошибка добавления категории {category_id}: {e}")
            raise ConfigError(f"Не удалось добавить категорию: {e}")

    def update_category(self, category_id: str, category_config: CategoryConfig) -> None:
        """
        Обновление категории

        Args:
            category_id: Идентификатор категории
            category_config: Новая конфигурация категории
        """
        try:
            with self._lock:
                if category_id not in self._categories_cache:
                    raise ConfigError(f"Категория {category_id} не найдена")

                self._categories_cache[category_id] = category_config
                self._save_categories()

            logger.info(f"Обновлена категория: {category_id}")

        except Exception as e:
            logger.error(f"Ошибка обновления категории {category_id}: {e}")
            raise ConfigError(f"Не удалось обновить категорию: {e}")

    def delete_category(self, category_id: str) -> None:
        """
        Удаление категории

        Args:
            category_id: Идентификатор категории для удаления
        """
        try:
            with self._lock:
                if category_id not in self._categories_cache:
                    raise ConfigError(f"Категория {category_id} не найдена")

                if category_id == "default":
                    raise ConfigError("Нельзя удалить категорию по умолчанию")

                del self._categories_cache[category_id]
                self._save_categories()

            logger.info(f"Удалена категория: {category_id}")

        except Exception as e:
            logger.error(f"Ошибка удаления категории {category_id}: {e}")
            raise ConfigError(f"Не удалось удалить категорию: {e}")

    def save_profile(self, profile_name: str) -> bool:
        """
        Сохранение текущей конфигурации как профиля

        Args:
            profile_name: Имя профиля

        Returns:
            Успешность операции
        """
        try:
            profile_file = self._profiles_dir / f"{profile_name}.json"

            with self._lock:
                profile_data = {
                    'name': profile_name,
                    'timestamp': self._get_timestamp(),
                    'config': self._config,
                    'categories': {
                        cat_id: asdict(config)
                        for cat_id, config in self._categories_cache.items()
                    }
                }

                with open(profile_file, 'w', encoding='utf-8') as f:
                    json.dump(profile_data, f, indent=4, ensure_ascii=False)

            logger.info(f"Сохранен профиль конфигурации: {profile_name}")
            return True

        except Exception as e:
            logger.error(f"Ошибка сохранения профиля {profile_name}: {e}")
            return False

    def load_profile(self, profile_name: str) -> bool:
        """
        Загрузка конфигурации из профиля

        Args:
            profile_name: Имя профиля

        Returns:
            Успешность операции
        """
        try:
            profile_file = self._profiles_dir / f"{profile_name}.json"

            if not profile_file.exists():
                raise ConfigError(f"Профиль {profile_name} не найден")

            with open(profile_file, 'r', encoding='utf-8') as f:
                profile_data = json.load(f)

            with self._lock:
                # Загрузка основной конфигурации
                self._config = profile_data['config']
                self._save_to_file(self._config)

                # Загрузка категорий
                categories_data = profile_data.get('categories', {})
                self._categories_cache.clear()
                for cat_id, cat_info in categories_data.items():
                    self._categories_cache[cat_id] = CategoryConfig(**cat_info)
                self._save_categories()

                # Обновление кэшей
                self._initialize_caches()

            logger.info(f"Загружен профиль конфигурации: {profile_name}")
            return True

        except Exception as e:
            logger.error(f"Ошибка загрузки профиля {profile_name}: {e}")
            return False

    def list_profiles(self) -> List[str]:
        """Получение списка доступных профилей"""
        try:
            profiles = []
            for profile_file in self._profiles_dir.glob("*.json"):
                profiles.append(profile_file.stem)

            return sorted(profiles)

        except Exception as e:
            logger.error(f"Ошибка получения списка профилей: {e}")
            return []

    def delete_profile(self, profile_name: str) -> bool:
        """
        Удаление профиля

        Args:
            profile_name: Имя профиля для удаления

        Returns:
            Успешность операции
        """
        try:
            profile_file = self._profiles_dir / f"{profile_name}.json"

            if not profile_file.exists():
                raise ConfigError(f"Профиль {profile_name} не найден")

            profile_file.unlink()

            logger.info(f"Удален профиль конфигурации: {profile_name}")
            return True

        except Exception as e:
            logger.error(f"Ошибка удаления профиля {profile_name}: {e}")
            return False

    def validate_config(self) -> List[str]:
        """
        Валидация текущей конфигурации

        Returns:
            Список ошибок валидации
        """
        errors = []

        try:
            # Проверка путей
            paths_to_check = [
                ('downloads_path', self.get('downloads_path')),
                ('torrents_path', self.get('torrents_path')),
                ('temp_path', self.get('temp_path')),
                ('incomplete_path', self.get('incomplete_path'))
            ]

            for path_name, path_value in paths_to_check:
                if not path_value:
                    errors.append(f"Путь {path_name} не указан")
                    continue

                try:
                    safe_path = safe_path_join(path_value)
                    if not safe_path.parent.exists():
                        errors.append(f"Родительская директория для {path_name} не существует: {safe_path.parent}")
                except Exception as e:
                    errors.append(f"Неверный путь {path_name}: {e}")

            # Проверка сетевых настроек
            network_config = self.get_network_config()
            if not (1024 <= network_config.listen_port <= 65535):
                errors.append("Порт должен быть в диапазоне 1024-65535")

            if network_config.max_connections <= 0:
                errors.append("Максимальное количество соединений должно быть положительным")

            if network_config.max_uploads <= 0:
                errors.append("Максимальное количество отдач должно быть положительным")

            # Проверка настроек производительности
            performance_config = self.get_performance_config()
            if performance_config.cache_size <= 0:
                errors.append("Размер кэша должен быть положительным")

            if performance_config.max_downloads <= 0:
                errors.append("Максимальное количество загрузок должно быть положительным")

            if performance_config.seed_ratio < 0:
                errors.append("Seed ratio не может быть отрицательным")

            return errors

        except Exception as e:
            errors.append(f"Ошибка валидации конфигурации: {e}")
            return errors

    def reset_to_defaults(self) -> None:
        """Сброс конфигурации к значениям по умолчанию"""
        try:
            with self._lock:
                # Создание новой конфигурации по умолчанию
                self._create_default_config({})

                # Перезагрузка категорий
                self._create_default_categories()

                # Обновление кэшей
                self._initialize_caches()

            logger.info("Конфигурация сброшена к значениям по умолчанию")

        except Exception as e:
            logger.error(f"Ошибка сброса конфигурации: {e}")
            raise ConfigError(f"Не удалось сбросить конфигурацию: {e}")

    def has_unsaved_changes(self) -> bool:
        """Проверка наличия несохраненных изменений"""
        with self._lock:
            return self._config != self._original_config

    def get_config_hash(self) -> str:
        """Получение хеша текущей конфигурации"""
        try:
            config_json = json.dumps(self._config, sort_keys=True)
            return hashlib.sha256(config_json.encode()).hexdigest()
        except Exception as e:
            logger.error(f"Ошибка вычисления хеша конфигурации: {e}")
            return ""

    def export_config(self, export_path: str) -> bool:
        """
        Экспорт конфигурации в файл

        Args:
            export_path: Путь для экспорта

        Returns:
            Успешность операции
        """
        try:
            export_data = {
                'export_time': self._get_timestamp(),
                'version': ConfigVersion.LATEST.value,
                'config': self._config,
                'categories': {
                    cat_id: asdict(config)
                    for cat_id, config in self._categories_cache.items()
                }
            }

            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=4, ensure_ascii=False)

            logger.info(f"Конфигурация экспортирована в: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта конфигурации: {e}")
            return False

    def import_config(self, import_path: str) -> bool:
        """
        Импорт конфигурации из файла

        Args:
            import_path: Путь к файлу импорта

        Returns:
            Успешность операции
        """
        try:
            if not Path(import_path).exists():
                raise ConfigError(f"Файл импорта не найден: {import_path}")

            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)

            with self._lock:
                # Загрузка основной конфигурации
                self._config = import_data['config']
                self._save_to_file(self._config)

                # Загрузка категорий
                categories_data = import_data.get('categories', {})
                self._categories_cache.clear()
                for cat_id, cat_info in categories_data.items():
                    self._categories_cache[cat_id] = CategoryConfig(**cat_info)
                self._save_categories()

                # Обновление кэшей
                self._initialize_caches()

            logger.info(f"Конфигурация импортирована из: {import_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка импорта конфигурации: {e}")
            return False

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы ConfigService...")

        try:
            # Сохранение изменений если есть
            if self.has_unsaved_changes():
                self._save_to_file(self._config)
                logger.info("Несохраненные изменения конфигурации сохранены")

            # Создание финальной резервной копии
            self._create_backup()

        except Exception as e:
            logger.error(f"Ошибка при завершении ConfigService: {e}")

        logger.info("ConfigService завершен")