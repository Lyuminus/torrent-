"""
CONFIG MODELS - Модели конфигурации

Содержит модели данных для конфигурации приложения.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class CategoryConfig:
    """Конфигурация категории"""
    name: str
    folder: str
    color: str = "white"
    download_limit: int = 0  # 0 = без ограничений
    upload_limit: int = 0
    max_downloads: int = 5
    auto_management: bool = True


@dataclass
class NetworkConfig:
    """Сетевая конфигурация"""
    listen_port: int = 6881
    enable_dht: bool = True
    enable_upnp: bool = True
    enable_lsd: bool = True
    enable_natpmp: bool = True
    max_connections: int = 200
    max_uploads: int = 10
    download_rate_limit: int = 0  # KB/s
    upload_rate_limit: int = 0
    proxy_host: str = ""
    proxy_port: int = 0
    proxy_username: str = ""
    proxy_password: str = ""


@dataclass
class PerformanceConfig:
    """Конфигурация производительности"""
    cache_size: int = 512  # MB
    file_pool_size: int = 40
    checking_mem_usage: int = 256  # MB
    max_downloads: int = 5
    seed_ratio: float = 2.0
    auto_manage_interval: int = 30  # seconds
    refresh_interval: int = 1  # second


@dataclass
class UIConfig:
    """Конфигурация интерфейса"""
    theme: str = "default"
    language: str = "ru"
    default_category: str = "default"
    auto_start: bool = False
    notifications: bool = True
    sound_notifications: bool = False
    start_minimized: bool = False
    update_check: bool = True