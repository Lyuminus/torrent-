"""
EXCEPTIONS MODELS - Пользовательские исключения

Содержит все пользовательские исключения, используемые в приложении.
"""


class CoreError(Exception):
    """Базовое исключение для ошибок ядра"""
    pass


class SessionError(CoreError):
    """Ошибка инициализации или работы сессии"""
    pass


class TorrentError(CoreError):
    """Ошибка работы с торрентами"""
    pass


class ConfigurationError(CoreError):
    """Ошибка конфигурации"""
    pass


class ServiceError(Exception):
    """Базовое исключение для ошибок сервисов"""
    pass


class ConfigError(ServiceError):
    """Ошибка конфигурации"""
    pass


class HistoryError(ServiceError):
    """Ошибка работы с историей"""
    pass


class SecurityError(ServiceError):
    """Ошибка безопасности"""
    pass


class AutomationError(ServiceError):
    """Ошибка автоматизации"""
    pass


class IntegrationError(ServiceError):
    """Ошибка интеграции"""
    pass