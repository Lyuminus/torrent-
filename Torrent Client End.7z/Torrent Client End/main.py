#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MAIN - Точка входа в Torrent Client v8.0
"""

import logging
import signal
import sys
from pathlib import Path
from typing import Dict, Any

# Добавляем корень проекта в PYTHONPATH при frozen-запуске
if getattr(sys, "frozen", False):
    # noinspection PyProtectedMember
    sys.path.insert(0, str(Path(sys.executable).parent))

from constants import (
    APP_NAME,
    APP_VERSION,
    DEFAULT_CONFIG_PATH,
    DEFAULT_LOG_LEVEL,
    DEFAULT_LOG_FORMAT,
    LOG_ROTATION_SIZE,
    LOG_BACKUP_COUNT,
)
from utils.logging_config import setup_logging, get_logger
from services import init_services, shutdown_services
from ui import create_interface

# --------------------------------------------------------------------------- #
# Настройка логирования ДО импорта остальных модулей
# --------------------------------------------------------------------------- #
setup_logging(
    log_level=DEFAULT_LOG_LEVEL,
    log_file=str(Path(DEFAULT_CONFIG_PATH) / "torrent_client.log"),
    max_bytes=LOG_ROTATION_SIZE,
    backup_count=LOG_BACKUP_COUNT,
)

logger = get_logger(__name__)


class TorrentClient:
    """
    Главный класс приложения.
    Управляет жизненным циклом: инициализация → запуск UI → graceful shutdown.
    """

    def __init__(self) -> None:
        self.core_components: Dict[str, Any] = {}
        self.services: Dict[str, Any] = {}
        self.ui: Any = None
        self.running: bool = False

    # ----------------------------------------------------------------------- #
    # Инициализация
    # ----------------------------------------------------------------------- #
    def initialize(self) -> bool:
        """
        Инициализирует все слои приложения строго в нужном порядке.
        """
        logger.info("Инициализация %s v%s", APP_NAME, APP_VERSION)

        # 1. Создание необходимых директорий
        Path(DEFAULT_CONFIG_PATH).mkdir(parents=True, exist_ok=True)

        # 2. Инициализация core-компонентов
        try:
            from core import (
                SessionManager,
                TorrentManager,
                FileManager,
                PeerManager,
                StatisticsEngine,
            )

            session_config = {"listen_port": 6881}  # Базовый конфиг
            session_manager = SessionManager(session_config)
            self.core_components["session_manager"] = session_manager

            torrent_manager = TorrentManager(session_manager, session_config)
            self.core_components["torrent_manager"] = torrent_manager

            file_manager = FileManager(session_config)
            self.core_components["file_manager"] = file_manager

            peer_manager = PeerManager(session_manager, session_config)
            self.core_components["peer_manager"] = peer_manager

            statistics_engine = StatisticsEngine(session_config)
            self.core_components["statistics_engine"] = statistics_engine

        except Exception as exc:
            logger.exception("Ошибка инициализации core-компонентов")
            return False

        # 3. Инициализация сервисов
        try:
            self.services = init_services(self.core_components, {})
        except Exception as exc:
            logger.exception("Ошибка инициализации сервисов")
            return False

        # 4. Инициализация UI
        try:
            self.ui = create_interface(
                interface_type="console",
                config={},
                core_components=self.core_components,
                services=self.services,
            )
            if not self.ui.initialize():
                raise RuntimeError("Инициализация UI вернула False")
        except Exception as exc:
            logger.exception("Ошибка инициализации UI")
            return False

        # 5. Установка обработчиков сигналов
        self._setup_signal_handlers()

        logger.info("Инициализация завершена успешно")
        return True

    # ----------------------------------------------------------------------- #
    # Управление сигналами
    # ----------------------------------------------------------------------- #
    def _setup_signal_handlers(self) -> None:
        """
        Перехватывает SIGINT и SIGTERM для graceful shutdown.
        """

        def _handler(signum: int, frame: Any) -> None:
            logger.info("Получен сигнал %s, начинаем корректное завершение...", signum)
            self.shutdown()

        signal.signal(signal.SIGINT, _handler)
        signal.signal(signal.SIGTERM, _handler)

    # ----------------------------------------------------------------------- #
    # Основной цикл
    # ----------------------------------------------------------------------- #
    def run(self) -> int:
        """
        Запускает UI и блокируется до завершения.
        Возвращает код выхода для sys.exit.
        """
        self.running = True
        logger.info("Запуск UI...")
        try:
            self.ui.start()
        except KeyboardInterrupt:
            logger.info("Прервано пользователем")
        except Exception as exc:
            logger.exception("Критическая ошибка в UI")
            return 1
        finally:
            self.shutdown()
        return 0

    # ----------------------------------------------------------------------- #
    # Graceful shutdown
    # ----------------------------------------------------------------------- #
    def shutdown(self) -> None:
        """
        Корректно завершает работу всех компонентов в обратном порядке.
        """
        if not self.running:
            return
        self.running = False
        logger.info("Завершение работы...")

        # 1. UI
        if self.ui:
            try:
                self.ui.stop()
            except Exception:
                logger.exception("Ошибка остановки UI")
            self.ui = None

        # 2. Сервисы
        try:
            shutdown_services(self.services)
        except Exception:
            logger.exception("Ошибка завершения сервисов")
        self.services.clear()

        # 3. Core (в обратном порядке инициализации)
        for name in ["statistics_engine", "peer_manager", "file_manager",
                     "torrent_manager", "session_manager"]:
            component = self.core_components.pop(name, None)
            if component and hasattr(component, "shutdown"):
                try:
                    component.shutdown()
                except Exception:
                    logger.exception("Ошибка завершения %s", name)

        logger.info("Завершение завершено ✓")


# --------------------------------------------------------------------------- #
# Точка входа
# --------------------------------------------------------------------------- #
def main() -> int:
    """
    Возвращает код выхода (0 – успешно, 1 – ошибка).
    """
    client = TorrentClient()
    if not client.initialize():
        return 1
    return client.run()


if __name__ == "__main__":
    sys.exit(main())