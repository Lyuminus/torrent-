"""
FORMATTERS - Утилиты форматирования данных

Содержит функции для форматирования размеров, скоростей, времени и других данных.
"""

import math
from typing import Union
from datetime import datetime, timedelta


def format_size(size_bytes: int) -> str:
    """
    Форматирование размера в байтах в читабельный вид.

    Args:
        size_bytes: Размер в байтах

    Returns:
        Строка с форматированным размером
    """
    if size_bytes == 0:
        return "0 B"

    size_names = ["B", "KB", "MB", "GB", "TB", "PB"]
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)

    return f"{s} {size_names[i]}"


def format_speed(speed_bytes: float) -> str:
    """
    Форматирование скорости в байтах/секунду в читабельный вид.

    Args:
        speed_bytes: Скорость в байтах/секунду

    Returns:
        Строка с форматированной скоростью
    """
    if speed_bytes == 0:
        return "0 B/s"

    size_names = ["B/s", "KB/s", "MB/s", "GB/s"]
    i = int(math.floor(math.log(speed_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(speed_bytes / p, 2)

    return f"{s} {size_names[i]}"


def format_duration(seconds: int) -> str:
    """
    Форматирование длительности в секундах в читабельный вид.

    Args:
        seconds: Длительность в секундах

    Returns:
        Строка с форматированной длительностью
    """
    if seconds == 0:
        return "0s"

    if seconds < 60:
        return f"{seconds}s"

    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {seconds}s"

    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours}h {minutes}m"

    days, hours = divmod(hours, 24)
    return f"{days}d {hours}h"


def format_timestamp(timestamp: float, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Форматирование временной метки в строку.

    Args:
        timestamp: Временная метка (Unix time)
        format_str: Формат строки (по умолчанию: %Y-%m-%d %H:%M:%S)

    Returns:
        Строка с форматированным временем
    """
    return datetime.fromtimestamp(timestamp).strftime(format_str)


def format_percentage(value: float, total: float) -> str:
    """
    Форматирование процента.

    Args:
        value: Текущее значение
        total: Общее значение

    Returns:
        Строка с процентом
    """
    if total == 0:
        return "0%"

    percentage = (value / total) * 100
    return f"{percentage:.1f}%"