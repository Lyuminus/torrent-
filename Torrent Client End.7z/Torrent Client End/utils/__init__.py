"""
UTILS MODULE - Вспомогательные утилиты

Содержит вспомогательные функции для работы с путями, форматирования данных,
валидации, логирования и получения системной информации.
"""

from .formatters import format_size, format_speed, format_duration, format_timestamp
from .validators import validate_path, safe_path_join, validate_ip_address, validate_torrent_file
from .logging_config import setup_logging, get_logger
from .system_info import get_system_info, get_disk_usage, get_network_interfaces

__all__ = [
    # Formatters
    'format_size',
    'format_speed',
    'format_duration',
    'format_timestamp',

    # Validators
    'validate_path',
    'safe_path_join',
    'validate_ip_address',
    'validate_torrent_file',

    # Logging
    'setup_logging',
    'get_logger',

    # System info
    'get_system_info',
    'get_disk_usage',
    'get_network_interfaces'
]