"""
LOGGING CONFIG - Настройка логирования

Содержит функции для настройки и управления логированием.
"""

import logging
import logging.handlers
import sys
from pathlib import Path
from typing import Optional


def setup_logging(
        log_level: str = "INFO",
        log_file: Optional[str] = None,
        max_bytes: int = 10 * 1024 * 1024,  # 10 MB
        backup_count: int = 5
) -> None:
    """
    Настройка логирования.

    Args:
        log_level: Уровень логирования (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Путь к файлу лога (если None, логи только в консоль)
        max_bytes: Максимальный размер файла лога перед ротацией
        backup_count: Количество бэкап-файлов
    """
    # Получение корневого логгера
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level.upper()))

    # Форматтер для логов
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Очистка существующих обработчиков
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Обработчик для консоли
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # Обработчик для файла (если указан)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """
    Получение логгера с указанным именем.

    Args:
        name: Имя логгера

    Returns:
        Объект логгера
    """
    return logging.getLogger(name)