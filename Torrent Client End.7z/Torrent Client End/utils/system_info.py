"""
SYSTEM INFO - Утилиты получения системной информации

Содержит функции для получения информации о системе, дисках, сети и т.д.
"""

import platform
import shutil
import psutil
from typing import Dict, Any, List


def get_system_info() -> Dict[str, Any]:
    """
    Получение информации о системе.

    Returns:
        Словарь с информацией о системе
    """
    try:
        system_info = {
            'platform': platform.system(),
            'platform_release': platform.release(),
            'platform_version': platform.version(),
            'architecture': platform.architecture()[0],
            'processor': platform.processor(),
            'python_version': platform.python_version(),
            'hostname': platform.node(),
            'cpu_count': psutil.cpu_count(logical=False),
            'cpu_count_logical': psutil.cpu_count(logical=True),
            'memory_total': psutil.virtual_memory().total,
            'boot_time': psutil.boot_time()
        }

        # Добавление информации о дисках
        disk_info = {}
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_info[partition.mountpoint] = {
                    'device': partition.device,
                    'fstype': partition.fstype,
                    'total': usage.total,
                    'used': usage.used,
                    'free': usage.free,
                    'percent': usage.percent
                }
            except Exception:
                continue

        system_info['disks'] = disk_info

        return system_info

    except Exception as e:
        return {'error': str(e)}


def get_disk_usage(path: str = "/") -> Dict[str, Any]:
    """
    Получение информации об использовании диска для указанного пути.

    Args:
        path: Путь для проверки

    Returns:
        Словарь с информацией об использовании диска
    """
    try:
        usage = shutil.disk_usage(path)
        return {
            'path': path,
            'total': usage.total,
            'used': usage.used,
            'free': usage.free,
            'percent': (usage.used / usage.total) * 100 if usage.total > 0 else 0
        }
    except Exception as e:
        return {'error': str(e)}


def get_network_interfaces() -> List[Dict[str, Any]]:
    """
    Получение информации о сетевых интерфейсах.

    Returns:
        Список с информацией о сетевых интерфейсах
    """
    try:
        interfaces = []
        for interface_name, interface_addresses in psutil.net_if_addrs().items():
            interface_info = {
                'name': interface_name,
                'addresses': []
            }

            for address in interface_addresses:
                address_info = {
                    'family': str(address.family),
                    'address': address.address,
                    'netmask': address.netmask,
                    'broadcast': address.broadcast
                }
                interface_info['addresses'].append(address_info)

            interfaces.append(interface_info)

        return interfaces

    except Exception as e:
        return [{'error': str(e)}]


def get_system_usage() -> Dict[str, Any]:
    """
    Получение текущей загрузки системы.

    Returns:
        Словарь с информацией о загрузке системы
    """
    try:
        return {
            'cpu_percent': psutil.cpu_percent(interval=0.1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_io': psutil.disk_io_counters()._asdict() if psutil.disk_io_counters() else {},
            'network_io': psutil.net_io_counters()._asdict() if psutil.net_io_counters() else {}
        }
    except Exception as e:
        return {'error': str(e)}