"""
BASE INTERFACE - Базовый класс интерфейса

Определяет общий интерфейс для всех типов UI (консольный, веб, API).
"""

import abc
from typing import Dict, Any, List, Optional
from abc import ABC, abstractmethod


class BaseInterface(ABC):
    """
    Абстрактный базовый класс для всех интерфейсов пользователя
    """

    def __init__(self, config: Dict[str, Any], core_components: Dict[str, Any],
                 services: Dict[str, Any]):
        """
        Инициализация интерфейса

        Args:
            config: Конфигурация приложения
            core_components: Компоненты ядра
            services: Сервисы приложения
        """
        self.config = config
        self.core_components = core_components
        self.services = services
        self.running = False

    @abstractmethod
    def initialize(self) -> bool:
        """
        Инициализация интерфейса

        Returns:
            Успешность инициализации
        """
        pass

    @abstractmethod
    def start(self) -> None:
        """
        Запуск интерфейса
        """
        pass

    @abstractmethod
    def stop(self) -> None:
        """
        Остановка интерфейса
        """
        pass

    @abstractmethod
    def display_message(self, message: str, message_type: str = "info") -> None:
        """
        Отображение сообщения пользователю

        Args:
            message: Текст сообщения
            message_type: Тип сообщения (info, warning, error, success)
        """
        pass

    @abstractmethod
    def get_user_input(self, prompt: str, input_type: type = str) -> Any:
        """
        Получение ввода от пользователя

        Args:
            prompt: Подсказка для пользователя
            input_type: Ожидаемый тип данных

        Returns:
            Введенные пользователем данные
        """
        pass

    @abstractmethod
    def update_display(self) -> None:
        """
        Обновление отображения интерфейса
        """
        pass

    def get_torrent_manager(self):
        """Получение менеджера торрентов"""
        return self.core_components.get('torrent_manager')

    def get_session_manager(self):
        """Получение менеджера сессии"""
        return self.core_components.get('session_manager')

    def get_config_service(self):
        """Получение сервиса конфигурации"""
        return self.services.get('config')

    def get_history_service(self):
        """Получение сервиса истории"""
        return self.services.get('history')

    def get_security_service(self):
        """Получение сервиса безопасности"""
        return self.services.get('security')

    def get_automation_service(self):
        """Получение сервиса автоматизации"""
        return self.services.get('automation')

    def get_integration_service(self):
        """Получение сервиса интеграций"""
        return self.services.get('integration')