"""
CONSTANTS - Глобальные константы и настройки торрент-клиента
"""

import sys
import os
from pathlib import Path

# --------------------------------------------------------------------------- #
# Метаданные приложения
# --------------------------------------------------------------------------- #
APP_VERSION: str = "8.0"
APP_NAME: str = "Torrent Client"
APP_AUTHOR: str = "Torrent Client Team"

# --------------------------------------------------------------------------- #
# Определение «домашней» директории с учётом frozen-сборок
# --------------------------------------------------------------------------- #
def _get_base_path() -> Path:
    """
    Возвращает базовый путь для хранения настроек и данных.
    Для «замороженных» сборок используется каталог рядом с исполняемым файлом.
    """
    if getattr(sys, "frozen", False):
        # PyInstaller / cx_Freeze
        return Path(sys.executable).parent.absolute()
    else:
        # Обычный запуск из исходников
        return Path.home()


BASE_DIR: Path = _get_base_path()

# --------------------------------------------------------------------------- #
# Пути по умолчанию
# --------------------------------------------------------------------------- #
DEFAULT_DOWNLOAD_PATH: str = str(BASE_DIR / "Downloads")
DEFAULT_TORRENTS_PATH: str = str(BASE_DIR / "Torrents")
DEFAULT_CONFIG_PATH: str = str(BASE_DIR / ".torrent_client")
DEFAULT_DATA_PATH: str = str(BASE_DIR / ".torrent_client" / "data")
DEFAULT_TEMP_PATH: str = str(BASE_DIR / "Downloads" / "temp")
DEFAULT_INCOMPLETE_PATH: str = str(BASE_DIR / "Downloads" / "incomplete")

# --------------------------------------------------------------------------- #
# Настройки сессии libtorrent по умолчанию
# --------------------------------------------------------------------------- #
DEFAULT_SESSION_SETTINGS: dict = {
    "listen_interfaces": "0.0.0.0:6881",
    "enable_dht": True,
    "enable_upnp": True,
    "enable_lsd": True,
    "enable_natpmp": True,
    "max_connections": 200,
    "max_uploads": 10,
    "download_rate_limit": 0,  # KB/s (0 = без ограничений)
    "upload_rate_limit": 0,    # KB/s
    "cache_size": 512,         # MB
    "file_pool_size": 40,
    "checking_mem_usage": 256, # MB
    "max_downloads": 5,
    "seed_ratio": 2.0,
}

# --------------------------------------------------------------------------- #
# Настройки логирования
# --------------------------------------------------------------------------- #
DEFAULT_LOG_LEVEL: str = "INFO"
DEFAULT_LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_ROTATION_SIZE: int = 10 * 1024 * 1024  # 10 MB
LOG_BACKUP_COUNT: int = 5

# --------------------------------------------------------------------------- #
# Валидация и безопасность
# --------------------------------------------------------------------------- #
MAX_FILENAME_LENGTH: int = 255
MAX_PATH_LENGTH: int = 4096
ALLOWED_FILE_EXTENSIONS: set = {".torrent", ".magnet"}
BLOCKED_EXTENSIONS: set = {
    ".exe", ".scr", ".pif", ".com", ".bat", ".cmd", ".vbs", ".ps1", ".jar",
}

# --------------------------------------------------------------------------- #
# Временные интервалы (секунды)
# --------------------------------------------------------------------------- #
STATISTICS_INTERVAL: int = 60
AUTO_SAVE_INTERVAL: int = 300
CLEANUP_INTERVAL: int = 3600
PEER_UPDATE_INTERVAL: int = 30

# --------------------------------------------------------------------------- #
# Лимиты
# --------------------------------------------------------------------------- #
MAX_TORRENTS: int = 1000
MAX_HISTORY_ENTRIES: int = 10000
MAX_PEERS_PER_TORRENT: int = 50
MIN_FREE_SPACE: int = 1024 ** 3  # 1 GB

# --------------------------------------------------------------------------- #
# Категории по умолчанию
# --------------------------------------------------------------------------- #
DEFAULT_CATEGORIES: dict = {
    "default": {
        "name": "По умолчанию",
        "folder": "",
        "color": "white",
        "download_limit": 0,
        "upload_limit": 0,
        "max_downloads": 5,
        "auto_management": True,
    },
    "movies": {
        "name": "Фильмы",
        "folder": "Movies",
        "color": "blue",
        "download_limit": 0,
        "upload_limit": 0,
        "max_downloads": 3,
        "auto_management": True,
    },
    "music": {
        "name": "Музыка",
        "folder": "Music",
        "color": "green",
        "download_limit": 0,
        "upload_limit": 0,
        "max_downloads": 3,
        "auto_management": True,
    },
    "software": {
        "name": "Программы",
        "folder": "Software",
        "color": "yellow",
        "download_limit": 0,
        "upload_limit": 0,
        "max_downloads": 2,
        "auto_management": True,
    },
}