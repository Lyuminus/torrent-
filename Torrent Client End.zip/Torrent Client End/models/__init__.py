"""
MODELS MODULE - Модели данных торрент-клиента

Содержит все модели данных, используемые в приложении:
- Модели торрентов, статусов, приоритетов
- Модели конфигурации
- Модели статистики
- Пользовательские исключения
"""

from .torrent import Torrent, TorrentStatus, Priority, TorrentStats, FileInfo
from .config import CategoryConfig, NetworkConfig, PerformanceConfig, UIConfig
from .statistics import SessionStats, TorrentStats, PeerStats
from .exceptions import (
    CoreError, SessionError, TorrentError, ConfigurationError,
    ServiceError, ConfigError, HistoryError, SecurityError,
    AutomationError, IntegrationError
)

__all__ = [
    # Torrent models
    'Torrent',
    'TorrentStatus',
    'Priority',
    'TorrentStats',
    'FileInfo',

    # Config models
    'CategoryConfig',
    'NetworkConfig',
    'PerformanceConfig',
    'UIConfig',

    # Statistics models
    'SessionStats',
    'TorrentStats',
    'PeerStats',

    # Exceptions
    'CoreError',
    'SessionError',
    'TorrentError',
    'ConfigurationError',
    'ServiceError',
    'ConfigError',
    'HistoryError',
    'SecurityError',
    'AutomationError',
    'IntegrationError'
]