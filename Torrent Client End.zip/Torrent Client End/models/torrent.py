"""
TORRENT MODELS - Модели данных для торрентов

Содержит модели данных, связанные с торрентами: статусы, приоритеты, информация о файлах.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum


class TorrentStatus(Enum):
    """Статусы торрента"""
    DOWNLOADING = "downloading"
    SEEDING = "seeding"
    PAUSED = "paused"
    CHECKING = "checking"
    COMPLETED = "completed"
    ERROR = "error"
    UNKNOWN = "unknown"


class Priority(Enum):
    """Приоритеты торрента"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    MAXIMUM = 3


@dataclass
class FileInfo:
    """Информация о файле в торренте"""
    path: str
    size: int
    progress: float = 0.0
    priority: Priority = Priority.NORMAL
    is_seed: bool = False
    modified_time: float = 0.0


@dataclass
class TorrentStats:
    """Статистика торрента"""
    info_hash: str
    name: str
    progress: float = 0.0
    download_rate: int = 0
    upload_rate: int = 0
    total_downloaded: int = 0
    total_uploaded: int = 0
    peers: int = 0
    seeds: int = 0
    status: TorrentStatus = TorrentStatus.UNKNOWN
    eta: int = 0
    piece_size: int = 0
    pieces_done: int = 0
    pieces_total: int = 0
    files: List[FileInfo] = field(default_factory=list)
    download_path: str = ""
    added_time: float = 0.0
    category: str = "default"
    tags: List[str] = field(default_factory=list)
    priority: Priority = Priority.NORMAL


@dataclass
class Torrent:
    """Модель торрента"""
    info_hash: str
    name: str
    added_date: float
    total_size: int
    download_path: str
    torrent_path: str = ""
    status: TorrentStatus = TorrentStatus.DOWNLOADING
    priority: Priority = Priority.NORMAL
    category: str = "default"
    tags: List[str] = field(default_factory=list)
    completed: bool = False
    error_message: str = ""
    # Дополнительные поля для хранения состояния
    _handle: Any = None  # Ссылка на handle libtorrent (не сериализуется)

    def update_from_stats(self, stats: TorrentStats) -> None:
        """Обновление торрента из статистики"""
        self.name = stats.name
        self.status = stats.status
        self.priority = stats.priority
        self.category = stats.category
        self.tags = stats.tags
        self.completed = (stats.progress >= 1.0)