"""
STATISTICS MODELS - Модели статистики

Содержит модели данных для статистики и аналитики.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class SessionStats:
    """Статистика сессии"""
    download_rate: int = 0
    upload_rate: int = 0
    total_download: int = 0
    total_upload: int = 0
    dht_nodes: int = 0
    num_peers: int = 0
    num_unchoked: int = 0
    num_torrents: int = 0
    up_bandwidth_queue: int = 0
    down_bandwidth_queue: int = 0


@dataclass
class TorrentStats:
    """Статистика торрента (расширенная)"""
    info_hash: str
    name: str
    total_size: int = 0
    progress: float = 0.0
    download_rate: int = 0
    upload_rate: int = 0
    total_downloaded: int = 0
    total_uploaded: int = 0
    peers: int = 0
    seeds: int = 0
    status: str = "unknown"
    eta: int = 0
    piece_size: int = 0
    pieces_done: int = 0
    pieces_total: int = 0
    files: List[Dict[str, Any]] = field(default_factory=list)
    download_path: str = ""
    added_time: float = 0.0
    category: str = "default"
    tags: List[str] = field(default_factory=list)
    priority: int = 1


@dataclass
class PeerStats:
    """Статистика пира"""
    ip: str
    port: int
    client: str = ""
    flags: List[str] = field(default_factory=list)
    download_speed: int = 0
    upload_speed: int = 0
    progress: float = 0.0
    total_downloaded: int = 0
    total_uploaded: int = 0
    connection_type: str = "tcp"
    country: str = ""
    connection_time: float = 0.0
    last_activity: float = 0.0