"""
HISTORY SERVICE - Сервис управления историей загрузок

Отвечает за хранение, поиск, фильтрацию и анализ истории торрент-загрузок.
Обеспечивает сохранение состояния загрузок, статистику по категориям и временные метрики.
Поддерживает расширенный поиск и экспорт данных.
"""

import json
import logging
import time
from typing import Dict, List, Optional, Any, Union, Set
from pathlib import Path
from threading import RLock
from dataclasses import dataclass, asdict, field
from enum import Enum
from datetime import datetime, timedelta
from collections import defaultdict
import sqlite3

from ..models.exceptions import HistoryError
from ..models.torrent import TorrentStatus, Priority

logger = logging.getLogger(__name__)


class HistoryEventType(Enum):
    """Типы событий в истории"""
    ADDED = "added"
    COMPLETED = "completed"
    PAUSED = "paused"
    RESUMED = "resumed"
    REMOVED = "removed"
    ERROR = "error"
    MOVED = "moved"
    RENAMED = "renamed"


@dataclass
class HistoryEvent:
    """Событие в истории загрузок"""
    event_id: str
    info_hash: str
    event_type: HistoryEventType
    timestamp: float
    data: Dict[str, Any] = field(default_factory=dict)
    description: str = ""


@dataclass
class TorrentHistory:
    """История одного торрента"""
    info_hash: str
    name: str
    added_date: float
    completed_date: Optional[float] = None
    last_updated: float = field(default_factory=time.time)

    # Статистика
    total_size: int = 0
    downloaded_bytes: int = 0
    uploaded_bytes: int = 0
    download_rate_avg: float = 0.0
    upload_rate_avg: float = 0.0

    # Метаданные
    category: str = "default"
    tags: List[str] = field(default_factory=list)
    priority: Priority = Priority.NORMAL

    # Пути
    torrent_path: str = ""
    download_path: str = ""
    final_path: str = ""

    # Статус
    status: TorrentStatus = TorrentStatus.DOWNLOADING
    error_message: str = ""

    # Дополнительные метрики
    seed_ratio: float = 0.0
    active_time: float = 0.0  # в секундах
    share_ratio: float = 0.0

    # События
    events: List[HistoryEvent] = field(default_factory=list)


class HistoryService:
    """
    Сервис управления историей загрузок с расширенной аналитикой
    """

    def __init__(self, config_service):
        self.config_service = config_service
        self._lock = RLock()

        # Основное хранилище
        self._history: Dict[str, TorrentHistory] = {}
        self._events: List[HistoryEvent] = []

        # Индексы для быстрого поиска
        self._category_index: Dict[str, Set[str]] = defaultdict(set)
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._status_index: Dict[TorrentStatus, Set[str]] = defaultdict(set)
        self._date_index: Dict[str, Set[str]] = defaultdict(set)  # по датам

        # База данных для долгосрочного хранения
        self._db_path: Optional[Path] = None
        self._db_connection: Optional[sqlite3.Connection] = None

        # Настройки
        self._retention_days = self.config_service.get('history_retention_days', 365)
        self._auto_cleanup = self.config_service.get('history_auto_cleanup', True)

        # Инициализация
        self._initialize_database()
        self._load_history()

        logger.info("HistoryService инициализирован")

    def _initialize_database(self) -> None:
        """Инициализация базы данных для истории"""
        try:
            data_path = self.config_service.get('data_path', '.torrent_client')
            self._db_path = Path(data_path) / "history.db"
            self._db_path.parent.mkdir(parents=True, exist_ok=True)

            self._db_connection = sqlite3.connect(
                str(self._db_path),
                timeout=30,
                check_same_thread=False
            )

            # Включение оптимизаций
            self._db_connection.execute("PRAGMA journal_mode=WAL")
            self._db_connection.execute("PRAGMA synchronous=NORMAL")
            self._db_connection.execute("PRAGMA cache_size=-10000")

            # Создание таблиц
            self._create_tables()

            logger.info("База данных истории инициализирована")

        except Exception as e:
            logger.error(f"Ошибка инициализации базы данных истории: {e}")
            raise HistoryError(f"Не удалось инициализировать базу данных истории: {e}")

    def _create_tables(self) -> None:
        """Создание таблиц базы данных"""
        try:
            cursor = self._db_connection.cursor()

            # Таблица торрентов
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS torrents_history (
                    info_hash TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    added_date REAL NOT NULL,
                    completed_date REAL,
                    last_updated REAL NOT NULL,
                    total_size INTEGER DEFAULT 0,
                    downloaded_bytes INTEGER DEFAULT 0,
                    uploaded_bytes INTEGER DEFAULT 0,
                    download_rate_avg REAL DEFAULT 0,
                    upload_rate_avg REAL DEFAULT 0,
                    category TEXT DEFAULT 'default',
                    tags TEXT,
                    priority INTEGER DEFAULT 1,
                    torrent_path TEXT,
                    download_path TEXT,
                    final_path TEXT,
                    status TEXT DEFAULT 'downloading',
                    error_message TEXT,
                    seed_ratio REAL DEFAULT 0,
                    active_time REAL DEFAULT 0,
                    share_ratio REAL DEFAULT 0
                )
            """)

            # Таблица событий
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS history_events (
                    event_id TEXT PRIMARY KEY,
                    info_hash TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    data TEXT,
                    description TEXT,
                    FOREIGN KEY (info_hash) REFERENCES torrents_history (info_hash) ON DELETE CASCADE
                )
            """)

            # Индексы для быстрого поиска
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_torrents_category ON torrents_history(category)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_torrents_status ON torrents_history(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_torrents_added_date ON torrents_history(added_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_info_hash ON history_events(info_hash)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_timestamp ON history_events(timestamp)")

            self._db_connection.commit()

        except Exception as e:
            logger.error(f"Ошибка создания таблиц истории: {e}")
            raise

    def _load_history(self) -> None:
        """Загрузка истории из базы данных"""
        try:
            cursor = self._db_connection.cursor()

            # Загрузка торрентов
            cursor.execute("SELECT * FROM torrents_history")
            torrent_rows = cursor.fetchall()

            for row in torrent_rows:
                try:
                    history = TorrentHistory(
                        info_hash=row[0],
                        name=row[1],
                        added_date=row[2],
                        completed_date=row[3],
                        last_updated=row[4],
                        total_size=row[5],
                        downloaded_bytes=row[6],
                        uploaded_bytes=row[7],
                        download_rate_avg=row[8],
                        upload_rate_avg=row[9],
                        category=row[10],
                        tags=json.loads(row[11]) if row[11] else [],
                        priority=Priority(row[12]) if row[12] else Priority.NORMAL,
                        torrent_path=row[13] or "",
                        download_path=row[14] or "",
                        final_path=row[15] or "",
                        status=TorrentStatus(row[16]) if row[16] else TorrentStatus.DOWNLOADING,
                        error_message=row[17] or "",
                        seed_ratio=row[18] or 0.0,
                        active_time=row[19] or 0.0,
                        share_ratio=row[20] or 0.0
                    )

                    self._add_to_memory(history)

                except Exception as e:
                    logger.warning(f"Ошибка загрузки истории торрента {row[0]}: {e}")

            # Загрузка событий
            cursor.execute("SELECT * FROM history_events")
            event_rows = cursor.fetchall()

            for row in event_rows:
                try:
                    event = HistoryEvent(
                        event_id=row[0],
                        info_hash=row[1],
                        event_type=HistoryEventType(row[2]),
                        timestamp=row[3],
                        data=json.loads(row[4]) if row[4] else {},
                        description=row[5] or ""
                    )

                    self._events.append(event)

                    # Добавление события в соответствующий торрент
                    if event.info_hash in self._history:
                        self._history[event.info_hash].events.append(event)

                except Exception as e:
                    logger.warning(f"Ошибка загрузки события {row[0]}: {e}")

            # Очистка устаревших данных
            if self._auto_cleanup:
                self._cleanup_old_data()

            logger.info(f"Загружено {len(self._history)} записей истории и {len(self._events)} событий")

        except Exception as e:
            logger.error(f"Ошибка загрузки истории: {e}")
            raise HistoryError(f"Не удалось загрузить историю: {e}")

    def _add_to_memory(self, history: TorrentHistory) -> None:
        """Добавление записи в память и обновление индексов"""
        with self._lock:
            self._history[history.info_hash] = history

            # Обновление индексов
            self._category_index[history.category].add(history.info_hash)

            for tag in history.tags:
                self._tag_index[tag].add(history.info_hash)

            self._status_index[history.status].add(history.info_hash)

            # Индекс по дате (формат: YYYY-MM-DD)
            date_key = datetime.fromtimestamp(history.added_date).strftime('%Y-%m-%d')
            self._date_index[date_key].add(history.info_hash)

    def _cleanup_old_data(self) -> None:
        """Очистка устаревших данных"""
        try:
            cutoff_time = time.time() - (self._retention_days * 24 * 3600)

            cursor = self._db_connection.cursor()

            # Удаление старых торрентов
            cursor.execute(
                "DELETE FROM torrents_history WHERE added_date < ? AND completed_date IS NOT NULL",
                (cutoff_time,)
            )
            torrents_deleted = cursor.rowcount

            # Удаление старых событий
            cursor.execute(
                "DELETE FROM history_events WHERE timestamp < ?",
                (cutoff_time,)
            )
            events_deleted = cursor.rowcount

            self._db_connection.commit()

            # Обновление памяти
            with self._lock:
                to_remove = []
                for info_hash, history in self._history.items():
                    if history.added_date < cutoff_time and history.completed_date is not None:
                        to_remove.append(info_hash)

                for info_hash in to_remove:
                    self._remove_from_memory(info_hash)

            if torrents_deleted > 0 or events_deleted > 0:
                logger.info(f"Очищено устаревших данных: {torrents_deleted} торрентов, {events_deleted} событий")

        except Exception as e:
            logger.error(f"Ошибка очистки устаревших данных: {e}")

    def _remove_from_memory(self, info_hash: str) -> None:
        """Удаление записи из памяти и индексов"""
        with self._lock:
            if info_hash in self._history:
                history = self._history[info_hash]

                # Удаление из индексов
                if history.category in self._category_index:
                    self._category_index[history.category].discard(info_hash)

                for tag in history.tags:
                    if tag in self._tag_index:
                        self._tag_index[tag].discard(info_hash)

                if history.status in self._status_index:
                    self._status_index[history.status].discard(info_hash)

                date_key = datetime.fromtimestamp(history.added_date).strftime('%Y-%m-%d')
                if date_key in self._date_index:
                    self._date_index[date_key].discard(info_hash)

                # Удаление из основного хранилища
                del self._history[info_hash]

    def add_torrent(self, info_hash: str, name: str, torrent_path: str = "",
                    download_path: str = "", category: str = "default",
                    tags: List[str] = None, priority: Priority = Priority.NORMAL) -> None:
        """
        Добавление торрента в историю

        Args:
            info_hash: Хеш торрента
            name: Название торрента
            torrent_path: Путь к торрент-файлу
            download_path: Путь для загрузки
            category: Категория
            tags: Список тегов
            priority: Приоритет
        """
        try:
            current_time = time.time()
            tags = tags or []

            history = TorrentHistory(
                info_hash=info_hash,
                name=name,
                added_date=current_time,
                last_updated=current_time,
                torrent_path=torrent_path,
                download_path=download_path,
                category=category,
                tags=tags,
                priority=priority,
                status=TorrentStatus.DOWNLOADING
            )

            # Сохранение в память
            self._add_to_memory(history)

            # Сохранение в базу данных
            self._save_torrent_to_db(history)

            # Создание события
            event = HistoryEvent(
                event_id=f"add_{info_hash}_{current_time}",
                info_hash=info_hash,
                event_type=HistoryEventType.ADDED,
                timestamp=current_time,
                description=f"Торрент '{name}' добавлен в историю"
            )
            self._add_event(event)

            logger.info(f"Торрент добавлен в историю: {name} ({info_hash})")

        except Exception as e:
            logger.error(f"Ошибка добавления торрента в историю: {e}")
            raise HistoryError(f"Не удалось добавить торрент в историю: {e}")

    def _save_torrent_to_db(self, history: TorrentHistory) -> None:
        """Сохранение торрента в базу данных"""
        try:
            cursor = self._db_connection.cursor()

            cursor.execute("""
                INSERT OR REPLACE INTO torrents_history 
                (info_hash, name, added_date, completed_date, last_updated, total_size,
                 downloaded_bytes, uploaded_bytes, download_rate_avg, upload_rate_avg,
                 category, tags, priority, torrent_path, download_path, final_path,
                 status, error_message, seed_ratio, active_time, share_ratio)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                history.info_hash,
                history.name,
                history.added_date,
                history.completed_date,
                history.last_updated,
                history.total_size,
                history.downloaded_bytes,
                history.uploaded_bytes,
                history.download_rate_avg,
                history.upload_rate_avg,
                history.category,
                json.dumps(history.tags),
                history.priority.value,
                history.torrent_path,
                history.download_path,
                history.final_path,
                history.status.value,
                history.error_message,
                history.seed_ratio,
                history.active_time,
                history.share_ratio
            ))

            self._db_connection.commit()

        except Exception as e:
            logger.error(f"Ошибка сохранения торрента в базу данных: {e}")
            raise

    def update_torrent(self, info_hash: str, updates: Dict[str, Any]) -> None:
        """
        Обновление информации о торренте

        Args:
            info_hash: Хеш торрента
            updates: Словарь с обновлениями
        """
        try:
            with self._lock:
                if info_hash not in self._history:
                    raise HistoryError(f"Торрент {info_hash} не найден в истории")

                history = self._history[info_hash]

                # Применение обновлений
                for key, value in updates.items():
                    if hasattr(history, key):
                        setattr(history, key, value)

                history.last_updated = time.time()

                # Обновление индексов если нужно
                if 'category' in updates:
                    old_category = history.category
                    new_category = updates['category']

                    if old_category in self._category_index:
                        self._category_index[old_category].discard(info_hash)
                    self._category_index[new_category].add(info_hash)

                if 'tags' in updates:
                    # Удаление старых тегов из индекса
                    for tag in history.tags:
                        if tag in self._tag_index:
                            self._tag_index[tag].discard(info_hash)

                    # Добавление новых тегов в индекс
                    for tag in updates['tags']:
                        self._tag_index[tag].add(info_hash)

                if 'status' in updates:
                    old_status = history.status
                    new_status = updates['status']

                    if old_status in self._status_index:
                        self._status_index[old_status].discard(info_hash)
                    self._status_index[new_status].add(info_hash)

            # Сохранение в базу данных
            self._save_torrent_to_db(history)

            logger.debug(f"Обновлена история торрента: {info_hash}")

        except Exception as e:
            logger.error(f"Ошибка обновления истории торрента {info_hash}: {e}")
            raise HistoryError(f"Не удалось обновить историю торрента: {e}")

    def complete_torrent(self, info_hash: str, final_path: str = "") -> None:
        """
        Отметка торрента как завершенного

        Args:
            info_hash: Хеш торрента
            final_path: Финальный путь к файлам
        """
        try:
            current_time = time.time()

            updates = {
                'completed_date': current_time,
                'status': TorrentStatus.COMPLETED,
                'final_path': final_path
            }

            self.update_torrent(info_hash, updates)

            # Создание события завершения
            event = HistoryEvent(
                event_id=f"complete_{info_hash}_{current_time}",
                info_hash=info_hash,
                event_type=HistoryEventType.COMPLETED,
                timestamp=current_time,
                description=f"Торрент завершен"
            )
            self._add_event(event)

            logger.info(f"Торрент отмечен как завершенный: {info_hash}")

        except Exception as e:
            logger.error(f"Ошибка отметки завершения торрента {info_hash}: {e}")
            raise HistoryError(f"Не удалось отметить торрент как завершенный: {e}")

    def remove_torrent(self, info_hash: str) -> None:
        """
        Удаление торрента из истории

        Args:
            info_hash: Хеш торрента для удаления
        """
        try:
            with self._lock:
                if info_hash not in self._history:
                    return

                # Создание события удаления
                event = HistoryEvent(
                    event_id=f"remove_{info_hash}_{time.time()}",
                    info_hash=info_hash,
                    event_type=HistoryEventType.REMOVED,
                    timestamp=time.time(),
                    description=f"Торрент удален из истории"
                )
                self._add_event(event)

                # Удаление из базы данных
                cursor = self._db_connection.cursor()
                cursor.execute("DELETE FROM torrents_history WHERE info_hash = ?", (info_hash,))
                cursor.execute("DELETE FROM history_events WHERE info_hash = ?", (info_hash,))
                self._db_connection.commit()

                # Удаление из памяти
                self._remove_from_memory(info_hash)

            logger.info(f"Торрент удален из истории: {info_hash}")

        except Exception as e:
            logger.error(f"Ошибка удаления торрента из истории {info_hash}: {e}")
            raise HistoryError(f"Не удалось удалить торрент из истории: {e}")

    def _add_event(self, event: HistoryEvent) -> None:
        """Добавление события в историю"""
        try:
            self._events.append(event)

            # Добавление события в соответствующий торрент
            if event.info_hash in self._history:
                self._history[event.info_hash].events.append(event)

            # Сохранение в базу данных
            cursor = self._db_connection.cursor()
            cursor.execute("""
                INSERT INTO history_events 
                (event_id, info_hash, event_type, timestamp, data, description)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                event.event_id,
                event.info_hash,
                event.event_type.value,
                event.timestamp,
                json.dumps(event.data),
                event.description
            ))

            self._db_connection.commit()

        except Exception as e:
            logger.error(f"Ошибка добавления события в историю: {e}")
            raise HistoryError(f"Не удалось добавить событие в историю: {e}")

    def get_torrent_history(self, info_hash: str) -> Optional[TorrentHistory]:
        """Получение истории конкретного торрента"""
        with self._lock:
            return self._history.get(info_hash)

    def get_all_history(self, limit: int = 1000, offset: int = 0) -> List[TorrentHistory]:
        """Получение всей истории с пагинацией"""
        with self._lock:
            histories = list(self._history.values())
            histories.sort(key=lambda x: x.added_date, reverse=True)
            return histories[offset:offset + limit]

    def search_history(self, query: str, field: str = "name") -> List[TorrentHistory]:
        """
        Поиск в истории

        Args:
            query: Поисковый запрос
            field: Поле для поиска (name, category, tags)

        Returns:
            Список найденных записей
        """
        try:
            results = []
            query_lower = query.lower()

            with self._lock:
                for history in self._history.values():
                    if field == "name" and query_lower in history.name.lower():
                        results.append(history)
                    elif field == "category" and query_lower in history.category.lower():
                        results.append(history)
                    elif field == "tags" and any(query_lower in tag.lower() for tag in history.tags):
                        results.append(history)

            results.sort(key=lambda x: x.added_date, reverse=True)
            return results

        except Exception as e:
            logger.error(f"Ошибка поиска в истории: {e}")
            return []

    def get_torrents_by_category(self, category: str) -> List[TorrentHistory]:
        """Получение торрентов по категории"""
        with self._lock:
            if category not in self._category_index:
                return []

            return [
                self._history[info_hash]
                for info_hash in self._category_index[category]
            ]

    def get_torrents_by_tag(self, tag: str) -> List[TorrentHistory]:
        """Получение торрентов по тегу"""
        with self._lock:
            if tag not in self._tag_index:
                return []

            return [
                self._history[info_hash]
                for info_hash in self._tag_index[tag]
            ]

    def get_torrents_by_status(self, status: TorrentStatus) -> List[TorrentHistory]:
        """Получение торрентов по статусу"""
        with self._lock:
            if status not in self._status_index:
                return []

            return [
                self._history[info_hash]
                for info_hash in self._status_index[status]
            ]

    def get_completed_torrents(self) -> List[TorrentHistory]:
        """Получение завершенных торрентов"""
        with self._lock:
            return [
                history for history in self._history.values()
                if history.completed_date is not None
            ]

    def get_torrent_events(self, info_hash: str, limit: int = 100) -> List[HistoryEvent]:
        """Получение событий торрента"""
        try:
            cursor = self._db_connection.cursor()
            cursor.execute("""
                SELECT * FROM history_events 
                WHERE info_hash = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (info_hash, limit))

            events = []
            for row in cursor.fetchall():
                event = HistoryEvent(
                    event_id=row[0],
                    info_hash=row[1],
                    event_type=HistoryEventType(row[2]),
                    timestamp=row[3],
                    data=json.loads(row[4]) if row[4] else {},
                    description=row[5] or ""
                )
                events.append(event)

            return events

        except Exception as e:
            logger.error(f"Ошибка получения событий торрента {info_hash}: {e}")
            return []

    def get_statistics(self) -> Dict[str, Any]:
        """Получение статистики по истории"""
        try:
            with self._lock:
                total_torrents = len(self._history)
                completed_torrents = len(self.get_completed_torrents())

                total_downloaded = sum(h.downloaded_bytes for h in self._history.values())
                total_uploaded = sum(h.uploaded_bytes for h in self._history.values())

                # Статистика по категориям
                category_stats = {}
                for category, info_hashes in self._category_index.items():
                    category_torrents = [self._history[h] for h in info_hashes]
                    category_stats[category] = {
                        'count': len(category_torrents),
                        'total_size': sum(t.total_size for t in category_torrents),
                        'completed': len([t for t in category_torrents if t.completed_date])
                    }

                # Статистика по времени
                now = time.time()
                last_week = now - (7 * 24 * 3600)
                last_month = now - (30 * 24 * 3600)

                recent_torrents = [
                    h for h in self._history.values()
                    if h.added_date >= last_week
                ]
                monthly_torrents = [
                    h for h in self._history.values()
                    if h.added_date >= last_month
                ]

                return {
                    'total_torrents': total_torrents,
                    'completed_torrents': completed_torrents,
                    'completion_rate': completed_torrents / total_torrents if total_torrents > 0 else 0,
                    'total_downloaded': total_downloaded,
                    'total_uploaded': total_uploaded,
                    'share_ratio': total_uploaded / total_downloaded if total_downloaded > 0 else 0,
                    'categories': category_stats,
                    'recent_added': len(recent_torrents),
                    'monthly_added': len(monthly_torrents),
                    'average_active_time': statistics.mean(
                        [h.active_time for h in self._history.values()]) if self._history else 0
                }

        except Exception as e:
            logger.error(f"Ошибка получения статистики истории: {e}")
            return {}

    def export_history(self, export_path: str, format: str = "json") -> bool:
        """
        Экспорт истории в файл

        Args:
            export_path: Путь для экспорта
            format: Формат экспорта (json, csv)

        Returns:
            Успешность операции
        """
        try:
            if format == "json":
                return self._export_json(export_path)
            elif format == "csv":
                return self._export_csv(export_path)
            else:
                raise HistoryError(f"Неподдерживаемый формат экспорта: {format}")

        except Exception as e:
            logger.error(f"Ошибка экспорта истории: {e}")
            return False

    def _export_json(self, export_path: str) -> bool:
        """Экспорт истории в JSON"""
        try:
            export_data = {
                'export_time': datetime.now().isoformat(),
                'version': '1.0',
                'torrents': [asdict(history) for history in self._history.values()],
                'statistics': self.get_statistics()
            }

            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"История экспортирована в JSON: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта истории в JSON: {e}")
            return False

    def _export_csv(self, export_path: str) -> bool:
        """Экспорт истории в CSV"""
        try:
            import csv

            with open(export_path, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)

                # Заголовки
                writer.writerow([
                    'Info Hash', 'Name', 'Added Date', 'Completed Date', 'Category',
                    'Status', 'Total Size', 'Downloaded', 'Uploaded', 'Share Ratio',
                    'Tags', 'Download Path'
                ])

                # Данные
                for history in self._history.values():
                    writer.writerow([
                        history.info_hash,
                        history.name,
                        datetime.fromtimestamp(history.added_date).isoformat(),
                        datetime.fromtimestamp(history.completed_date).isoformat() if history.completed_date else '',
                        history.category,
                        history.status.value,
                        history.total_size,
                        history.downloaded_bytes,
                        history.uploaded_bytes,
                        history.share_ratio,
                        ';'.join(history.tags),
                        history.download_path
                    ])

            logger.info(f"История экспортирована в CSV: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта истории в CSV: {e}")
            return False

    def cleanup_old_torrents(self, days: int = None) -> int:
        """
        Очистка старых торрентов

        Args:
            days: Количество дней (использует настройку по умолчанию если None)

        Returns:
            Количество удаленных торрентов
        """
        try:
            retention_days = days or self._retention_days
            self._retention_days = retention_days

            # Обновление настройки в конфигурации
            self.config_service.set('history_retention_days', retention_days)

            # Вызов очистки
            self._cleanup_old_data()

            # Подсчет оставшихся торрентов для возврата
            with self._lock:
                return len(self._history)

        except Exception as e:
            logger.error(f"Ошибка очистки старых торрентов: {e}")
            return 0

    def get_history_size(self) -> Dict[str, int]:
        """Получение информации о размере истории"""
        try:
            cursor = self._db_connection.cursor()

            # Размер таблиц
            cursor.execute("SELECT COUNT(*) FROM torrents_history")
            torrents_count = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM history_events")
            events_count = cursor.fetchone()[0]

            # Размер файла базы данных
            db_size = self._db_path.stat().st_size if self._db_path.exists() else 0

            return {
                'torrents_count': torrents_count,
                'events_count': events_count,
                'db_size_bytes': db_size,
                'memory_torrents': len(self._history),
                'memory_events': len(self._events)
            }

        except Exception as e:
            logger.error(f"Ошибка получения размера истории: {e}")
            return {}

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы HistoryService...")

        try:
            # Создание резервной копии базы данных
            if self._db_path and self._db_path.exists():
                backup_path = self._db_path.with_suffix('.backup.db')
                import shutil
                shutil.copy2(self._db_path, backup_path)
                logger.info(f"Создана резервная копия истории: {backup_path}")

            # Закрытие соединения с базой данных
            if self._db_connection:
                self._db_connection.close()

        except Exception as e:
            logger.error(f"Ошибка при завершении HistoryService: {e}")

        logger.info("HistoryService завершен")