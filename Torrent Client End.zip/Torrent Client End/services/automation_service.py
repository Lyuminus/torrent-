"""
AUTOMATION SERVICE - Сервис автоматизации и правил

Отвечает за создание, управление и выполнение автоматических правил для торрентов.
Обеспечивает триггеры по событиям, времени и условиям с гибкой системой действий.
Поддерживает планировщик задач и сложные workflow.
"""

import logging
import time
import threading
from typing import Dict, List, Optional, Any, Set, Callable, Union
from threading import RLock, Timer
from dataclasses import dataclass, asdict, field
from enum import Enum
from datetime import datetime, timedelta
import json
import re

from ..models.exceptions import AutomationError
from ..models.torrent import TorrentStatus, Priority

logger = logging.getLogger(__name__)


class TriggerType(Enum):
    """Типы триггеров для автоматизации"""
    TORRENT_ADDED = "torrent_added"
    TORRENT_COMPLETED = "torrent_completed"
    TORRENT_PAUSED = "torrent_paused"
    TORRENT_RESUMED = "torrent_resumed"
    TORRENT_REMOVED = "torrent_removed"
    TORRENT_ERROR = "torrent_error"
    SCHEDULED_TIME = "scheduled_time"
    INTERVAL = "interval"
    DISK_SPACE_LOW = "disk_space_low"
    SPEED_THRESHOLD = "speed_threshold"
    RATIO_ACHIEVED = "ratio_achieved"
    CATEGORY_CHANGE = "category_change"


class ActionType(Enum):
    """Типы действий для автоматизации"""
    PAUSE_TORRENT = "pause_torrent"
    RESUME_TORRENT = "resume_torrent"
    REMOVE_TORRENT = "remove_torrent"
    DELETE_TORRENT = "delete_torrent"
    CHANGE_PRIORITY = "change_priority"
    CHANGE_CATEGORY = "change_category"
    APPLY_TAGS = "apply_tags"
    MOVE_STORAGE = "move_storage"
    SET_LIMITS = "set_limits"
    SEND_NOTIFICATION = "send_notification"
    EXECUTE_SCRIPT = "execute_script"
    STOP_ALL = "stop_all"
    START_ALL = "start_all"
    REANNOUNCE = "reannounce"
    FORCE_RECHECK = "force_recheck"


class ConditionOperator(Enum):
    """Операторы для условий"""
    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    STARTS_WITH = "starts_with"
    ENDS_WITH = "ends_with"
    MATCHES_REGEX = "matches_regex"
    IN_LIST = "in_list"
    NOT_IN_LIST = "not_in_list"


@dataclass
class Condition:
    """Условие для выполнения правила"""
    field: str  # Поле для проверки (name, size, category, etc.)
    operator: ConditionOperator
    value: Any  # Значение для сравнения
    value_type: str = "string"  # Тип значения: string, number, boolean


@dataclass
class Action:
    """Действие для выполнения"""
    action_type: ActionType
    parameters: Dict[str, Any] = field(default_factory=dict)
    delay_seconds: int = 0  # Задержка выполнения в секундах


@dataclass
class AutomationRule:
    """Правило автоматизации"""
    rule_id: str
    name: str
    description: str = ""
    enabled: bool = True
    trigger: TriggerType = TriggerType.TORRENT_ADDED
    trigger_conditions: List[Condition] = field(default_factory=list)
    execution_conditions: List[Condition] = field(default_factory=list)
    actions: List[Action] = field(default_factory=list)
    match_all_conditions: bool = True  # True = AND, False = OR

    # Настройки выполнения
    max_executions: int = 0  # 0 = без ограничений
    cooldown_seconds: int = 0  # Задержка между выполнениями
    execution_count: int = 0  # Счетчик выполнений

    # Временные параметры для триггеров SCHEDULED_TIME и INTERVAL
    schedule_time: str = ""  # Время в формате HH:MM
    interval_minutes: int = 0  # Интервал в минутах
    days_of_week: List[int] = field(default_factory=list)  # 0-6 (пн-вс)

    created_at: float = field(default_factory=time.time)
    last_executed: Optional[float] = None


class AutomationService:
    """
    Сервис автоматизации с поддержкой сложных правил и планировщика
    """

    def __init__(self, config_service, history_service):
        self.config_service = config_service
        self.history_service = history_service

        # Потокобезопасные структуры
        self._lock = RLock()
        self._rules: Dict[str, AutomationRule] = {}
        self._active_timers: Dict[str, Timer] = {}
        self._rule_execution_history: Dict[str, List[Dict]] = {}

        # Колбэки для внешних интеграций
        self._torrent_callbacks: Dict[TriggerType, List[Callable]] = {
            trigger: [] for trigger in TriggerType
        }

        # Система планировщика
        self._scheduler_running = False
        self._scheduler_thread: Optional[threading.Thread] = None

        # Кэш для условий
        self._condition_cache: Dict[str, Any] = {}

        # Инициализация
        self._load_rules()
        self._start_scheduler()

        logger.info("AutomationService инициализирован")

    def _load_rules(self) -> None:
        """Загрузка правил из конфигурации"""
        try:
            rules_data = self.config_service.get('automation.rules', {})

            for rule_id, rule_dict in rules_data.items():
                try:
                    # Восстановление условий
                    trigger_conditions = [
                        Condition(**cond) for cond in rule_dict.get('trigger_conditions', [])
                    ]
                    execution_conditions = [
                        Condition(**cond) for cond in rule_dict.get('execution_conditions', [])
                    ]

                    # Восстановление действий
                    actions = [
                        Action(
                            action_type=ActionType(action['action_type']),
                            parameters=action.get('parameters', {}),
                            delay_seconds=action.get('delay_seconds', 0)
                        ) for action in rule_dict.get('actions', [])
                    ]

                    rule = AutomationRule(
                        rule_id=rule_id,
                        name=rule_dict['name'],
                        description=rule_dict.get('description', ''),
                        enabled=rule_dict.get('enabled', True),
                        trigger=TriggerType(rule_dict['trigger']),
                        trigger_conditions=trigger_conditions,
                        execution_conditions=execution_conditions,
                        actions=actions,
                        match_all_conditions=rule_dict.get('match_all_conditions', True),
                        max_executions=rule_dict.get('max_executions', 0),
                        cooldown_seconds=rule_dict.get('cooldown_seconds', 0),
                        execution_count=rule_dict.get('execution_count', 0),
                        schedule_time=rule_dict.get('schedule_time', ''),
                        interval_minutes=rule_dict.get('interval_minutes', 0),
                        days_of_week=rule_dict.get('days_of_week', []),
                        created_at=rule_dict.get('created_at', time.time()),
                        last_executed=rule_dict.get('last_executed')
                    )

                    self._rules[rule_id] = rule

                    # Запуск таймеров для временных триггеров
                    if rule.enabled:
                        self._setup_rule_timers(rule)

                except Exception as e:
                    logger.error(f"Ошибка загрузки правила {rule_id}: {e}")

            logger.info(f"Загружено правил автоматизации: {len(self._rules)}")

        except Exception as e:
            logger.error(f"Ошибка загрузки правил автоматизации: {e}")

    def _save_rules(self) -> None:
        """Сохранение правил в конфигурацию"""
        try:
            rules_data = {}

            for rule_id, rule in self._rules.items():
                rule_dict = asdict(rule)

                # Конвертация enum в строки
                rule_dict['trigger'] = rule.trigger.value
                rule_dict['trigger_conditions'] = [
                    {**asdict(cond), 'operator': cond.operator.value}
                    for cond in rule.trigger_conditions
                ]
                rule_dict['execution_conditions'] = [
                    {**asdict(cond), 'operator': cond.operator.value}
                    for cond in rule.execution_conditions
                ]
                rule_dict['actions'] = [
                    {**asdict(action), 'action_type': action.action_type.value}
                    for action in rule.actions
                ]

                rules_data[rule_id] = rule_dict

            self.config_service.set('automation.rules', rules_data)
            logger.debug("Правила автоматизации сохранены")

        except Exception as e:
            logger.error(f"Ошибка сохранения правил автоматизации: {e}")

    def _start_scheduler(self) -> None:
        """Запуск фонового планировщика"""

        def scheduler_worker():
            logger.info("Планировщик автоматизации запущен")

            while self._scheduler_running:
                try:
                    current_time = datetime.now()

                    # Проверка правил с триггерами по времени
                    with self._lock:
                        for rule in self._rules.values():
                            if not rule.enabled:
                                continue

                            if rule.trigger == TriggerType.SCHEDULED_TIME:
                                self._check_scheduled_rule(rule, current_time)
                            elif rule.trigger == TriggerType.INTERVAL:
                                self._check_interval_rule(rule, current_time)

                    time.sleep(30)  # Проверка каждые 30 секунд

                except Exception as e:
                    logger.error(f"Ошибка в планировщике автоматизации: {e}")
                    time.sleep(10)

            logger.info("Планировщик автоматизации остановлен")

        self._scheduler_running = True
        self._scheduler_thread = threading.Thread(
            target=scheduler_worker,
            daemon=True,
            name="AutomationScheduler"
        )
        self._scheduler_thread.start()

    def _check_scheduled_rule(self, rule: AutomationRule, current_time: datetime) -> None:
        """Проверка правила с триггером по расписанию"""
        try:
            if not rule.schedule_time:
                return

            # Парсинг времени расписания
            schedule_hour, schedule_minute = map(int, rule.schedule_time.split(':'))
            scheduled_time = current_time.replace(
                hour=schedule_hour,
                minute=schedule_minute,
                second=0,
                microsecond=0
            )

            # Проверка дней недели
            if rule.days_of_week and current_time.weekday() not in rule.days_of_week:
                return

            # Проверка, что текущее время в пределах 1 минуты от запланированного
            time_diff = abs((current_time - scheduled_time).total_seconds())
            if time_diff <= 30:  # 30 секунд окно
                # Проверка, что правило не выполнялось сегодня
                last_executed = rule.last_executed
                if last_executed:
                    last_exec_date = datetime.fromtimestamp(last_executed).date()
                    if last_exec_date == current_time.date():
                        return

                self._execute_rule(rule, {"trigger_time": current_time.isoformat()})

        except Exception as e:
            logger.error(f"Ошибка проверки расписания для правила {rule.name}: {e}")

    def _check_interval_rule(self, rule: AutomationRule, current_time: datetime) -> None:
        """Проверка правила с интервальным триггером"""
        try:
            if rule.interval_minutes <= 0:
                return

            # Проверка времени последнего выполнения
            last_executed = rule.last_executed
            if last_executed:
                next_execution = last_executed + (rule.interval_minutes * 60)
                if time.time() < next_execution:
                    return

            # Первое выполнение или время пришло
            self._execute_rule(rule, {"trigger_time": current_time.isoformat()})

        except Exception as e:
            logger.error(f"Ошибка проверки интервала для правила {rule.name}: {e}")

    def _setup_rule_timers(self, rule: AutomationRule) -> None:
        """Настройка таймеров для правила"""
        try:
            # Очистка существующих таймеров
            if rule.rule_id in self._active_timers:
                self._active_timers[rule.rule_id].cancel()
                del self._active_timers[rule.rule_id]

            # Для интервальных правил создаем периодический таймер
            if rule.trigger == TriggerType.INTERVAL and rule.interval_minutes > 0:
                timer = Timer(
                    rule.interval_minutes * 60,
                    self._on_interval_trigger,
                    [rule.rule_id]
                )
                timer.daemon = True
                timer.start()
                self._active_timers[rule.rule_id] = timer

        except Exception as e:
            logger.error(f"Ошибка настройки таймеров для правила {rule.rule_id}: {e}")

    def _on_interval_trigger(self, rule_id: str) -> None:
        """Обработчик интервального триггера"""
        try:
            with self._lock:
                rule = self._rules.get(rule_id)
                if not rule or not rule.enabled:
                    return

            self._execute_rule(rule, {"trigger_type": "interval"})

            # Перезапуск таймера
            self._setup_rule_timers(rule)

        except Exception as e:
            logger.error(f"Ошибка интервального триггера для правила {rule_id}: {e}")

    def create_rule(self, rule: AutomationRule) -> str:
        """
        Создание нового правила автоматизации

        Args:
            rule: Правило для создания

        Returns:
            ID созданного правила
        """
        try:
            with self._lock:
                # Генерация ID если не указан
                if not rule.rule_id:
                    rule.rule_id = f"rule_{int(time.time())}_{len(self._rules)}"

                # Проверка уникальности ID
                if rule.rule_id in self._rules:
                    raise AutomationError(f"Правило с ID {rule.rule_id} уже существует")

                self._rules[rule.rule_id] = rule

                # Настройка таймеров если правило активно
                if rule.enabled:
                    self._setup_rule_timers(rule)

                # Сохранение в конфигурацию
                self._save_rules()

            logger.info(f"Создано правило автоматизации: {rule.name} ({rule.rule_id})")
            return rule.rule_id

        except Exception as e:
            logger.error(f"Ошибка создания правила автоматизации: {e}")
            raise AutomationError(f"Не удалось создать правило: {e}")

    def update_rule(self, rule_id: str, updates: Dict[str, Any]) -> bool:
        """
        Обновление правила автоматизации

        Args:
            rule_id: ID правила
            updates: Обновления для применения

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if rule_id not in self._rules:
                    raise AutomationError(f"Правило {rule_id} не найдено")

                rule = self._rules[rule_id]

                # Применение обновлений
                for key, value in updates.items():
                    if hasattr(rule, key):
                        setattr(rule, key, value)

                # Перезапуск таймеров если правило активно
                if rule.enabled:
                    self._setup_rule_timers(rule)

                # Сохранение в конфигурацию
                self._save_rules()

            logger.info(f"Обновлено правило автоматизации: {rule_id}")
            return True

        except Exception as e:
            logger.error(f"Ошибка обновления правила {rule_id}: {e}")
            return False

    def delete_rule(self, rule_id: str) -> bool:
        """
        Удаление правила автоматизации

        Args:
            rule_id: ID правила для удаления

        Returns:
            Успешность операции
        """
        try:
            with self._lock:
                if rule_id not in self._rules:
                    return False

                # Остановка таймеров
                if rule_id in self._active_timers:
                    self._active_timers[rule_id].cancel()
                    del self._active_timers[rule_id]

                # Удаление правила
                del self._rules[rule_id]

                # Сохранение в конфигурацию
                self._save_rules()

            logger.info(f"Удалено правило автоматизации: {rule_id}")
            return True

        except Exception as e:
            logger.error(f"Ошибка удаления правила {rule_id}: {e}")
            return False

    def enable_rule(self, rule_id: str) -> bool:
        """Включение правила"""
        return self.update_rule(rule_id, {'enabled': True})

    def disable_rule(self, rule_id: str) -> bool:
        """Отключение правила"""
        try:
            with self._lock:
                if rule_id in self._active_timers:
                    self._active_timers[rule_id].cancel()
                    del self._active_timers[rule_id]

            return self.update_rule(rule_id, {'enabled': False})
        except Exception as e:
            logger.error(f"Ошибка отключения правила {rule_id}: {e}")
            return False

    def get_rule(self, rule_id: str) -> Optional[AutomationRule]:
        """Получение правила по ID"""
        with self._lock:
            return self._rules.get(rule_id)

    def get_all_rules(self) -> List[AutomationRule]:
        """Получение всех правил"""
        with self._lock:
            return list(self._rules.values())

    def get_rules_by_trigger(self, trigger_type: TriggerType) -> List[AutomationRule]:
        """Получение правил по типу триггера"""
        with self._lock:
            return [
                rule for rule in self._rules.values()
                if rule.trigger == trigger_type and rule.enabled
            ]

    def on_torrent_event(self, trigger_type: TriggerType, torrent_data: Dict[str, Any]) -> None:
        """
        Обработчик событий торрента

        Args:
            trigger_type: Тип события
            torrent_data: Данные торрента
        """
        try:
            rules = self.get_rules_by_trigger(trigger_type)

            for rule in rules:
                # Проверка условий триггера
                if self._check_conditions(rule.trigger_conditions, torrent_data, rule.match_all_conditions):
                    # Проверка условий выполнения
                    execution_context = {
                        **torrent_data,
                        'trigger_type': trigger_type.value,
                        'timestamp': time.time()
                    }

                    if self._check_conditions(rule.execution_conditions, execution_context, rule.match_all_conditions):
                        self._execute_rule(rule, execution_context)

        except Exception as e:
            logger.error(f"Ошибка обработки события {trigger_type}: {e}")

    def _check_conditions(self, conditions: List[Condition], context: Dict[str, Any],
                          match_all: bool = True) -> bool:
        """
        Проверка условий

        Args:
            conditions: Список условий для проверки
            context: Контекст с данными для проверки
            match_all: True = все условия должны быть истинны, False = хотя бы одно

        Returns:
            Результат проверки условий
        """
        if not conditions:
            return True

        results = []

        for condition in conditions:
            try:
                # Получение значения из контекста
                field_value = self._get_nested_value(context, condition.field)

                # Приведение типов если нужно
                actual_value = self._convert_value(field_value, condition.value_type)
                expected_value = self._convert_value(condition.value, condition.value_type)

                # Проверка условия
                result = self._evaluate_condition(actual_value, condition.operator, expected_value)
                results.append(result)

            except Exception as e:
                logger.warning(f"Ошибка проверки условия {condition.field}: {e}")
                results.append(False)

        if match_all:
            return all(results)
        else:
            return any(results)

    def _get_nested_value(self, data: Dict[str, Any], field_path: str) -> Any:
        """Получение вложенного значения из словаря"""
        try:
            keys = field_path.split('.')
            value = data

            for key in keys:
                if isinstance(value, dict) and key in value:
                    value = value[key]
                else:
                    return None

            return value
        except Exception:
            return None

    def _convert_value(self, value: Any, value_type: str) -> Any:
        """Приведение значения к указанному типу"""
        if value is None:
            return None

        try:
            if value_type == "number":
                return float(value)
            elif value_type == "boolean":
                return bool(value)
            elif value_type == "string":
                return str(value)
            else:
                return value
        except Exception:
            return value

    def _evaluate_condition(self, actual_value: Any, operator: ConditionOperator,
                            expected_value: Any) -> bool:
        """Вычисление условия"""
        try:
            if operator == ConditionOperator.EQUALS:
                return actual_value == expected_value
            elif operator == ConditionOperator.NOT_EQUALS:
                return actual_value != expected_value
            elif operator == ConditionOperator.GREATER_THAN:
                return actual_value > expected_value
            elif operator == ConditionOperator.LESS_THAN:
                return actual_value < expected_value
            elif operator == ConditionOperator.CONTAINS:
                return expected_value in str(actual_value)
            elif operator == ConditionOperator.NOT_CONTAINS:
                return expected_value not in str(actual_value)
            elif operator == ConditionOperator.STARTS_WITH:
                return str(actual_value).startswith(str(expected_value))
            elif operator == ConditionOperator.ENDS_WITH:
                return str(actual_value).endswith(str(expected_value))
            elif operator == ConditionOperator.MATCHES_REGEX:
                return bool(re.match(str(expected_value), str(actual_value)))
            elif operator == ConditionOperator.IN_LIST:
                return actual_value in expected_value
            elif operator == ConditionOperator.NOT_IN_LIST:
                return actual_value not in expected_value
            else:
                return False
        except Exception:
            return False

    def _execute_rule(self, rule: AutomationRule, context: Dict[str, Any]) -> None:
        """
        Выполнение правила автоматизации

        Args:
            rule: Правило для выполнения
            context: Контекст выполнения
        """
        try:
            # Проверка ограничений выполнения
            if rule.max_executions > 0 and rule.execution_count >= rule.max_executions:
                logger.debug(f"Правило {rule.name} достигло максимального количества выполнений")
                return

            if rule.cooldown_seconds > 0 and rule.last_executed:
                time_since_last = time.time() - rule.last_executed
                if time_since_last < rule.cooldown_seconds:
                    return

            # Обновление статистики правила
            rule.execution_count += 1
            rule.last_executed = time.time()

            # Выполнение действий
            for action in rule.actions:
                if action.delay_seconds > 0:
                    # Отложенное выполнение
                    timer = Timer(
                        action.delay_seconds,
                        self._execute_action,
                        [action, context, rule.rule_id]
                    )
                    timer.daemon = True
                    timer.start()
                else:
                    # Немедленное выполнение
                    self._execute_action(action, context, rule.rule_id)

            # Сохранение истории выполнения
            self._record_execution_history(rule.rule_id, context)

            # Сохранение обновленного правила
            self._save_rules()

            logger.info(f"Выполнено правило автоматизации: {rule.name}")

        except Exception as e:
            logger.error(f"Ошибка выполнения правила {rule.name}: {e}")

    def _execute_action(self, action: Action, context: Dict[str, Any], rule_id: str) -> None:
        """
        Выполнение отдельного действия

        Args:
            action: Действие для выполнения
            context: Контекст выполнения
            rule_id: ID правила
        """
        try:
            # Здесь будут вызываться внешние API для выполнения действий
            # В реальной реализации эти методы будут интегрированы с другими сервисами

            action_result = {
                'action_type': action.action_type.value,
                'parameters': action.parameters,
                'context': context,
                'success': True,
                'timestamp': time.time()
            }

            # Логирование выполнения действия
            logger.debug(f"Выполнение действия {action.action_type.value} для правила {rule_id}")

            # Вызов колбэков для внешней обработки
            self._notify_action_handlers(action, context)

            # Сохранение результата в историю
            self._record_action_history(rule_id, action_result)

        except Exception as e:
            logger.error(f"Ошибка выполнения действия {action.action_type.value}: {e}")

    def _notify_action_handlers(self, action: Action, context: Dict[str, Any]) -> None:
        """Уведомление внешних обработчиков действий"""
        try:
            # В реальной реализации здесь будет интеграция с другими сервисами
            # Например, вызов методов TorrentManager для управления торрентами

            # Заглушка для демонстрации
            pass

        except Exception as e:
            logger.error(f"Ошибка уведомления обработчиков действия: {e}")

    def _record_execution_history(self, rule_id: str, context: Dict[str, Any]) -> None:
        """Запись истории выполнения правила"""
        try:
            execution_record = {
                'timestamp': time.time(),
                'context': context,
                'rule_id': rule_id
            }

            with self._lock:
                if rule_id not in self._rule_execution_history:
                    self._rule_execution_history[rule_id] = []

                self._rule_execution_history[rule_id].append(execution_record)

                # Ограничение размера истории (последние 100 записей)
                if len(self._rule_execution_history[rule_id]) > 100:
                    self._rule_execution_history[rule_id] = self._rule_execution_history[rule_id][-100:]

        except Exception as e:
            logger.error(f"Ошибка записи истории выполнения: {e}")

    def _record_action_history(self, rule_id: str, action_result: Dict[str, Any]) -> None:
        """Запись истории выполнения действия"""
        try:
            with self._lock:
                if rule_id not in self._rule_execution_history:
                    return

                # Добавление результата действия к последнему выполнению правила
                if self._rule_execution_history[rule_id]:
                    last_execution = self._rule_execution_history[rule_id][-1]
                    if 'actions' not in last_execution:
                        last_execution['actions'] = []
                    last_execution['actions'].append(action_result)

        except Exception as e:
            logger.error(f"Ошибка записи истории действия: {e}")

    def get_execution_history(self, rule_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Получение истории выполнения правила"""
        with self._lock:
            if rule_id in self._rule_execution_history:
                return self._rule_execution_history[rule_id][-limit:]
            return []

    def clear_execution_history(self, rule_id: str = None) -> None:
        """Очистка истории выполнения"""
        with self._lock:
            if rule_id:
                if rule_id in self._rule_execution_history:
                    del self._rule_execution_history[rule_id]
            else:
                self._rule_execution_history.clear()

        logger.info("История выполнения очищена")

    def register_action_handler(self, action_type: ActionType, handler: Callable) -> None:
        """Регистрация обработчика действия"""
        # В реальной реализации здесь будет система колбэков
        # Для демонстрации просто логируем
        logger.debug(f"Зарегистрирован обработчик для действия {action_type.value}")

    def test_rule_conditions(self, rule_id: str, test_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Тестирование условий правила

        Args:
            rule_id: ID правила
            test_context: Тестовый контекст

        Returns:
            Результаты тестирования
        """
        try:
            with self._lock:
                rule = self._rules.get(rule_id)
                if not rule:
                    raise AutomationError(f"Правило {rule_id} не найдено")

            results = {
                'trigger_conditions': [],
                'execution_conditions': [],
                'overall_trigger': False,
                'overall_execution': False
            }

            # Тестирование условий триггера
            for condition in rule.trigger_conditions:
                field_value = self._get_nested_value(test_context, condition.field)
                actual_value = self._convert_value(field_value, condition.value_type)
                expected_value = self._convert_value(condition.value, condition.value_type)

                result = self._evaluate_condition(actual_value, condition.operator, expected_value)

                results['trigger_conditions'].append({
                    'condition': asdict(condition),
                    'actual_value': actual_value,
                    'expected_value': expected_value,
                    'result': result
                })

            # Тестирование условий выполнения
            for condition in rule.execution_conditions:
                field_value = self._get_nested_value(test_context, condition.field)
                actual_value = self._convert_value(field_value, condition.value_type)
                expected_value = self._convert_value(condition.value, condition.value_type)

                result = self._evaluate_condition(actual_value, condition.operator, expected_value)

                results['execution_conditions'].append({
                    'condition': asdict(condition),
                    'actual_value': actual_value,
                    'expected_value': expected_value,
                    'result': result
                })

            # Общие результаты
            trigger_results = [cond['result'] for cond in results['trigger_conditions']]
            execution_results = [cond['result'] for cond in results['execution_conditions']]

            if rule.match_all_conditions:
                results['overall_trigger'] = all(trigger_results) if trigger_results else True
                results['overall_execution'] = all(execution_results) if execution_results else True
            else:
                results['overall_trigger'] = any(trigger_results) if trigger_results else True
                results['overall_execution'] = any(execution_results) if execution_results else True

            return results

        except Exception as e:
            logger.error(f"Ошибка тестирования правила {rule_id}: {e}")
            raise AutomationError(f"Не удалось протестировать правило: {e}")

    def get_automation_statistics(self) -> Dict[str, Any]:
        """Получение статистики автоматизации"""
        with self._lock:
            total_rules = len(self._rules)
            enabled_rules = len([r for r in self._rules.values() if r.enabled])
            total_executions = sum(rule.execution_count for rule in self._rules.values())

            # Статистика по триггерам
            trigger_stats = {}
            for trigger in TriggerType:
                trigger_stats[trigger.value] = len(self.get_rules_by_trigger(trigger))

            # Статистика по действиям
            action_stats = {}
            for rule in self._rules.values():
                for action in rule.actions:
                    action_type = action.action_type.value
                    action_stats[action_type] = action_stats.get(action_type, 0) + 1

            return {
                'total_rules': total_rules,
                'enabled_rules': enabled_rules,
                'disabled_rules': total_rules - enabled_rules,
                'total_executions': total_executions,
                'trigger_statistics': trigger_stats,
                'action_statistics': action_stats,
                'active_timers': len(self._active_timers),
                'history_entries': sum(len(h) for h in self._rule_execution_history.values())
            }

    def export_rules(self, export_path: str) -> bool:
        """Экспорт правил в файл"""
        try:
            export_data = {
                'export_time': datetime.now().isoformat(),
                'version': '1.0',
                'rules': {
                    rule_id: asdict(rule) for rule_id, rule in self._rules.items()
                }
            }

            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Правила экспортированы: {export_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта правил: {e}")
            return False

    def import_rules(self, import_path: str, overwrite: bool = False) -> bool:
        """Импорт правил из файла"""
        try:
            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)

            imported_count = 0

            with self._lock:
                if overwrite:
                    self._rules.clear()

                for rule_id, rule_dict in import_data.get('rules', {}).items():
                    try:
                        # Создание объекта правила
                        rule = AutomationRule(**rule_dict)

                        # Обновление ID если нужно
                        if not overwrite and rule_id in self._rules:
                            rule.rule_id = f"{rule_id}_imported_{int(time.time())}"
                        else:
                            rule.rule_id = rule_id

                        self._rules[rule.rule_id] = rule
                        imported_count += 1

                    except Exception as e:
                        logger.warning(f"Ошибка импорта правила {rule_id}: {e}")

                # Сохранение и перенастройка таймеров
                self._save_rules()
                for rule in self._rules.values():
                    if rule.enabled:
                        self._setup_rule_timers(rule)

            logger.info(f"Импортировано правил: {imported_count}")
            return True

        except Exception as e:
            logger.error(f"Ошибка импорта правил: {e}")
            return False

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы AutomationService...")

        # Остановка планировщика
        self._scheduler_running = False

        if self._scheduler_thread and self._scheduler_thread.is_alive():
            self._scheduler_thread.join(timeout=5)

        # Остановка всех таймеров
        with self._lock:
            for timer in self._active_timers.values():
                timer.cancel()
            self._active_timers.clear()

        # Сохранение правил
        self._save_rules()

        # Очистка структур
        with self._lock:
            self._rules.clear()
            self._rule_execution_history.clear()
            self._condition_cache.clear()

        logger.info("AutomationService завершен")