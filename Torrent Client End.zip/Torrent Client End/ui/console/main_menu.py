"""
MAIN MENU - Главное меню консольного интерфейса

Содержит основную логику консольного интерфейса и главное меню.
"""

import os
import sys
import time
from typing import Dict, Any, List, Optional
from threading import Thread, Event

from ..base_interface import BaseInterface
from .torrent_views import TorrentViews
from .settings_views import SettingsViews
from .help_views import HelpViews


class ConsoleInterface(BaseInterface):
    """
    Консольный интерфейс торрент-клиента
    """

    def __init__(self, config: Dict[str, Any], core_components: Dict[str, Any],
                 services: Dict[str, Any]):
        super().__init__(config, core_components, services)

        # Компоненты интерфейса
        self.torrent_views = TorrentViews(self)
        self.settings_views = SettingsViews(self)
        self.help_views = HelpViews(self)

        # Состояние интерфейса
        self.current_view = "main"
        self.refresh_interval = 2  # секунды
        self.auto_refresh = True
        self.stop_event = Event()
        self.refresh_thread = None

    def initialize(self) -> bool:
        """Инициализация консольного интерфейса"""
        try:
            # Очистка экрана
            self.clear_screen()

            # Запуск фонового обновления
            self.start_auto_refresh()

            self.display_message("Консольный интерфейс инициализирован", "success")
            return True

        except Exception as e:
            self.display_message(f"Ошибка инициализации интерфейса: {e}", "error")
            return False

    def start(self) -> None:
        """Запуск главного цикла интерфейса"""
        self.running = True
        self.display_welcome()

        while self.running:
            try:
                if self.current_view == "main":
                    self.show_main_menu()
                elif self.current_view == "torrents":
                    self.torrent_views.show_torrents_menu()
                elif self.current_view == "settings":
                    self.settings_views.show_settings_menu()
                elif self.current_view == "help":
                    self.help_views.show_help_menu()
                elif self.current_view == "exit":
                    break
                else:
                    self.display_message(f"Неизвестный вид: {self.current_view}", "error")
                    self.current_view = "main"

            except KeyboardInterrupt:
                self.display_message("\nПолучен сигнал прерывания", "warning")
                self.confirm_exit()
            except Exception as e:
                self.display_message(f"Ошибка в интерфейсе: {e}", "error")
                time.sleep(2)
                self.current_view = "main"

    def stop(self) -> None:
        """Остановка интерфейса"""
        self.running = False
        self.stop_event.set()

        if self.refresh_thread and self.refresh_thread.is_alive():
            self.refresh_thread.join(timeout=5)

    def display_message(self, message: str, message_type: str = "info") -> None:
        """Отображение сообщения"""
        colors = {
            "info": "\033[94m",  # Синий
            "success": "\033[92m",  # Зеленый
            "warning": "\033[93m",  # Желтый
            "error": "\033[91m",  # Красный
            "reset": "\033[0m"  # Сброс
        }

        color = colors.get(message_type, colors["info"])
        print(f"{color}[{message_type.upper()}] {message}{colors['reset']}")

    def get_user_input(self, prompt: str, input_type: type = str) -> Any:
        """Получение ввода от пользователя"""
        try:
            user_input = input(f"\033[96m{prompt}:\033[0m ").strip()

            if input_type == str:
                return user_input
            elif input_type == int:
                return int(user_input) if user_input else 0
            elif input_type == float:
                return float(user_input) if user_input else 0.0
            elif input_type == bool:
                return user_input.lower() in ('y', 'yes', 'true', '1', 'да')
            else:
                return user_input

        except (ValueError, TypeError):
            self.display_message("Неверный формат ввода", "error")
            return None
        except KeyboardInterrupt:
            raise
        except Exception as e:
            self.display_message(f"Ошибка ввода: {e}", "error")
            return None

    def update_display(self) -> None:
        """Обновление отображения (вызывается автоматически)"""
        if self.current_view == "main":
            self.display_main_screen()

    def clear_screen(self) -> None:
        """Очистка экрана консоли"""
        os.system('cls' if os.name == 'nt' else 'clear')

    def display_welcome(self) -> None:
        """Отображение приветственного экрана"""
        self.clear_screen()
        print("\033[95m" + "=" * 60)
        print("           TORRENT CLIENT v8.0 - КОНСОЛЬНЫЙ ИНТЕРФЕЙС")
        print("=" * 60 + "\033[0m")
        print()

    def show_main_menu(self) -> None:
        """Отображение главного меню"""
        self.display_main_screen()

        print("\n\033[93mГЛАВНОЕ МЕНЮ:\033[0m")
        print("1. Управление торрентами")
        print("2. Настройки")
        print("3. Справка")
        print("4. Выход")
        print()

        choice = self.get_user_input("Выберите действие (1-4)", int)

        if choice == 1:
            self.current_view = "torrents"
        elif choice == 2:
            self.current_view = "settings"
        elif choice == 3:
            self.current_view = "help"
        elif choice == 4:
            self.confirm_exit()
        else:
            self.display_message("Неверный выбор", "warning")

    def display_main_screen(self) -> None:
        """Отображение главного экрана с информацией"""
        self.clear_screen()
        self.display_welcome()

        # Основная информация о системе
        torrent_manager = self.get_torrent_manager()
        session_manager = self.get_session_manager()

        if torrent_manager and session_manager:
            try:
                # Статистика торрентов
                all_torrents = torrent_manager.get_all_torrents_status()
                active_torrents = [t for t in all_torrents if t.status.value in ['downloading', 'seeding']]
                downloading_torrents = [t for t in all_torrents if t.status.value == 'downloading']

                # Статистика сессии
                session_stats = session_manager.get_session_stats()

                print("\033[92mТЕКУЩАЯ СТАТИСТИКА:\033[0m")
                print(f"Всего торрентов: {len(all_torrents)}")
                print(f"Активных: {len(active_torrents)}")
                print(f"Загружаются: {len(downloading_torrents)}")
                print(f"Скорость загрузки: {self.format_speed(session_stats.download_rate)}")
                print(f"Скорость отдачи: {self.format_speed(session_stats.upload_rate)}")
                print(f"Пиров: {session_stats.num_peers}")

            except Exception as e:
                self.display_message(f"Ошибка получения статистики: {e}", "error")

        print("\n" + "\033[90m" + "=" * 60 + "\033[0m")

    def confirm_exit(self) -> None:
        """Подтверждение выхода"""
        confirm = self.get_user_input("Вы уверены, что хотите выйти? (y/N)", str)
        if confirm and confirm.lower() in ('y', 'yes', 'да'):
            self.current_view = "exit"
            self.running = False
        else:
            self.current_view = "main"

    def start_auto_refresh(self) -> None:
        """Запуск автоматического обновления интерфейса"""

        def refresh_worker():
            while not self.stop_event.is_set():
                try:
                    if self.auto_refresh and self.running:
                        self.update_display()
                    self.stop_event.wait(self.refresh_interval)
                except Exception as e:
                    self.display_message(f"Ошибка автообновления: {e}", "error")
                    self.stop_event.wait(5)  # Подождать 5 секунд при ошибке

        self.refresh_thread = Thread(target=refresh_worker, daemon=True)
        self.refresh_thread.start()

    def format_speed(self, speed_bytes: int) -> str:
        """Форматирование скорости"""
        if speed_bytes == 0:
            return "0 B/s"

        units = ["B/s", "KB/s", "MB/s", "GB/s"]
        unit_index = 0
        speed = float(speed_bytes)

        while speed >= 1024 and unit_index < len(units) - 1:
            speed /= 1024
            unit_index += 1

        return f"{speed:.2f} {units[unit_index]}"

    def format_size(self, size_bytes: int) -> str:
        """Форматирование размера"""
        if size_bytes == 0:
            return "0 B"

        units = ["B", "KB", "MB", "GB", "TB"]
        unit_index = 0
        size = float(size_bytes)

        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1

        return f"{size:.2f} {units[unit_index]}"