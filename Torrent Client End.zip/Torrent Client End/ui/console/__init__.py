"""
CONSOLE UI - Консольный пользовательский интерфейс

Содержит компоненты для работы с консольным интерфейсом торрент-клиента.
"""

from .main_menu import ConsoleInterface
from .torrent_views import TorrentViews
from .settings_views import SettingsViews
from .help_views import HelpViews

__all__ = ['ConsoleInterface', 'TorrentViews', 'SettingsViews', 'HelpViews']