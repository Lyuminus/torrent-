"""
TORRENT VIEWS - Представления для управления торрентами

Содержит экраны и меню для работы с торрентами.
"""

import os
from typing import List, Dict, Any
from pathlib import Path

from ..base_interface import BaseInterface
from ...models.torrent import TorrentStatus, Priority


class TorrentViews:
    """Представления для управления торрентами"""

    def __init__(self, interface: BaseInterface):
        self.interface = interface

    def show_torrents_menu(self) -> None:
        """Меню управления торрентами"""
        self.display_torrents_list()

        print("\n\033[93mУПРАВЛЕНИЕ ТОРРЕНТАМИ:\033[0m")
        print("1. Добавить торрент")
        print("2. Добавить магнет-ссылку")
        print("3. Приостановить/возобновить торрент")
        print("4. Удалить торрент")
        print("5. Подробная информация о торренте")
        print("6. Обновить список")
        print("7. Назад в главное меню")
        print()

        choice = self.interface.get_user_input("Выберите действие (1-7)", int)

        if choice == 1:
            self.add_torrent_file()
        elif choice == 2:
            self.add_magnet_link()
        elif choice == 3:
            self.toggle_torrent_pause()
        elif choice == 4:
            self.remove_torrent()
        elif choice == 5:
            self.show_torrent_details()
        elif choice == 6:
            return  # Просто обновим список
        elif choice == 7:
            self.interface.current_view = "main"
        else:
            self.interface.display_message("Неверный выбор", "warning")

    def display_torrents_list(self) -> None:
        """Отображение списка торрентов"""
        self.interface.clear_screen()
        print("\033[95m" + "=" * 60)
        print("                   СПИСОК ТОРРЕНТОВ")
        print("=" * 60 + "\033[0m")
        print()

        torrent_manager = self.interface.get_torrent_manager()
        if not torrent_manager:
            self.interface.display_message("Менеджер торрентов не доступен", "error")
            return

        try:
            torrents = torrent_manager.get_all_torrents_status()

            if not torrents:
                self.interface.display_message("Нет активных торрентов", "info")
                return

            print(f"{'ID':<3} {'Статус':<12} {'Прогресс':<8} {'Скорость':<12} {'Название'}")
            print("-" * 80)

            for i, torrent in enumerate(torrents):
                status_color = self.get_status_color(torrent.status)
                progress_bar = self.create_progress_bar(torrent.progress)
                speed_info = f"↓{self.interface.format_speed(torrent.download_rate)} ↑{self.interface.format_speed(torrent.upload_rate)}"

                print(
                    f"{i + 1:<3} {status_color}{torrent.status.value:<12}\033[0m {progress_bar} {speed_info:<12} {torrent.name[:50]}")

        except Exception as e:
            self.interface.display_message(f"Ошибка получения списка торрентов: {e}", "error")

    def add_torrent_file(self) -> None:
        """Добавление торрента из файла"""
        print("\n\033[93mДОБАВЛЕНИЕ ТОРРЕНТА ИЗ ФАЙЛА:\033[0m")

        file_path = self.interface.get_user_input("Путь к .torrent файлу")
        if not file_path:
            return

        # Проверка существования файла
        if not os.path.exists(file_path):
            self.interface.display_message("Файл не существует", "error")
            return

        # Проверка безопасности
        security_service = self.interface.get_security_service()
        if security_service:
            scan_result = security_service.scan_torrent_file(file_path)
            if scan_result.security_level.value == "malicious":
                self.interface.display_message("Файл признан опасным!", "error")
                self.interface.display_message(f"Причина: {', '.join([t.value for t in scan_result.threats])}",
                                               "warning")
                confirm = self.interface.get_user_input("Все равно добавить? (y/N)", str)
                if not confirm or confirm.lower() not in ('y', 'yes', 'да'):
                    return

        # Получение пути для загрузки
        download_path = self.interface.get_user_input("Путь для загрузки (оставьте пустым для папки по умолчанию)")
        if not download_path:
            config_service = self.interface.get_config_service()
            if config_service:
                download_path = config_service.get('downloads_path')

        # Добавление торрента
        torrent_manager = self.interface.get_torrent_manager()
        if torrent_manager:
            try:
                from ...core.torrent_manager import AddTorrentParams

                params = AddTorrentParams(
                    save_path=download_path,
                    paused=False
                )

                result = torrent_manager.add_torrent_from_file(file_path, params)

                if result.value == "success":
                    self.interface.display_message("Торрент успешно добавлен", "success")

                    # Добавление в историю
                    history_service = self.interface.get_history_service()
                    if history_service:
                        # Получим info_hash добавленного торрента
                        # Это упрощенная реализация - в реальности нужно получить хеш из результата
                        history_service.add_torrent(
                            info_hash="",  # Нужно получить из результата
                            name=Path(file_path).stem,
                            torrent_path=file_path,
                            download_path=download_path
                        )

                else:
                    self.interface.display_message(f"Ошибка добавления торрента: {result.value}", "error")

            except Exception as e:
                self.interface.display_message(f"Ошибка добавления торрента: {e}", "error")

    def add_magnet_link(self) -> None:
        """Добавление торрента из магнет-ссылки"""
        print("\n\033[93mДОБАВЛЕНИЕ ТОРРЕНТА ИЗ МАГНЕТ-ССЫЛКИ:\033[0m")

        magnet_link = self.interface.get_user_input("Магнет-ссылка")
        if not magnet_link:
            return

        # Проверка безопасности
        security_service = self.interface.get_security_service()
        if security_service:
            scan_result = security_service.scan_magnet_link(magnet_link)
            if scan_result.security_level.value == "malicious":
                self.interface.display_message("Магнет-ссылка признана опасной!", "error")
                self.interface.display_message(f"Причина: {', '.join([t.value for t in scan_result.threats])}",
                                               "warning")
                confirm = self.interface.get_user_input("Все равно добавить? (y/N)", str)
                if not confirm or confirm.lower() not in ('y', 'yes', 'да'):
                    return

        # Получение пути для загрузки
        download_path = self.interface.get_user_input("Путь для загрузки (оставьте пустым для папки по умолчанию)")
        if not download_path:
            config_service = self.interface.get_config_service()
            if config_service:
                download_path = config_service.get('downloads_path')

        # Добавление торрента
        torrent_manager = self.interface.get_torrent_manager()
        if torrent_manager:
            try:
                from ...core.torrent_manager import AddTorrentParams

                params = AddTorrentParams(
                    save_path=download_path,
                    paused=False
                )

                result = torrent_manager.add_torrent_from_magnet(magnet_link, params)

                if result.value == "success":
                    self.interface.display_message("Торрент успешно добавлен", "success")
                else:
                    self.interface.display_message(f"Ошибка добавления торрента: {result.value}", "error")

            except Exception as e:
                self.interface.display_message(f"Ошибка добавления торрента: {e}", "error")

    def toggle_torrent_pause(self) -> None:
        """Приостановка/возобновление торрента"""
        torrent_id = self.interface.get_user_input("ID торрента для приостановки/возобновления", int)
        if not torrent_id:
            return

        torrent_manager = self.interface.get_torrent_manager()
        if not torrent_manager:
            return

        try:
            torrents = torrent_manager.get_all_torrents_status()
            if torrent_id < 1 or torrent_id > len(torrents):
                self.interface.display_message("Неверный ID торрента", "error")
                return

            torrent = torrents[torrent_id - 1]

            if torrent.status in [TorrentStatus.PAUSED, TorrentStatus.ERROR]:
                # Возобновление
                if torrent_manager.resume_torrent(torrent.info_hash):
                    self.interface.display_message("Торрент возобновлен", "success")
                else:
                    self.interface.display_message("Ошибка возобновления торрента", "error")
            else:
                # Приостановка
                if torrent_manager.pause_torrent(torrent.info_hash):
                    self.interface.display_message("Торрент приостановлен", "success")
                else:
                    self.interface.display_message("Ошибка приостановки торрента", "error")

        except Exception as e:
            self.interface.display_message(f"Ошибка управления торрентом: {e}", "error")

    def remove_torrent(self) -> None:
        """Удаление торрента"""
        torrent_id = self.interface.get_user_input("ID торрента для удаления", int)
        if not torrent_id:
            return

        delete_files = self.interface.get_user_input("Удалить файлы? (y/N)", str)
        delete_files = delete_files and delete_files.lower() in ('y', 'yes', 'да')

        torrent_manager = self.interface.get_torrent_manager()
        if not torrent_manager:
            return

        try:
            torrents = torrent_manager.get_all_torrents_status()
            if torrent_id < 1 or torrent_id > len(torrents):
                self.interface.display_message("Неверный ID торрента", "error")
                return

            torrent = torrents[torrent_id - 1]

            if torrent_manager.remove_torrent(torrent.info_hash, delete_files):
                self.interface.display_message("Торрент удален", "success")
            else:
                self.interface.display_message("Ошибка удаления торрента", "error")

        except Exception as e:
            self.interface.display_message(f"Ошибка удаления торрента: {e}", "error")

    def show_torrent_details(self) -> None:
        """Показать подробную информацию о торренте"""
        torrent_id = self.interface.get_user_input("ID торрента для просмотра", int)
        if not torrent_id:
            return

        torrent_manager = self.interface.get_torrent_manager()
        if not torrent_manager:
            return

        try:
            torrents = torrent_manager.get_all_torrents_status()
            if torrent_id < 1 or torrent_id > len(torrents):
                self.interface.display_message("Неверный ID торрента", "error")
                return

            torrent = torrents[torrent_id - 1]

            self.interface.clear_screen()
            print("\033[95m" + "=" * 60)
            print(f"           ИНФОРМАЦИЯ О ТОРРЕНТЕ: {torrent.name}")
            print("=" * 60 + "\033[0m")
            print()

            print(f"Название: {torrent.name}")
            print(f"Хеш: {torrent.info_hash}")
            print(f"Статус: {self.get_status_color(torrent.status)}{torrent.status.value}\033[0m")
            print(f"Прогресс: {torrent.progress * 100:.1f}%")
            print(f"Размер: {self.interface.format_size(torrent.total_size)}")
            print(f"Загружено: {self.interface.format_size(torrent.total_downloaded)}")
            print(f"Отдано: {self.interface.format_size(torrent.total_uploaded)}")
            print(f"Скорость загрузки: {self.interface.format_speed(torrent.download_rate)}")
            print(f"Скорость отдачи: {self.interface.format_speed(torrent.upload_rate)}")
            print(f"Пиры: {torrent.peers} (сиды: {torrent.seeds})")
            print(f"ETA: {self.format_eta(torrent.eta)}")
            print(f"Путь загрузки: {torrent.download_path}")
            print(f"Категория: {torrent.category}")
            print(f"Теги: {', '.join(torrent.tags)}")

            # Информация о файлах
            files = torrent_manager.get_torrent_files(torrent.info_hash)
            if files:
                print(f"\nФайлы ({len(files)}):")
                for file in files:
                    progress = (file['progress'] / file['size']) * 100 if file['size'] > 0 else 0
                    print(f"  {file['path']} - {self.interface.format_size(file['size'])} - {progress:.1f}%")

            print("\nНажмите Enter для возврата...")
            input()

        except Exception as e:
            self.interface.display_message(f"Ошибка получения информации о торренте: {e}", "error")

    def get_status_color(self, status: TorrentStatus) -> str:
        """Получение цвета для статуса"""
        colors = {
            TorrentStatus.DOWNLOADING: "\033[92m",  # Зеленый
            TorrentStatus.SEEDING: "\033[96m",  # Голубой
            TorrentStatus.PAUSED: "\033[93m",  # Желтый
            TorrentStatus.CHECKING: "\033[94m",  # Синий
            TorrentStatus.COMPLETED: "\033[92m",  # Зеленый
            TorrentStatus.ERROR: "\033[91m",  # Красный
            TorrentStatus.UNKNOWN: "\033[90m"  # Серый
        }
        return colors.get(status, "\033[0m")

    def create_progress_bar(self, progress: float, width: int = 20) -> str:
        """Создание строки прогресс-бара"""
        filled = int(width * progress)
        empty = width - filled
        return f"[{'#' * filled}{'.' * empty}] {progress * 100:.1f}%"

    def format_eta(self, seconds: int) -> str:
        """Форматирование ETA"""
        if seconds <= 0:
            return "Неизвестно"

        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        else:
            return f"{minutes:02d}:{seconds:02d}"