"""
SETTINGS VIEWS - Представления для настроек

Содержит экраны и меню для управления настройками приложения.
"""

from typing import Dict, Any


class SettingsViews:
    """Представления для управления настройками"""

    def __init__(self, interface):
        self.interface = interface

    def show_settings_menu(self) -> None:
        """Меню настроек"""
        self.display_settings_info()

        print("\n\033[93mНАСТРОЙКИ:\033[0m")
        print("1. Сетевые настройки")
        print("2. Настройки производительности")
        print("3. Настройки интерфейса")
        print("4. Настройки безопасности")
        print("5. Автоматизация")
        print("6. Интеграции")
        print("7. Назад в главное меню")
        print()

        choice = self.interface.get_user_input("Выберите действие (1-7)", int)

        if choice == 1:
            self.show_network_settings()
        elif choice == 2:
            self.show_performance_settings()
        elif choice == 3:
            self.show_ui_settings()
        elif choice == 4:
            self.show_security_settings()
        elif choice == 5:
            self.show_automation_settings()
        elif choice == 6:
            self.show_integration_settings()
        elif choice == 7:
            self.interface.current_view = "main"
        else:
            self.interface.display_message("Неверный выбор", "warning")

    def display_settings_info(self) -> None:
        """Отображение информации о текущих настройках"""
        self.interface.clear_screen()
        print("\033[95m" + "=" * 60)
        print("                      НАСТРОЙКИ")
        print("=" * 60 + "\033[0m")
        print()

        config_service = self.interface.get_config_service()
        if not config_service:
            self.interface.display_message("Сервис конфигурации не доступен", "error")
            return

        try:
            # Основные настройки
            downloads_path = config_service.get('downloads_path', 'Не установлено')
            listen_port = config_service.get('network.listen_port', 6881)
            max_downloads = config_service.get('performance.max_downloads', 5)

            print("\033[92mТЕКУЩИЕ НАСТРОЙКИ:\033[0m")
            print(f"Папка загрузок: {downloads_path}")
            print(f"Порт: {listen_port}")
            print(f"Макс. загрузок: {max_downloads}")

        except Exception as e:
            self.interface.display_message(f"Ошибка получения настроек: {e}", "error")

    def show_network_settings(self) -> None:
        """Настройки сети"""
        print("\n\033[93mСЕТЕВЫЕ НАСТРОЙКИ:\033[0m")

        config_service = self.interface.get_config_service()
        if not config_service:
            return

        try:
            current_port = config_service.get('network.listen_port', 6881)
            print(f"Текущий порт: {current_port}")

            new_port = self.interface.get_user_input("Новый порт (оставьте пустым для сохранения текущего)", int)
            if new_port is not None:
                if new_port == 0:  # Пользователь оставил пустым
                    new_port = current_port

                if 1024 <= new_port <= 65535:
                    config_service.set('network.listen_port', new_port)

                    # Применение настроек к сессии
                    session_manager = self.interface.get_session_manager()
                    if session_manager:
                        session_manager.update_settings({'listen_port': new_port})

                    self.interface.display_message("Настройки сети обновлены", "success")
                else:
                    self.interface.display_message("Порт должен быть в диапазоне 1024-65535", "error")

        except Exception as e:
            self.interface.display_message(f"Ошибка обновления сетевых настроек: {e}", "error")

    def show_performance_settings(self) -> None:
        """Настройки производительности"""
        print("\n\033[93mНАСТРОЙКИ ПРОИЗВОДИТЕЛЬНОСТИ:\033[0m")

        config_service = self.interface.get_config_service()
        if not config_service:
            return

        try:
            current_max_downloads = config_service.get('performance.max_downloads', 5)
            print(f"Текущее макс. количество загрузок: {current_max_downloads}")

            new_max_downloads = self.interface.get_user_input(
                "Новое значение (оставьте пустым для сохранения текущего)", int)
            if new_max_downloads is not None:
                if new_max_downloads == 0:  # Пользователь оставил пустым
                    new_max_downloads = current_max_downloads

                if new_max_downloads > 0:
                    config_service.set('performance.max_downloads', new_max_downloads)

                    # Применение настроек к сессии
                    session_manager = self.interface.get_session_manager()
                    if session_manager:
                        session_manager.update_settings({'max_downloads': new_max_downloads})

                    self.interface.display_message("Настройки производительности обновлены", "success")
                else:
                    self.interface.display_message("Значение должно быть положительным", "error")

        except Exception as e:
            self.interface.display_message(f"Ошибка обновления настроек производительности: {e}", "error")

    def show_ui_settings(self) -> None:
        """Настройки интерфейса"""
        print("\n\033[93mНАСТРОЙКИ ИНТЕРФЕЙСА:\033[0m")

        config_service = self.interface.get_config_service()
        if not config_service:
            return

        try:
            current_refresh = self.interface.refresh_interval
            print(f"Текущий интервал обновления: {current_refresh} сек.")

            new_refresh = self.interface.get_user_input(
                "Новый интервал обновления в секундах (оставьте пустым для сохранения текущего)", int)
            if new_refresh is not None:
                if new_refresh == 0:  # Пользователь оставил пустым
                    new_refresh = current_refresh

                if new_refresh > 0:
                    self.interface.refresh_interval = new_refresh
                    self.interface.display_message("Интервал обновления изменен", "success")
                else:
                    self.interface.display_message("Интервал должен быть положительным", "error")

            # Настройка автообновления
            auto_refresh = self.interface.get_user_input("Включить автообновление? (Y/n)", str)
            if auto_refresh:
                self.interface.auto_refresh = auto_refresh.lower() not in ('n', 'no', 'нет')
                status = "включено" if self.interface.auto_refresh else "выключено"
                self.interface.display_message(f"Автообновление {status}", "success")

        except Exception as e:
            self.interface.display_message(f"Ошибка обновления настроек интерфейса: {e}", "error")

    def show_security_settings(self) -> None:
        """Настройки безопасности"""
        print("\n\033[93mНАСТРОЙКИ БЕЗОПАСНОСТИ:\033[0m")

        security_service = self.interface.get_security_service()
        if not security_service:
            self.interface.display_message("Сервис безопасности не доступен", "error")
            return

        try:
            stats = security_service.get_security_stats()

            print("\033[92mСТАТИСТИКА БЕЗОПАСНОСТИ:\033[0m")
            print(f"Всего проверок: {stats.get('total_scans', 0)}")
            print(f"Обнаружено угроз: {stats.get('threats_detected', 0)}")
            print(f"IP в черном списке: {stats.get('ip_blacklist_size', 0)}")
            print(f"Хешей в черном списке: {stats.get('hash_blacklist_size', 0)}")

            print("\n\033[93mДЕЙСТВИЯ:\033[0m")
            print("1. Добавить в черный список")
            print("2. Очистить кэш проверок")
            print("3. Назад")

            choice = self.interface.get_user_input("Выберите действие (1-3)", int)

            if choice == 1:
                self.add_to_blacklist()
            elif choice == 2:
                security_service.clear_cache()
                self.interface.display_message("Кэш проверок очищен", "success")

        except Exception as e:
            self.interface.display_message(f"Ошибка работы с настройками безопасности: {e}", "error")

    def add_to_blacklist(self) -> None:
        """Добавление в черный список"""
        print("\n\033[93mДОБАВЛЕНИЕ В ЧЕРНЫЙ СПИСОК:\033[0m")

        identifier = self.interface.get_user_input("Идентификатор (IP, хеш, домен)")
        if not identifier:
            return

        print("Типы:")
        print("1. IP адрес")
        print("2. Хеш торрента")
        print("3. Домен")
        print("4. URL трекера")

        type_choice = self.interface.get_user_input("Выберите тип (1-4)", int)

        type_map = {
            1: 'ip',
            2: 'hash',
            3: 'domain',
            4: 'tracker'
        }

        entry_type = type_map.get(type_choice)
        if not entry_type:
            self.interface.display_message("Неверный тип", "error")
            return

        reason = self.interface.get_user_input("Причина блокировки")
        duration = self.interface.get_user_input("Длительность блокировки в часах (0 = навсегда)", int)

        security_service = self.interface.get_security_service()
        if security_service:
            if security_service.add_to_blacklist(identifier, entry_type, reason, duration):
                self.interface.display_message("Запись добавлена в черный список", "success")
            else:
                self.interface.display_message("Ошибка добавления в черный список", "error")

    def show_automation_settings(self) -> None:
        """Настройки автоматизации"""
        print("\n\033[93mНАСТРОЙКИ АВТОМАТИЗАЦИИ:\033[0m")

        automation_service = self.interface.get_automation_service()
        if not automation_service:
            self.interface.display_message("Сервис автоматизации не доступен", "error")
            return

        try:
            stats = automation_service.get_automation_statistics()

            print("\033[92mСТАТИСТИКА АВТОМАТИЗАЦИИ:\033[0m")
            print(f"Всего правил: {stats.get('total_rules', 0)}")
            print(f"Активных правил: {stats.get('enabled_rules', 0)}")
            print(f"Всего выполнений: {stats.get('total_executions', 0)}")

            print("\n\033[93mДЕЙСТВИЯ:\033[0m")
            print("1. Просмотр правил")
            print("2. Создать правило")
            print("3. Назад")

            choice = self.interface.get_user_input("Выберите действие (1-3)", int)

            if choice == 1:
                self.show_automation_rules()
            elif choice == 2:
                self.create_automation_rule()

        except Exception as e:
            self.interface.display_message(f"Ошибка работы с автоматизацией: {e}", "error")

    def show_automation_rules(self) -> None:
        """Просмотр правил автоматизации"""
        automation_service = self.interface.get_automation_service()
        if not automation_service:
            return

        rules = automation_service.get_all_rules()

        if not rules:
            self.interface.display_message("Нет созданных правил", "info")
            return

        print("\n\033[92mСПИСОК ПРАВИЛ:\033[0m")
        for i, rule in enumerate(rules, 1):
            status = "✓" if rule.enabled else "✗"
            print(f"{i}. [{status}] {rule.name} - {rule.trigger.value}")

    def create_automation_rule(self) -> None:
        """Создание правила автоматизации"""
        print("\n\033[93mСОЗДАНИЕ ПРАВИЛА АВТОМАТИЗАЦИИ:\033[0m")
        self.interface.display_message("Функция в разработке", "info")

    def show_integration_settings(self) -> None:
        """Настройки интеграций"""
        print("\n\033[93mНАСТРОЙКИ ИНТЕГРАЦИЙ:\033[0m")

        integration_service = self.interface.get_integration_service()
        if not integration_service:
            self.interface.display_message("Сервис интеграций не доступен", "error")
            return

        try:
            status = integration_service.get_integration_status()

            print("\033[92mСТАТУС ИНТЕГРАЦИЙ:\033[0m")
            notifications = status.get('notifications', {})
            print(f"Уведомления: {'включено' if notifications.get('enabled') else 'выключено'}")
            print(f"Очередь уведомлений: {notifications.get('queue_size', 0)}")

            print(f"Медиа-серверы: {len(status.get('media_servers', {}))}")
            print(f"Вебхуки: {len(status.get('webhooks', {}))}")

            print("\n\033[93mДЕЙСТВИЯ:\033[0m")
            print("1. Настройка уведомлений")
            print("2. Настройка медиа-серверов")
            print("3. Назад")

            choice = self.interface.get_user_input("Выберите действие (1-3)", int)

            if choice == 1:
                self.configure_notifications()
            elif choice == 2:
                self.configure_media_servers()

        except Exception as e:
            self.interface.display_message(f"Ошибка работы с интеграциями: {e}", "error")

    def configure_notifications(self) -> None:
        """Настройка уведомлений"""
        print("\n\033[93mНАСТРОЙКА УВЕДОМЛЕНИЙ:\033[0m")
        self.interface.display_message("Функция в разработке", "info")

    def configure_media_servers(self) -> None:
        """Настройка медиа-серверов"""
        print("\n\033[93mНАСТРОЙКА МЕДИА-СЕРВЕРОВ:\033[0m")
        self.interface.display_message("Функция в разработке", "info")