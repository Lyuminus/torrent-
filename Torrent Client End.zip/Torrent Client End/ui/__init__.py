"""
UI MODULE - Модуль пользовательского интерфейса

Содержит интерфейсы для взаимодействия с пользователем:
- Консольный интерфейс (console)
- Веб-интерфейс (web) - заготовка на будущее
- API интерфейс (api) - заготовка на будущее
"""

from .base_interface import BaseInterface
from .console.main_menu import ConsoleInterface


# Фабрика для создания интерфейсов
def create_interface(interface_type: str = "console", **kwargs):
    """
    Создание интерфейса указанного типа

    Args:
        interface_type: Тип интерфейса ('console', 'web', 'api')
        **kwargs: Дополнительные параметры

    Returns:
        Экземпляр интерфейса
    """
    if interface_type == "console":
        return ConsoleInterface(**kwargs)
    elif interface_type == "web":
        # Будущая реализация веб-интерфейса
        raise NotImplementedError("Web interface not implemented yet")
    elif interface_type == "api":
        # Будущая реализация API интерфейса
        raise NotImplementedError("API interface not implemented yet")
    else:
        raise ValueError(f"Unknown interface type: {interface_type}")


__all__ = ['BaseInterface', 'ConsoleInterface', 'create_interface']