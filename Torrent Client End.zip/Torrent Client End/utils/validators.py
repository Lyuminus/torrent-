"""
VALIDATORS - Утилиты валидации данных

Содержит функции для валидации путей, IP-адресов, торрент-файлов и других данных.
"""

import os
import re
import ipaddress
from pathlib import Path
from typing import Union


def validate_path(path: Union[str, Path]) -> bool:
    """
    Валидация пути.

    Args:
        path: Путь для проверки

    Returns:
        True если путь валиден, иначе False
    """
    try:
        path = Path(path)
        # Проверка на пустой путь
        if not path:
            return False

        # Проверка на абсолютный путь
        if not path.is_absolute():
            return False

        # Проверка на наличие недопустимых символов (для Windows и Unix)
        invalid_chars = '<>:"|?*' if os.name == 'nt' else '\0'
        if any(char in str(path) for char in invalid_chars):
            return False

        return True

    except Exception:
        return False


def safe_path_join(base_path: Union[str, Path], *paths) -> Path:
    """
    Безопасное объединение путей с защитой от path traversal атак.

    Args:
        base_path: Базовый путь
        *paths: Дополнительные компоненты пути

    Returns:
        Объединенный безопасный путь

    Raises:
        ValueError: Если результирующий путь выходит за пределы базового
    """
    base_path = Path(base_path).resolve()
    full_path = base_path.joinpath(*paths).resolve()

    # Проверка, что полный путь находится внутри базового
    if base_path not in full_path.parents and base_path != full_path:
        raise ValueError(f"Path traversal detected: {full_path} is outside of {base_path}")

    return full_path


def validate_ip_address(ip: str) -> bool:
    """
    Валидация IP-адреса.

    Args:
        ip: IP-адрес для проверки

    Returns:
        True если IP-адрес валиден, иначе False
    """
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def validate_torrent_file(file_path: Union[str, Path]) -> bool:
    """
    Базовая валидация торрент-файла.

    Args:
        file_path: Путь к торрент-файлу

    Returns:
        True если файл похож на валидный торрент, иначе False
    """
    try:
        path = Path(file_path)

        # Проверка расширения
        if path.suffix.lower() != '.torrent':
            return False

        # Проверка существования файла
        if not path.exists() or not path.is_file():
            return False

        # Проверка размера (торрент-файлы обычно не пустые и не гигантские)
        file_size = path.stat().st_size
        if file_size == 0 or file_size > 100 * 1024 * 1024:  # 100 MB
            return False

        # Проверка начала файла (должен начинаться с 'd8:announce' или 'd4:info')
        with open(path, 'rb') as f:
            first_bytes = f.read(100)
            if not first_bytes.startswith(b'd'):
                return False

        return True

    except Exception:
        return False


def validate_port(port: int) -> bool:
    """
    Валидация номера порта.

    Args:
        port: Номер порта

    Returns:
        True если порт валиден, иначе False
    """
    return 1 <= port <= 65535


def validate_magnet_link(magnet_uri: str) -> bool:
    """
    Базовая валидация магнет-ссылки.

    Args:
        magnet_uri: Магнет-ссылка

    Returns:
        True если ссылка похожа на валидную магнет-ссылку, иначе False
    """
    pattern = r'^magnet:\?xt=urn:btih:[a-zA-Z0-9]+.*$'
    return bool(re.match(pattern, magnet_uri))