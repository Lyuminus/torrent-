"""
STATISTICS ENGINE - Движок статистики и аналитики

Отвечает за сбор, агрегацию, анализ и хранение статистических данных.
Обеспечивает мониторинг производительности, прогнозирование и генерацию отчетов.
Интегрирует данные из всех компонентов системы для комплексной аналитики.
"""

import logging
import time
import sqlite3
import json
from typing import Dict, List, Optional, Any, Union, Tuple
from threading import RLock, Thread
from dataclasses import dataclass, asdict, field
from enum import Enum
from collections import defaultdict, deque
from pathlib import Path
import statistics
from datetime import datetime, timedelta

import psutil

from ..models.exceptions import ConfigurationError
from ..utils.formatters import format_size, format_speed, format_duration

logger = logging.getLogger(__name__)


class StatisticType(Enum):
    """Типы собираемой статистики"""
    TORRENT = "torrent"
    SESSION = "session"
    SYSTEM = "system"
    NETWORK = "network"
    STORAGE = "storage"
    PERFORMANCE = "performance"


class TimeRange(Enum):
    """Временные диапазоны для статистики"""
    REAL_TIME = "realtime"
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"
    ALL = "all"


@dataclass
class StatisticPoint:
    """Точка статистических данных"""
    timestamp: float
    value: float
    type: str
    tags: Dict[str, str] = field(default_factory=dict)


@dataclass
class TorrentStatistics:
    """Расширенная статистика торрента"""
    info_hash: str
    name: str
    time_range: TimeRange

    # Основные метрики
    total_downloaded: int = 0
    total_uploaded: int = 0
    average_download_speed: float = 0.0
    average_upload_speed: float = 0.0
    peak_download_speed: float = 0.0
    peak_upload_speed: float = 0.0
    efficiency_ratio: float = 0.0  # uploaded/downloaded

    # Временные метрики
    active_time: float = 0.0  # секунды
    seeding_time: float = 0.0  # секунды
    average_availability: float = 0.0

    # Качественные метрики
    piece_health: float = 0.0  # здоровье частей
    file_completeness: float = 0.0  # полнота файлов
    connection_quality: float = 0.0  # качество соединений

    # Производные показатели
    estimated_completion_time: Optional[float] = None
    predicted_seeding_time: Optional[float] = None
    reliability_score: float = 0.0


@dataclass
class SessionStatistics:
    """Статистика сессии"""
    time_range: TimeRange

    # Сетевые метрики
    total_downloaded: int = 0
    total_uploaded: int = 0
    average_download_speed: float = 0.0
    average_upload_speed: float = 0.0
    peak_download_speed: float = 0.0
    peak_upload_speed: float = 0.0

    # Метрики торрентов
    total_torrents: int = 0
    active_torrents: int = 0
    completed_torrents: int = 0
    seeding_torrents: int = 0

    # Эффективность
    overall_efficiency: float = 0.0
    connection_success_rate: float = 0.0
    piece_retrieval_efficiency: float = 0.0

    # Системные метрики
    memory_usage: float = 0.0
    cpu_usage: float = 0.0
    disk_usage: float = 0.0


@dataclass
class PerformanceMetrics:
    """Метрики производительности"""
    timestamp: float

    # Системные метрики
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_io_read: float = 0.0
    disk_io_write: float = 0.0
    network_io_received: float = 0.0
    network_io_sent: float = 0.0

    # Метрики приложения
    active_connections: int = 0
    torrents_processing: int = 0
    alerts_processed: int = 0
    cache_hit_rate: float = 0.0


class StatisticsEngine:
    """
    Движок статистики с расширенной аналитикой и прогнозированием
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config

        # Потокобезопасные структуры
        self._lock = RLock()
        self._data_points: Dict[str, deque] = defaultdict(lambda: deque(maxlen=10000))
        self._aggregated_data: Dict[str, Dict] = {}

        # База данных для долгосрочного хранения
        self._db_path = Path(config.get('data_path', '.torrent_client')) / "statistics.db"
        self._db_connection: Optional[sqlite3.Connection] = None

        # Кэш для часто запрашиваемых данных
        self._cache: Dict[str, Any] = {}
        self._cache_ttl: Dict[str, float] = {}

        # Настройки
        self._retention_period = config.get('statistics_retention_days', 365)
        self._collection_interval = config.get('statistics_interval', 60)  # секунды

        # Система подписок на обновления
        self._subscribers: Dict[str, List[callable]] = defaultdict(list)

        # Инициализация
        self._initialize_database()
        self._start_collection_worker()

        logger.info("StatisticsEngine инициализирован")

    def _initialize_database(self) -> None:
        """Инициализация базы данных для статистики"""
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)

            self._db_connection = sqlite3.connect(
                str(self._db_path),
                timeout=30,
                check_same_thread=False
            )

            # Включение оптимизаций
            self._db_connection.execute("PRAGMA journal_mode=WAL")
            self._db_connection.execute("PRAGMA synchronous=NORMAL")
            self._db_connection.execute("PRAGMA cache_size=-10000")  # 10MB cache

            # Создание таблиц
            self._create_tables()

            # Очистка устаревших данных
            self._cleanup_old_data()

            logger.info("База данных статистики инициализирована")

        except Exception as e:
            logger.error(f"Ошибка инициализации базы данных: {e}")
            raise ConfigurationError(f"Не удалось инициализировать базу данных статистики: {e}")

    def _create_tables(self) -> None:
        """Создание таблиц базы данных"""
        try:
            cursor = self._db_connection.cursor()

            # Основная таблица точек данных
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS data_points (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    metric_type TEXT NOT NULL,
                    metric_name TEXT NOT NULL,
                    value REAL NOT NULL,
                    tags TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Индексы для быстрого поиска
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_timestamp ON data_points(timestamp)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_metric_type ON data_points(metric_type)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_metric_name ON data_points(metric_name)
            """)

            # Таблица агрегированных данных
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS aggregated_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    time_range TEXT NOT NULL,
                    metric_type TEXT NOT NULL,
                    metric_name TEXT NOT NULL,
                    value REAL NOT NULL,
                    period_start REAL NOT NULL,
                    period_end REAL NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(time_range, metric_type, metric_name, period_start)
                )
            """)

            self._db_connection.commit()

        except Exception as e:
            logger.error(f"Ошибка создания таблиц: {e}")
            raise

    def _cleanup_old_data(self) -> None:
        """Очистка устаревших данных"""
        try:
            cutoff_time = time.time() - (self._retention_period * 24 * 3600)

            cursor = self._db_connection.cursor()
            cursor.execute(
                "DELETE FROM data_points WHERE timestamp < ?",
                (cutoff_time,)
            )

            deleted_count = cursor.rowcount
            self._db_connection.commit()

            if deleted_count > 0:
                logger.info(f"Очищено устаревших точек данных: {deleted_count}")

        except Exception as e:
            logger.error(f"Ошибка очистки устаревших данных: {e}")

    def _start_collection_worker(self) -> None:
        """Запуск фонового сборщика статистики"""

        def collection_worker():
            logger.info("Запуск сборщика статистики")

            while getattr(self, '_collection_active', True):
                try:
                    self._collect_system_metrics()
                    self._aggregate_recent_data()
                    self._cleanup_memory_cache()

                    # Уведомление подписчиков
                    self._notify_subscribers()

                except Exception as e:
                    logger.error(f"Ошибка в сборщике статистики: {e}")

                time.sleep(self._collection_interval)

            logger.info("Сборщик статистики остановлен")

        self._collection_active = True
        self._collection_thread = Thread(
            target=collection_worker,
            daemon=True,
            name="StatisticsCollector"
        )
        self._collection_thread.start()

    def _collect_system_metrics(self) -> None:
        """Сбор системных метрик"""
        try:
            timestamp = time.time()

            # Сбор метрик системы
            cpu_percent = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            disk_io = psutil.disk_io_counters()
            network_io = psutil.net_io_counters()

            metrics = PerformanceMetrics(
                timestamp=timestamp,
                cpu_percent=cpu_percent,
                memory_percent=memory.percent,
                disk_io_read=disk_io.read_bytes if disk_io else 0,
                disk_io_write=disk_io.write_bytes if disk_io else 0,
                network_io_received=network_io.bytes_recv if network_io else 0,
                network_io_sent=network_io.bytes_sent if network_io else 0
            )

            # Сохранение метрик
            self.record_metrics("system", asdict(metrics))

        except Exception as e:
            logger.error(f"Ошибка сбора системных метрик: {e}")

    def record_metrics(self, metric_type: str, metrics: Dict[str, Any], tags: Dict[str, str] = None) -> None:
        """
        Запись метрик в систему

        Args:
            metric_type: Тип метрики (torrent, session, system, etc.)
            metrics: Словарь с метриками
            tags: Дополнительные теги для классификации
        """
        try:
            timestamp = time.time()
            tags = tags or {}

            with self._lock:
                for metric_name, value in metrics.items():
                    if isinstance(value, (int, float)):
                        # Сохранение в память
                        point_key = f"{metric_type}.{metric_name}"
                        point = StatisticPoint(
                            timestamp=timestamp,
                            value=float(value),
                            type=metric_type,
                            tags=tags
                        )
                        self._data_points[point_key].append(point)

                        # Сохранение в базу данных
                        self._save_to_database(point_key, point)

            logger.debug(f"Записаны метрики типа {metric_type}: {len(metrics)} значений")

        except Exception as e:
            logger.error(f"Ошибка записи метрик: {e}")

    def _save_to_database(self, metric_key: str, point: StatisticPoint) -> None:
        """Сохранение точки данных в базу данных"""
        try:
            if not self._db_connection:
                return

            cursor = self._db_connection.cursor()

            # Разбор ключа метрики
            parts = metric_key.split('.')
            metric_type = parts[0] if len(parts) > 0 else 'unknown'
            metric_name = parts[1] if len(parts) > 1 else 'unknown'

            tags_json = json.dumps(point.tags) if point.tags else None

            cursor.execute("""
                INSERT INTO data_points 
                (timestamp, metric_type, metric_name, value, tags)
                VALUES (?, ?, ?, ?, ?)
            """, (point.timestamp, metric_type, metric_name, point.value, tags_json))

            # Периодический коммит для производительности
            if cursor.rowcount % 100 == 0:
                self._db_connection.commit()

        except Exception as e:
            logger.error(f"Ошибка сохранения в базу данных: {e}")

    def _aggregate_recent_data(self) -> None:
        """Агрегация недавних данных для быстрого доступа"""
        try:
            current_time = time.time()
            aggregation_intervals = {
                TimeRange.HOUR: 3600,
                TimeRange.DAY: 86400,
                TimeRange.WEEK: 604800
            }

            for time_range, interval in aggregation_intervals.items():
                cutoff_time = current_time - interval

                with self._lock:
                    for metric_key, points in self._data_points.items():
                        # Фильтрация точек по времени
                        recent_points = [
                            p for p in points
                            if p.timestamp >= cutoff_time
                        ]

                        if recent_points:
                            # Агрегация данных
                            values = [p.value for p in recent_points]

                            aggregated = {
                                'count': len(values),
                                'average': statistics.mean(values) if values else 0,
                                'median': statistics.median(values) if values else 0,
                                'min': min(values) if values else 0,
                                'max': max(values) if values else 0,
                                'std_dev': statistics.stdev(values) if len(values) > 1 else 0
                            }

                            self._aggregated_data[f"{metric_key}.{time_range.value}"] = aggregated

            logger.debug("Агрегация данных завершена")

        except Exception as e:
            logger.error(f"Ошибка агрегации данных: {e}")

    def _cleanup_memory_cache(self) -> None:
        """Очистка устаревших данных из кэша памяти"""
        try:
            current_time = time.time()
            cache_ttl = 300  # 5 минут

            with self._lock:
                expired_keys = [
                    key for key, timestamp in self._cache_ttl.items()
                    if current_time - timestamp > cache_ttl
                ]

                for key in expired_keys:
                    if key in self._cache:
                        del self._cache[key]
                    if key in self._cache_ttl:
                        del self._cache_ttl[key]

                if expired_keys:
                    logger.debug(f"Очищен кэш: {len(expired_keys)} записей")

        except Exception as e:
            logger.error(f"Ошибка очистки кэша: {e}")

    def _notify_subscribers(self) -> None:
        """Уведомление подписчиков о новых данных"""
        try:
            current_time = time.time()

            with self._lock:
                for metric_type, subscribers in self._subscribers.items():
                    if subscribers:
                        # Получение последних данных для метрики
                        recent_data = self.get_recent_stats(metric_type, TimeRange.HOUR)

                        for subscriber in subscribers:
                            try:
                                subscriber(metric_type, recent_data)
                            except Exception as e:
                                logger.error(f"Ошибка в подписчике {metric_type}: {e}")

        except Exception as e:
            logger.error(f"Ошибка уведомления подписчиков: {e}")

    def get_torrent_statistics(self, info_hash: str, time_range: TimeRange) -> TorrentStatistics:
        """
        Получение расширенной статистики торрента

        Args:
            info_hash: Хеш торрента
            time_range: Временной диапазон

        Returns:
            Статистика торрента
        """
        cache_key = f"torrent_stats.{info_hash}.{time_range.value}"

        # Проверка кэша
        cached_result = self._get_cached(cache_key)
        if cached_result:
            return cached_result

        try:
            # Базовые метрики
            download_points = self.get_metric_points(
                f"torrent.{info_hash}.download_rate", time_range
            )
            upload_points = self.get_metric_points(
                f"torrent.{info_hash}.upload_rate", time_range
            )
            progress_points = self.get_metric_points(
                f"torrent.{info_hash}.progress", time_range
            )

            # Расчет метрик
            total_downloaded = sum(p.value for p in download_points) * self._collection_interval
            total_uploaded = sum(p.value for p in upload_points) * self._collection_interval

            download_speeds = [p.value for p in download_points]
            upload_speeds = [p.value for p in upload_points]

            average_download = statistics.mean(download_speeds) if download_speeds else 0
            average_upload = statistics.mean(upload_speeds) if upload_speeds else 0
            peak_download = max(download_speeds) if download_speeds else 0
            peak_upload = max(upload_speeds) if upload_speeds else 0

            efficiency = total_uploaded / total_downloaded if total_downloaded > 0 else 0

            # Расчет временных метрик
            active_time = len(download_points) * self._collection_interval

            # Создание объекта статистики
            stats = TorrentStatistics(
                info_hash=info_hash,
                name=f"Torrent_{info_hash[:8]}",  # В реальности нужно получить имя
                time_range=time_range,
                total_downloaded=total_downloaded,
                total_uploaded=total_uploaded,
                average_download_speed=average_download,
                average_upload_speed=average_upload,
                peak_download_speed=peak_download,
                peak_upload_speed=peak_upload,
                efficiency_ratio=efficiency,
                active_time=active_time,
                seeding_time=active_time * 0.7,  # Примерное значение
                reliability_score=0.85  # Примерное значение
            )

            # Сохранение в кэш
            self._set_cached(cache_key, stats)

            return stats

        except Exception as e:
            logger.error(f"Ошибка получения статистики торрента {info_hash}: {e}")
            return TorrentStatistics(info_hash=info_hash, name="Unknown", time_range=time_range)

    def get_session_statistics(self, time_range: TimeRange) -> SessionStatistics:
        """
        Получение статистики сессии

        Args:
            time_range: Временной диапазон

        Returns:
            Статистика сессии
        """
        cache_key = f"session_stats.{time_range.value}"

        # Проверка кэша
        cached_result = self._get_cached(cache_key)
        if cached_result:
            return cached_result

        try:
            # Получение агрегированных данных
            download_data = self.get_aggregated_metric("session", "total_download", time_range)
            upload_data = self.get_aggregated_metric("session", "total_upload", time_range)

            # Расчет метрик
            total_downloaded = download_data.get('sum', 0) if download_data else 0
            total_uploaded = upload_data.get('sum', 0) if upload_data else 0

            average_download = download_data.get('average', 0) if download_data else 0
            average_upload = upload_data.get('average', 0) if upload_data else 0

            peak_download = download_data.get('max', 0) if download_data else 0
            peak_upload = upload_data.get('max', 0) if upload_data else 0

            efficiency = total_uploaded / total_downloaded if total_downloaded > 0 else 0

            # Системные метрики
            cpu_data = self.get_aggregated_metric("system", "cpu_percent", time_range)
            memory_data = self.get_aggregated_metric("system", "memory_percent", time_range)

            stats = SessionStatistics(
                time_range=time_range,
                total_downloaded=total_downloaded,
                total_uploaded=total_uploaded,
                average_download_speed=average_download,
                average_upload_speed=average_upload,
                peak_download_speed=peak_download,
                peak_upload_speed=peak_upload,
                overall_efficiency=efficiency,
                memory_usage=memory_data.get('average', 0) if memory_data else 0,
                cpu_usage=cpu_data.get('average', 0) if cpu_data else 0
            )

            # Сохранение в кэш
            self._set_cached(cache_key, stats)

            return stats

        except Exception as e:
            logger.error(f"Ошибка получения статистики сессии: {e}")
            return SessionStatistics(time_range=time_range)

    def get_metric_points(self, metric_key: str, time_range: TimeRange) -> List[StatisticPoint]:
        """
        Получение точек данных для метрики

        Args:
            metric_key: Ключ метрики
            time_range: Временной диапазон

        Returns:
            Список точек данных
        """
        try:
            cutoff_time = self._get_cutoff_time(time_range)

            with self._lock:
                if metric_key in self._data_points:
                    points = self._data_points[metric_key]
                    return [p for p in points if p.timestamp >= cutoff_time]

            # Если данных нет в памяти, запрашиваем из базы
            return self._get_points_from_database(metric_key, cutoff_time)

        except Exception as e:
            logger.error(f"Ошибка получения точек данных для {metric_key}: {e}")
            return []

    def _get_points_from_database(self, metric_key: str, cutoff_time: float) -> List[StatisticPoint]:
        """Получение точек данных из базы данных"""
        try:
            if not self._db_connection:
                return []

            parts = metric_key.split('.')
            metric_type = parts[0] if len(parts) > 0 else 'unknown'
            metric_name = parts[1] if len(parts) > 1 else 'unknown'

            cursor = self._db_connection.cursor()
            cursor.execute("""
                SELECT timestamp, value, tags
                FROM data_points
                WHERE metric_type = ? AND metric_name = ? AND timestamp >= ?
                ORDER BY timestamp ASC
            """, (metric_type, metric_name, cutoff_time))

            points = []
            for row in cursor.fetchall():
                timestamp, value, tags_json = row
                tags = json.loads(tags_json) if tags_json else {}

                point = StatisticPoint(
                    timestamp=timestamp,
                    value=value,
                    type=metric_type,
                    tags=tags
                )
                points.append(point)

            return points

        except Exception as e:
            logger.error(f"Ошибка получения точек из базы данных: {e}")
            return []

    def get_aggregated_metric(self, metric_type: str, metric_name: str,
                              time_range: TimeRange) -> Dict[str, float]:
        """
        Получение агрегированных данных по метрике

        Args:
            metric_type: Тип метрики
            metric_name: Имя метрики
            time_range: Временной диапазон

        Returns:
            Агрегированные данные
        """
        cache_key = f"agg_{metric_type}_{metric_name}_{time_range.value}"

        # Проверка кэша
        cached_result = self._get_cached(cache_key)
        if cached_result:
            return cached_result

        try:
            metric_key = f"{metric_type}.{metric_name}"
            points = self.get_metric_points(metric_key, time_range)

            if not points:
                return {}

            values = [p.value for p in points]

            aggregated = {
                'count': len(values),
                'sum': sum(values),
                'average': statistics.mean(values),
                'median': statistics.median(values),
                'min': min(values),
                'max': max(values),
                'std_dev': statistics.stdev(values) if len(values) > 1 else 0,
                'first_value': values[0],
                'last_value': values[-1],
                'change': values[-1] - values[0] if values else 0
            }

            # Сохранение в кэш
            self._set_cached(cache_key, aggregated)

            return aggregated

        except Exception as e:
            logger.error(f"Ошибка агрегации метрики {metric_type}.{metric_name}: {e}")
            return {}

    def get_recent_stats(self, metric_type: str, time_range: TimeRange) -> Dict[str, Any]:
        """
        Получение недавней статистики по типу метрики

        Args:
            metric_type: Тип метрики
            time_range: Временной диапазон

        Returns:
            Словарь с недавней статистикой
        """
        try:
            cutoff_time = self._get_cutoff_time(time_range)

            with self._lock:
                relevant_metrics = {
                    key: points for key, points in self._data_points.items()
                    if key.startswith(f"{metric_type}.") and points
                }

            stats = {}
            for metric_key, points in relevant_metrics.items():
                recent_points = [p for p in points if p.timestamp >= cutoff_time]
                if recent_points:
                    values = [p.value for p in recent_points]
                    stats[metric_key] = {
                        'current': values[-1] if values else 0,
                        'average': statistics.mean(values) if values else 0,
                        'trend': self._calculate_trend(values)
                    }

            return stats

        except Exception as e:
            logger.error(f"Ошибка получения недавней статистики: {e}")
            return {}

    def _get_cutoff_time(self, time_range: TimeRange) -> float:
        """Получение времени отсечки для временного диапазона"""
        current_time = time.time()

        if time_range == TimeRange.REAL_TIME:
            return current_time - 300  # 5 минут
        elif time_range == TimeRange.HOUR:
            return current_time - 3600
        elif time_range == TimeRange.DAY:
            return current_time - 86400
        elif time_range == TimeRange.WEEK:
            return current_time - 604800
        elif time_range == TimeRange.MONTH:
            return current_time - 2592000  # 30 дней
        elif time_range == TimeRange.YEAR:
            return current_time - 31536000  # 365 дней
        else:  # ALL
            return 0

    def _calculate_trend(self, values: List[float], window: int = 10) -> float:
        """Расчет тренда значений"""
        try:
            if len(values) < window:
                return 0.0

            recent = values[-window:]
            older = values[-window * 2:-window] if len(values) >= window * 2 else values[:window]

            if not older:
                return 0.0

            recent_avg = statistics.mean(recent)
            older_avg = statistics.mean(older)

            if older_avg == 0:
                return 0.0

            return (recent_avg - older_avg) / older_avg

        except Exception as e:
            logger.debug(f"Ошибка расчета тренда: {e}")
            return 0.0

    def subscribe_to_metrics(self, metric_type: str, callback: callable) -> None:
        """
        Подписка на обновления метрик

        Args:
            metric_type: Тип метрики для подписки
            callback: Функция обратного вызова
        """
        with self._lock:
            self._subscribers[metric_type].append(callback)

        logger.debug(f"Добавлена подписка на метрики типа {metric_type}")

    def unsubscribe_from_metrics(self, metric_type: str, callback: callable) -> None:
        """
        Отписка от обновлений метрик

        Args:
            metric_type: Тип метрики
            callback: Функция обратного вызова для удаления
        """
        with self._lock:
            if metric_type in self._subscribers and callback in self._subscribers[metric_type]:
                self._subscribers[metric_type].remove(callback)

        logger.debug(f"Удалена подписка на метрики типа {metric_type}")

    def _get_cached(self, key: str) -> Any:
        """Получение данных из кэша"""
        try:
            with self._lock:
                if key in self._cache and key in self._cache_ttl:
                    if time.time() - self._cache_ttl[key] < 300:  # 5 минут TTL
                        return self._cache[key]
                    else:
                        # Удаление устаревших данных
                        del self._cache[key]
                        del self._cache_ttl[key]
            return None
        except Exception as e:
            logger.debug(f"Ошибка получения из кэша: {e}")
            return None

    def _set_cached(self, key: str, value: Any) -> None:
        """Сохранение данных в кэш"""
        try:
            with self._lock:
                self._cache[key] = value
                self._cache_ttl[key] = time.time()
        except Exception as e:
            logger.debug(f"Ошибка сохранения в кэш: {e}")

    def export_statistics(self, output_path: str, time_range: TimeRange = TimeRange.MONTH) -> bool:
        """
        Экспорт статистики в файл

        Args:
            output_path: Путь для сохранения
            time_range: Временной диапазон

        Returns:
            Успешность операции
        """
        try:
            import csv

            export_data = {
                'export_time': datetime.now().isoformat(),
                'time_range': time_range.value,
                'session_stats': asdict(self.get_session_statistics(time_range)),
                'system_stats': self.get_recent_stats('system', time_range),
                'performance_metrics': self.get_aggregated_metric('system', 'cpu_percent', time_range)
            }

            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Статистика экспортирована: {output_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта статистики: {e}")
            return False

    def generate_report(self, time_range: TimeRange = TimeRange.WEEK) -> Dict[str, Any]:
        """
        Генерация комплексного отчета

        Args:
            time_range: Временной диапазон

        Returns:
            Словарь с отчетом
        """
        try:
            session_stats = self.get_session_statistics(time_range)
            system_stats = self.get_recent_stats('system', time_range)

            report = {
                'generated_at': datetime.now().isoformat(),
                'time_range': time_range.value,
                'summary': {
                    'total_downloaded': format_size(session_stats.total_downloaded),
                    'total_uploaded': format_size(session_stats.total_uploaded),
                    'efficiency_ratio': f"{session_stats.overall_efficiency:.2f}",
                    'average_speed_down': format_speed(session_stats.average_download_speed),
                    'average_speed_up': format_speed(session_stats.average_upload_speed)
                },
                'performance': {
                    'cpu_usage': f"{session_stats.cpu_usage:.1f}%",
                    'memory_usage': f"{session_stats.memory_usage:.1f}%",
                    'active_time': format_duration(int(session_stats.total_torrents * 3600))  # Пример
                },
                'recommendations': self._generate_recommendations(session_stats, system_stats)
            }

            return report

        except Exception as e:
            logger.error(f"Ошибка генерации отчета: {e}")
            return {'error': str(e)}

    def _generate_recommendations(self, session_stats: SessionStatistics,
                                  system_stats: Dict[str, Any]) -> List[str]:
        """Генерация рекомендаций на основе статистики"""
        recommendations = []

        try:
            # Рекомендации по эффективности
            if session_stats.overall_efficiency < 0.5:
                recommendations.append(
                    "Низкий ratio. Рекомендуется увеличить время сидинга."
                )

            # Рекомендации по производительности
            if session_stats.cpu_usage > 80:
                recommendations.append(
                    "Высокая загрузка CPU. Рассмотрите ограничение количества активных торрентов."
                )

            if session_stats.memory_usage > 85:
                recommendations.append(
                    "Высокое использование памяти. Увеличьте размер кэша или ограничьте количество торрентов."
                )

            # Рекомендации по скорости
            if session_stats.average_download_speed < 1024 * 1024:  # 1 MB/s
                recommendations.append(
                    "Низкая скорость загрузки. Проверьте сетевые настройки и лимиты."
                )

            return recommendations

        except Exception as e:
            logger.error(f"Ошибка генерации рекомендаций: {e}")
            return ["Ошибка анализа статистики"]

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы StatisticsEngine...")

        # Остановка сборщика
        self._collection_active = False
        if hasattr(self, '_collection_thread') and self._collection_thread.is_alive():
            self._collection_thread.join(timeout=5)

        # Финализация базы данных
        try:
            if self._db_connection:
                # Коммит оставшихся изменений
                self._db_connection.commit()

                # Создание резервной копии при завершении
                backup_path = self._db_path.with_suffix('.backup.db')
                self._create_backup(backup_path)

                # Закрытие соединения
                self._db_connection.close()

        except Exception as e:
            logger.error(f"Ошибка завершения работы базы данных: {e}")

        # Очистка структур
        with self._lock:
            self._data_points.clear()
            self._aggregated_data.clear()
            self._cache.clear()
            self._cache_ttl.clear()
            self._subscribers.clear()

        logger.info("StatisticsEngine завершен")

    def _create_backup(self, backup_path: Path) -> None:
        """Создание резервной копии базы данных"""
        try:
            import shutil
            shutil.copy2(self._db_path, backup_path)
            logger.info(f"Создана резервная копия базы данных: {backup_path}")
        except Exception as e:
            logger.warning(f"Не удалось создать резервную копию: {e}")