"""
PEER MANAGER - Менеджер пиров и сетевых соединений

Отвечает за управление пирами, сбор статистики сетевой активности,
оптимизацию соединений и блокировку нежелательных пиров.
Обеспечивает мониторинг качества соединений и интеллектуальное управление пирами.
"""

import logging
import time
import ipaddress
from typing import Dict, List, Optional, Any, Set, Tuple
from threading import RLock
from dataclasses import dataclass, asdict
from enum import Enum
from collections import defaultdict, deque

import libtorrent as lt

from ..models.exceptions import TorrentError
from ..utils.validators import validate_ip_address

logger = logging.getLogger(__name__)


class PeerConnectionType(Enum):
    """Типы соединений с пирами"""
    TCP = "tcp"
    UDP = "udp"
    WEB_SEED = "web_seed"
    DHT = "dht"
    LSD = "lsd"


class PeerFlags(Enum):
    """Флаги пиров"""
    INTERESTED = "interested"
    CHOKED = "choked"
    REMOTE_INTERESTED = "remote_interested"
    REMOTE_CHOKED = "remote_choked"
    SUPPORTS_EXTENSIONS = "supports_extensions"
    LOCAL_CONNECTION = "local_connection"
    HANDSHAKE = "handshake"
    CONNECTING = "connecting"
    QUEUED = "queued"
    ON_PAROLE = "on_parole"
    SEED = "seed"
    OPTIMISTIC_UNCHOKE = "optimistic_unchoke"
    RC4_ENCRYPTED = "rc4_encrypted"
    PLAINTEXT_ENCRYPTED = "plaintext_encrypted"


@dataclass
class PeerStats:
    """Статистика пира"""
    ip: str
    port: int
    client: str
    flags: Set[PeerFlags]
    download_speed: int
    upload_speed: int
    progress: float
    total_downloaded: int
    total_uploaded: int
    connection_type: PeerConnectionType
    country: str
    connection_time: float
    last_activity: float
    download_rate_history: List[int]
    upload_rate_history: List[int]
    pieces_done: int
    pieces_total: int
    failed_requests: int
    timeout_requests: int


@dataclass
class PeerQualityMetrics:
    """Метрики качества пира"""
    score: float
    reliability: float
    speed_efficiency: float
    availability: float
    stability: float


class PeerManager:
    """
    Менеджер пиров с расширенной аналитикой и управлением
    """

    def __init__(self, session_manager, config: Dict[str, Any]):
        self.session_manager = session_manager
        self.config = config

        # Потокобезопасные структуры
        self._peer_cache: Dict[str, Dict[str, PeerStats]] = defaultdict(dict)
        self._banned_peers: Set[str] = set()
        self._peer_quality: Dict[str, PeerQualityMetrics] = {}
        self._lock = RLock()

        # Настройки управления пирами
        self._max_peers_per_torrent = config.get('max_peers_per_torrent', 50)
        self._min_peers_for_healthy = config.get('min_peers_for_healthy', 5)
        self._peer_ban_duration = config.get('peer_ban_duration', 3600)  # 1 час

        # История для анализа
        self._peer_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self._connection_attempts: Dict[str, int] = defaultdict(int)

        # Инициализация систем управления
        self._initialize_peer_management()

        logger.info("PeerManager инициализирован")

    def _initialize_peer_management(self) -> None:
        """Инициализация систем управления пирами"""
        try:
            # Загрузка забаненных пиров из конфигурации
            banned_peers = self.config.get('banned_peers', [])
            self._banned_peers.update(banned_peers)

            # Настройка callback для обновления статистики
            self.session_manager.register_alert_handler(
                'stats_alert',
                self._on_stats_update
            )

            logger.info("Системы управления пирами инициализированы")

        except Exception as e:
            logger.error(f"Ошибка инициализации управления пирами: {e}")

    def _on_stats_update(self, alert) -> None:
        """Обработка обновления статистики"""
        try:
            # Периодическое обновление качества пиров
            current_time = time.time()
            if hasattr(self, '_last_quality_update'):
                if current_time - self._last_quality_update > 300:  # 5 минут
                    self._update_peer_quality_metrics()
                    self._last_quality_update = current_time
            else:
                self._last_quality_update = current_time

        except Exception as e:
            logger.error(f"Ошибка обработки обновления статистики: {e}")

    def get_peers_info(self, info_hash: str) -> List[PeerStats]:
        """
        Получение информации о пирах торрента

        Args:
            info_hash: Хеш торрента

        Returns:
            Список статистики пиров
        """
        try:
            session = self.session_manager.session
            if not session:
                return []

            # Получение handles торрентов
            torrent_handle = self._get_torrent_handle(info_hash)
            if not torrent_handle:
                return []

            # Получение информации о пирах из libtorrent
            peer_info_list = torrent_handle.get_peer_info()

            peers_stats = []
            current_time = time.time()

            for peer_info in peer_info_list:
                try:
                    # Пропуск забаненных пиров
                    peer_key = f"{peer_info.ip[0]}:{peer_info.ip[1]}"
                    if peer_key in self._banned_peers:
                        continue

                    # Определение типа соединения
                    connection_type = self._determine_connection_type(peer_info)

                    # Определение флагов
                    flags = self._parse_peer_flags(peer_info)

                    # Расчет прогресса
                    progress = peer_info.progress if hasattr(peer_info, 'progress') else 0.0

                    # Получение истории скоростей
                    download_history = self._get_rate_history(peer_key, 'download')
                    upload_history = self._get_rate_history(peer_key, 'upload')

                    # Определение страны
                    country = self._get_country_from_ip(peer_info.ip[0])

                    # Создание статистики пира
                    peer_stats = PeerStats(
                        ip=peer_info.ip[0],
                        port=peer_info.ip[1],
                        client=peer_info.client,
                        flags=flags,
                        download_speed=peer_info.down_speed,
                        upload_speed=peer_info.up_speed,
                        progress=progress,
                        total_downloaded=peer_info.total_download,
                        total_uploaded=peer_info.total_upload,
                        connection_type=connection_type,
                        country=country,
                        connection_time=current_time - (
                            peer_info.connection_time if hasattr(peer_info, 'connection_time') else 0),
                        last_activity=current_time - (
                            peer_info.last_active if hasattr(peer_info, 'last_active') else 0),
                        download_rate_history=download_history,
                        upload_rate_history=upload_history,
                        pieces_done=peer_info.pieces.length if hasattr(peer_info, 'pieces') else 0,
                        pieces_total=peer_info.pieces.size() if hasattr(peer_info, 'pieces') else 0,
                        failed_requests=peer_info.failcount if hasattr(peer_info, 'failcount') else 0,
                        timeout_requests=peer_info.timeout_requests if hasattr(peer_info, 'timeout_requests') else 0
                    )

                    peers_stats.append(peer_stats)

                    # Обновление кэша
                    with self._lock:
                        self._peer_cache[info_hash][peer_key] = peer_stats

                    # Обновление истории
                    self._update_peer_history(peer_key, peer_stats)

                except Exception as e:
                    logger.warning(f"Ошибка обработки информации о пире: {e}")
                    continue

            return peers_stats

        except Exception as e:
            logger.error(f"Ошибка получения информации о пирах {info_hash}: {e}")
            return []

    def _get_torrent_handle(self, info_hash: str) -> Optional[lt.torrent_handle]:
        """Получение handle торрента по info_hash"""
        try:
            # Этот метод должен быть интегрирован с TorrentManager
            # Временная реализация - получение через сессию
            session = self.session_manager.session
            if not session:
                return None

            # Получение всех handles (это не оптимально, нужно интегрировать с TorrentManager)
            handles = session.get_torrents()
            for handle in handles:
                if str(handle.info_hash()) == info_hash:
                    return handle

            return None

        except Exception as e:
            logger.error(f"Ошибка получения handle торрента {info_hash}: {e}")
            return None

    def _determine_connection_type(self, peer_info) -> PeerConnectionType:
        """Определение типа соединения с пиром"""
        try:
            # Анализ источника пира
            source_flags = peer_info.source_flags if hasattr(peer_info, 'source_flags') else 0

            if source_flags & lt.peer_info.tracker:
                return PeerConnectionType.TCP
            elif source_flags & lt.peer_info.dht:
                return PeerConnectionType.DHT
            elif source_flags & lt.peer_info.pex:
                return PeerConnectionType.TCP
            elif source_flags & lt.peer_info.lsd:
                return PeerConnectionType.LSD
            elif source_flags & lt.peer_info.resume_data:
                return PeerConnectionType.TCP
            else:
                # Анализ по другим признакам
                client = peer_info.client.lower()
                if 'http' in client or 'web' in client:
                    return PeerConnectionType.WEB_SEED
                else:
                    return PeerConnectionType.TCP

        except Exception as e:
            logger.warning(f"Ошибка определения типа соединения: {e}")
            return PeerConnectionType.TCP

    def _parse_peer_flags(self, peer_info) -> Set[PeerFlags]:
        """Парсинг флагов пира"""
        flags = set()

        try:
            # Маппинг флагов libtorrent на наши
            flag_mapping = {
                lt.peer_info.interesting: PeerFlags.INTERESTED,
                lt.peer_info.choked: PeerFlags.CHOKED,
                lt.peer_info.remote_interested: PeerFlags.REMOTE_INTERESTED,
                lt.peer_info.remote_choked: PeerFlags.REMOTE_CHOKED,
                lt.peer_info.supports_extensions: PeerFlags.SUPPORTS_EXTENSIONS,
                lt.peer_info.local_connection: PeerFlags.LOCAL_CONNECTION,
                lt.peer_info.handshake: PeerFlags.HANDSHAKE,
                lt.peer_info.connecting: PeerFlags.CONNECTING,
                lt.peer_info.queued: PeerFlags.QUEUED,
                lt.peer_info.on_parole: PeerFlags.ON_PAROLE,
                lt.peer_info.seed: PeerFlags.SEED,
                lt.peer_info.optimistic_unchoke: PeerFlags.OPTIMISTIC_UNCHOKE,
                lt.peer_info.rc4_encrypted: PeerFlags.RC4_ENCRYPTED,
                lt.peer_info.plaintext_encrypted: PeerFlags.PLAINTEXT_ENCRYPTED
            }

            for lt_flag, our_flag in flag_mapping.items():
                if peer_info.flags & lt_flag:
                    flags.add(our_flag)

        except Exception as e:
            logger.warning(f"Ошибка парсинга флагов пира: {e}")

        return flags

    def _get_country_from_ip(self, ip: str) -> str:
        """Определение страны по IP адресу"""
        try:
            # Базовая реализация - в production можно использовать GeoIP базу
            # Здесь просто возвращаем пустую строку, так как для полноценной
            # реализации требуется внешняя база данных
            return ""

        except Exception as e:
            logger.debug(f"Ошибка определения страны для IP {ip}: {e}")
            return ""

    def _get_rate_history(self, peer_key: str, rate_type: str) -> List[int]:
        """Получение истории скоростей пира"""
        try:
            history_key = f"{peer_key}_{rate_type}"
            return list(self._peer_history[history_key])
        except Exception as e:
            logger.debug(f"Ошибка получения истории скоростей для {peer_key}: {e}")
            return []

    def _update_peer_history(self, peer_key: str, stats: PeerStats) -> None:
        """Обновление истории пира"""
        try:
            # История скорости загрузки
            download_key = f"{peer_key}_download"
            self._peer_history[download_key].append(stats.download_speed)

            # История скорости отдачи
            upload_key = f"{peer_key}_upload"
            self._peer_history[upload_key].append(stats.upload_speed)

            # Общая история соединений
            connection_key = f"{peer_key}_connections"
            self._peer_history[connection_key].append(time.time())

        except Exception as e:
            logger.debug(f"Ошибка обновления истории пира {peer_key}: {e}")

    def ban_peer(self, ip: str, port: int = None, duration: int = None) -> bool:
        """
        Блокировка пира

        Args:
            ip: IP адрес пира
            port: Порт пира (опционально)
            duration: Длительность блокировки в секундах

        Returns:
            Успешность операции
        """
        try:
            if not validate_ip_address(ip):
                raise TorrentError(f"Неверный IP адрес: {ip}")

            ban_duration = duration or self._peer_ban_duration
            peer_key = f"{ip}:{port}" if port else ip

            with self._lock:
                self._banned_peers.add(peer_key)

            # Установка таймера для автоматической разблокировки
            if ban_duration > 0:
                self._schedule_unban(peer_key, ban_duration)

            # Принудительное отключение пира
            self._disconnect_peer(ip, port)

            logger.info(f"Пир заблокирован: {peer_key} на {ban_duration} секунд")
            return True

        except Exception as e:
            logger.error(f"Ошибка блокировки пира {ip}:{port}: {e}")
            return False

    def _schedule_unban(self, peer_key: str, duration: int) -> None:
        """Планирование автоматической разблокировки пира"""
        try:
            import threading

            def unban_peer():
                time.sleep(duration)
                with self._lock:
                    if peer_key in self._banned_peers:
                        self._banned_peers.remove(peer_key)
                        logger.info(f"Пир автоматически разблокирован: {peer_key}")

            thread = threading.Thread(target=unban_peer, daemon=True)
            thread.start()

        except Exception as e:
            logger.error(f"Ошибка планирования разблокировки пира {peer_key}: {e}")

    def _disconnect_peer(self, ip: str, port: int = None) -> None:
        """Принудительное отключение пира"""
        try:
            session = self.session_manager.session
            if not session:
                return

            # Отключение пира через сессию libtorrent
            if port:
                session.disconnect_peer((ip, port))
            else:
                # Если порт не указан, отключаем все соединения с этим IP
                for info_hash in list(self._peer_cache.keys()):
                    torrent_handle = self._get_torrent_handle(info_hash)
                    if torrent_handle:
                        # Получаем информацию о пирах и отключаем совпадающие по IP
                        peer_info_list = torrent_handle.get_peer_info()
                        for peer_info in peer_info_list:
                            if peer_info.ip[0] == ip:
                                session.disconnect_peer(peer_info.ip)

        except Exception as e:
            logger.error(f"Ошибка отключения пира {ip}:{port}: {e}")

    def unban_peer(self, ip: str, port: int = None) -> bool:
        """
        Разблокировка пира

        Args:
            ip: IP адрес пира
            port: Порт пира (опционально)

        Returns:
            Успешность операции
        """
        try:
            peer_key = f"{ip}:{port}" if port else ip

            with self._lock:
                if peer_key in self._banned_peers:
                    self._banned_peers.remove(peer_key)
                    logger.info(f"Пир разблокирован: {peer_key}")
                    return True
                else:
                    logger.warning(f"Пир не найден в списке заблокированных: {peer_key}")
                    return False

        except Exception as e:
            logger.error(f"Ошибка разблокировки пира {ip}:{port}: {e}")
            return False

    def get_banned_peers(self) -> List[str]:
        """Получение списка заблокированных пиров"""
        with self._lock:
            return list(self._banned_peers)

    def clear_banned_peers(self) -> None:
        """Очистка списка заблокированных пиров"""
        with self._lock:
            self._banned_peers.clear()
        logger.info("Список заблокированных пиров очищен")

    def get_peer_quality(self, peer_key: str) -> Optional[PeerQualityMetrics]:
        """
        Получение метрик качества пира

        Args:
            peer_key: Ключ пира (ip:port)

        Returns:
            Метрики качества пира
        """
        try:
            with self._lock:
                if peer_key in self._peer_quality:
                    return self._peer_quality[peer_key]

            # Расчет метрик если они не в кэше
            return self._calculate_peer_quality(peer_key)

        except Exception as e:
            logger.error(f"Ошибка получения метрик качества пира {peer_key}: {e}")
            return None

    def _calculate_peer_quality(self, peer_key: str) -> Optional[PeerQualityMetrics]:
        """Расчет метрик качества пира"""
        try:
            # Сбор данных из истории
            download_history = self._get_rate_history(peer_key, 'download')
            upload_history = self._get_rate_history(peer_key, 'upload')
            connection_history = self._get_rate_history(peer_key, 'connections')

            if not download_history or not upload_history:
                return None

            # Расчет надежности (стабильность скорости)
            avg_download = sum(download_history) / len(download_history)
            std_download = (sum((x - avg_download) ** 2 for x in download_history) / len(download_history)) ** 0.5
            reliability = 1.0 - (std_download / avg_download if avg_download > 0 else 1.0)

            # Расчет эффективности скорости
            max_possible_speed = 10 * 1024 * 1024  # 10 MB/s как максимальная
            speed_efficiency = min(avg_download / max_possible_speed, 1.0)

            # Расчет доступности (частота соединений)
            if len(connection_history) > 1:
                time_range = connection_history[-1] - connection_history[0]
                connection_rate = len(connection_history) / (time_range if time_range > 0 else 1)
                availability = min(connection_rate / 10, 1.0)  # Нормализация
            else:
                availability = 0.5

            # Расчет стабильности (вариативность времени соединений)
            if len(connection_history) > 2:
                intervals = [connection_history[i + 1] - connection_history[i] for i in
                             range(len(connection_history) - 1)]
                avg_interval = sum(intervals) / len(intervals)
                stability = 1.0 - (min(avg_interval, 3600) / 3600)  # Нормализация к часу
            else:
                stability = 0.5

            # Итоговый score (взвешенная сумма)
            score = (
                    reliability * 0.3 +
                    speed_efficiency * 0.4 +
                    availability * 0.15 +
                    stability * 0.15
            )

            metrics = PeerQualityMetrics(
                score=score,
                reliability=reliability,
                speed_efficiency=speed_efficiency,
                availability=availability,
                stability=stability
            )

            # Сохранение в кэш
            with self._lock:
                self._peer_quality[peer_key] = metrics

            return metrics

        except Exception as e:
            logger.error(f"Ошибка расчета метрик качества пира {peer_key}: {e}")
            return None

    def _update_peer_quality_metrics(self) -> None:
        """Периодическое обновление метрик качества всех пиров"""
        try:
            with self._lock:
                peer_keys = list(self._peer_quality.keys())

            for peer_key in peer_keys:
                self._calculate_peer_quality(peer_key)

            logger.debug("Метрики качества пиров обновлены")

        except Exception as e:
            logger.error(f"Ошибка обновления метрик качества пиров: {e}")

    def get_top_peers(self, info_hash: str, limit: int = 10) -> List[Tuple[str, PeerQualityMetrics]]:
        """
        Получение лучших пиров по качеству

        Args:
            info_hash: Хеш торрента
            limit: Максимальное количество

        Returns:
            Список лучших пиров с метриками
        """
        try:
            peers_info = self.get_peers_info(info_hash)
            peer_metrics = []

            for peer in peers_info:
                peer_key = f"{peer.ip}:{peer.port}"
                metrics = self.get_peer_quality(peer_key)
                if metrics:
                    peer_metrics.append((peer_key, metrics))

            # Сортировка по score
            peer_metrics.sort(key=lambda x: x[1].score, reverse=True)

            return peer_metrics[:limit]

        except Exception as e:
            logger.error(f"Ошибка получения лучших пиров для {info_hash}: {e}")
            return []

    def optimize_peer_connections(self, info_hash: str) -> None:
        """
        Оптимизация соединений с пирами для торрента

        Args:
            info_hash: Хеш торрента
        """
        try:
            # Получение текущих пиров
            current_peers = self.get_peers_info(info_hash)
            if len(current_peers) <= self._min_peers_for_healthy:
                return

            # Получение лучших пиров
            top_peers = self.get_top_peers(info_hash, self._max_peers_per_torrent)
            top_peer_keys = set(peer[0] for peer in top_peers)

            # Отключение худших пиров
            disconnected_count = 0
            for peer in current_peers:
                peer_key = f"{peer.ip}:{peer.port}"
                if peer_key not in top_peer_keys:
                    self._disconnect_peer(peer.ip, peer.port)
                    disconnected_count += 1

            if disconnected_count > 0:
                logger.info(f"Оптимизированы соединения для {info_hash}: отключено {disconnected_count} пиров")

        except Exception as e:
            logger.error(f"Ошибка оптимизации соединений для {info_hash}: {e}")

    def get_network_statistics(self) -> Dict[str, Any]:
        """Получение общей сетевой статистики"""
        try:
            total_download_speed = 0
            total_upload_speed = 0
            total_peers = 0
            healthy_torrents = 0

            with self._lock:
                for info_hash, peers in self._peer_cache.items():
                    total_peers += len(peers)

                    for peer in peers.values():
                        total_download_speed += peer.download_speed
                        total_upload_speed += peer.upload_speed

                    # Торрент считается здоровым если имеет достаточно пиров
                    if len(peers) >= self._min_peers_for_healthy:
                        healthy_torrents += 1

            return {
                'total_download_speed': total_download_speed,
                'total_upload_speed': total_upload_speed,
                'total_peers': total_peers,
                'healthy_torrents': healthy_torrents,
                'banned_peers_count': len(self._banned_peers),
                'average_peer_quality': self._get_average_peer_quality()
            }

        except Exception as e:
            logger.error(f"Ошибка получения сетевой статистики: {e}")
            return {}

    def _get_average_peer_quality(self) -> float:
        """Получение среднего качества пиров"""
        try:
            with self._lock:
                if not self._peer_quality:
                    return 0.0

                total_score = sum(metrics.score for metrics in self._peer_quality.values())
                return total_score / len(self._peer_quality)

        except Exception as e:
            logger.error(f"Ошибка расчета среднего качества пиров: {e}")
            return 0.0

    def export_peer_data(self, output_path: str) -> bool:
        """
        Экспорт данных о пирах

        Args:
            output_path: Путь для сохранения

        Returns:
            Успешность операции
        """
        try:
            import json
            from datetime import datetime

            export_data = {
                'export_time': datetime.now().isoformat(),
                'banned_peers': list(self._banned_peers),
                'peer_quality': {
                    peer: asdict(metrics)
                    for peer, metrics in self._peer_quality.items()
                },
                'network_statistics': self.get_network_statistics()
            }

            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Данные о пирах экспортированы: {output_path}")
            return True

        except Exception as e:
            logger.error(f"Ошибка экспорта данных о пирах: {e}")
            return False

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы PeerManager...")

        # Отмена регистрации обработчиков
        self.session_manager.unregister_alert_handler('stats_alert', self._on_stats_update)

        # Экспорт данных при завершении
        try:
            export_path = f"peer_data_export_{int(time.time())}.json"
            self.export_peer_data(export_path)
        except Exception as e:
            logger.warning(f"Не удалось экспортировать данные о пирах: {e}")

        # Очистка структур
        with self._lock:
            self._peer_cache.clear()
            self._banned_peers.clear()
            self._peer_quality.clear()
            self._peer_history.clear()
            self._connection_attempts.clear()

        logger.info("PeerManager завершен")