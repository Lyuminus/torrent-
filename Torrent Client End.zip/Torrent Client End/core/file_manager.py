"""
FILE MANAGER - Менеджер файлов и путей

Отвечает за безопасные операции с файловой системой, управление путями,
работу с файлами торрентов, создание торрент-файлов и проверку целостности.
Обеспечивает безопасность и валидацию всех файловых операций.
"""

import os
import hashlib
import logging
import shutil
from typing import List, Dict, Any, Optional, Union, Tuple
from pathlib import Path
from threading import RLock
from dataclasses import dataclass
from enum import Enum

import libtorrent as lt

from ..models.exceptions import SecurityError, TorrentError
from ..utils.validators import validate_path, safe_path_join

logger = logging.getLogger(__name__)


class FileOperation(Enum):
    """Типы файловых операций"""
    CREATE = "create"
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    MOVE = "move"
    COPY = "copy"


@dataclass
class FileInfo:
    """Информация о файле"""
    path: str
    size: int
    modified_time: float
    is_directory: bool
    permissions: int
    checksum: str = ""


@dataclass
class DiskSpaceInfo:
    """Информация о свободном месте на диске"""
    total: int
    free: int
    used: int
    percentage: float


class FileManager:
    """
    Менеджер файлов с расширенным функционалом безопасности
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.base_download_path = self.config.get('downloads_path', str(Path.home() / "Downloads"))
        self.base_torrents_path = self.config.get('torrents_path', str(Path.home() / "Torrents"))

        # Потокобезопасные структуры
        self._lock = RLock()
        self._file_locks: Dict[str, RLock] = {}

        # Кэш информации о файлах
        self._file_cache: Dict[str, FileInfo] = {}

        # Создание базовых директорий
        self._ensure_directories()

        logger.info("FileManager инициализирован")

    def _ensure_directories(self) -> None:
        """Создание необходимых директорий"""
        try:
            directories = [
                self.base_download_path,
                self.base_torrents_path,
                self.config.get('temp_path', str(Path(self.base_download_path) / "temp")),
                self.config.get('incomplete_path', str(Path(self.base_download_path) / "incomplete"))
            ]

            for directory in directories:
                safe_path = safe_path_join(directory)
                safe_path.mkdir(parents=True, exist_ok=True)
                logger.debug(f"Директория обеспечена: {safe_path}")

        except Exception as e:
            logger.error(f"Ошибка создания директорий: {e}")
            raise SecurityError(f"Не удалось создать необходимые директории: {e}")

    def get_file_lock(self, file_path: str) -> RLock:
        """Получение блокировки для файла (для потокобезопасности)"""
        with self._lock:
            if file_path not in self._file_locks:
                self._file_locks[file_path] = RLock()
            return self._file_locks[file_path]

    def safe_file_operation(self, operation: FileOperation, file_path: str,
                            callback: callable, *args, **kwargs) -> Any:
        """
        Безопасное выполнение файловой операции

        Args:
            operation: Тип операции
            file_path: Путь к файлу
            callback: Функция для выполнения
            *args, **kwargs: Аргументы для callback

        Returns:
            Результат выполнения callback
        """
        safe_path = safe_path_join(file_path)
        file_lock = self.get_file_lock(str(safe_path))

        with file_lock:
            try:
                # Валидация пути перед операцией
                if operation in [FileOperation.READ, FileOperation.WRITE, FileOperation.DELETE]:
                    if not safe_path.exists():
                        raise SecurityError(f"Файл не существует: {safe_path}")

                # Проверка прав доступа
                self._check_file_permissions(operation, safe_path)

                # Выполнение операции
                result = callback(safe_path, *args, **kwargs)

                # Обновление кэша
                self._update_file_cache(safe_path)

                logger.debug(f"Файловая операция {operation.value} выполнена: {safe_path}")
                return result

            except Exception as e:
                logger.error(f"Ошибка файловой операции {operation.value} для {safe_path}: {e}")
                raise

    def _check_file_permissions(self, operation: FileOperation, path: Path) -> None:
        """Проверка прав доступа для операции"""
        try:
            if operation == FileOperation.READ:
                if not os.access(path, os.R_OK):
                    raise SecurityError(f"Нет прав на чтение: {path}")
            elif operation == FileOperation.WRITE:
                if not os.access(path, os.W_OK):
                    raise SecurityError(f"Нет прав на запись: {path}")
            elif operation == FileOperation.CREATE:
                parent_dir = path.parent
                if not os.access(parent_dir, os.W_OK):
                    raise SecurityError(f"Нет прав на создание в директории: {parent_dir}")
            elif operation == FileOperation.DELETE:
                if not os.access(path, os.W_OK):
                    raise SecurityError(f"Нет прав на удаление: {path}")

        except Exception as e:
            raise SecurityError(f"Ошибка проверки прав доступа: {e}")

    def _update_file_cache(self, path: Path) -> None:
        """Обновление кэша информации о файле"""
        try:
            if path.exists():
                stat = path.stat()
                checksum = self._calculate_checksum(path) if path.is_file() else ""

                self._file_cache[str(path)] = FileInfo(
                    path=str(path),
                    size=stat.st_size,
                    modified_time=stat.st_mtime,
                    is_directory=path.is_dir(),
                    permissions=stat.st_mode,
                    checksum=checksum
                )
            else:
                # Удаление из кэша если файл удален
                if str(path) in self._file_cache:
                    del self._file_cache[str(path)]

        except Exception as e:
            logger.warning(f"Ошибка обновления кэша для {path}: {e}")

    def _calculate_checksum(self, file_path: Path, chunk_size: int = 8192) -> str:
        """Вычисление контрольной суммы файла"""
        try:
            hasher = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(chunk_size), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception as e:
            logger.warning(f"Ошибка вычисления контрольной суммы для {file_path}: {e}")
            return ""

    def get_file_info(self, file_path: str) -> Optional[FileInfo]:
        """Получение информации о файле"""
        try:
            safe_path = safe_path_join(file_path)

            # Проверка кэша
            cache_key = str(safe_path)
            if cache_key in self._file_cache:
                cached_info = self._file_cache[cache_key]
                # Проверка актуальности кэша
                if safe_path.exists():
                    current_mtime = safe_path.stat().st_mtime
                    if current_mtime == cached_info.modified_time:
                        return cached_info

            # Получение свежей информации
            return self.safe_file_operation(
                FileOperation.READ, file_path,
                lambda path: self._get_file_info_impl(path)
            )

        except Exception as e:
            logger.error(f"Ошибка получения информации о файле {file_path}: {e}")
            return None

    def _get_file_info_impl(self, path: Path) -> FileInfo:
        """Реализация получения информации о файле"""
        stat = path.stat()
        checksum = self._calculate_checksum(path) if path.is_file() else ""

        info = FileInfo(
            path=str(path),
            size=stat.st_size,
            modified_time=stat.st_mtime,
            is_directory=path.is_dir(),
            permissions=stat.st_mode,
            checksum=checksum
        )

        # Сохранение в кэш
        self._file_cache[str(path)] = info

        return info

    def list_directory(self, directory_path: str, recursive: bool = False) -> List[FileInfo]:
        """Список файлов в директории"""
        try:
            safe_dir = safe_path_join(directory_path)

            if not safe_dir.is_dir():
                raise SecurityError(f"Путь не является директорией: {safe_dir}")

            def list_callback(path):
                file_list = []

                if recursive:
                    for item in path.rglob('*'):
                        if item.is_file() or item.is_dir():
                            file_list.append(self._get_file_info_impl(item))
                else:
                    for item in path.iterdir():
                        if item.is_file() or item.is_dir():
                            file_list.append(self._get_file_info_impl(item))

                return file_list

            return self.safe_file_operation(
                FileOperation.READ, directory_path, list_callback
            )

        except Exception as e:
            logger.error(f"Ошибка получения списка директории {directory_path}: {e}")
            return []

    def create_directory(self, directory_path: str, parents: bool = True) -> bool:
        """Создание директории"""
        try:
            def create_callback(path):
                path.mkdir(parents=parents, exist_ok=True)
                return True

            return self.safe_file_operation(
                FileOperation.CREATE, directory_path, create_callback
            )

        except Exception as e:
            logger.error(f"Ошибка создания директории {directory_path}: {e}")
            return False

    def delete_file(self, file_path: str) -> bool:
        """Удаление файла или директории"""
        try:
            def delete_callback(path):
                if path.is_file():
                    path.unlink()
                elif path.is_dir():
                    shutil.rmtree(path)
                return True

            return self.safe_file_operation(
                FileOperation.DELETE, file_path, delete_callback
            )

        except Exception as e:
            logger.error(f"Ошибка удаления {file_path}: {e}")
            return False

    def move_file(self, source_path: str, destination_path: str) -> bool:
        """Перемещение файла или директории"""
        try:
            safe_source = safe_path_join(source_path)
            safe_dest = safe_path_join(destination_path)

            def move_callback(path):
                shutil.move(str(safe_source), str(safe_dest))
                return True

            # Используем source_path для блокировки
            return self.safe_file_operation(
                FileOperation.MOVE, source_path, move_callback
            )

        except Exception as e:
            logger.error(f"Ошибка перемещения {source_path} -> {destination_path}: {e}")
            return False

    def copy_file(self, source_path: str, destination_path: str) -> bool:
        """Копирование файла или директории"""
        try:
            safe_source = safe_path_join(source_path)
            safe_dest = safe_path_join(destination_path)

            def copy_callback(path):
                if safe_source.is_file():
                    shutil.copy2(str(safe_source), str(safe_dest))
                elif safe_source.is_dir():
                    shutil.copytree(str(safe_source), str(safe_dest))
                return True

            return self.safe_file_operation(
                FileOperation.COPY, source_path, copy_callback
            )

        except Exception as e:
            logger.error(f"Ошибка копирования {source_path} -> {destination_path}: {e}")
            return False

    def calculate_directory_size(self, directory_path: str) -> int:
        """Вычисление размера директории"""
        try:
            safe_dir = safe_path_join(directory_path)

            if not safe_dir.is_dir():
                raise SecurityError(f"Путь не является директорией: {safe_dir}")

            def size_callback(path):
                total_size = 0
                for file_path in path.rglob('*'):
                    if file_path.is_file():
                        total_size += file_path.stat().st_size
                return total_size

            return self.safe_file_operation(
                FileOperation.READ, directory_path, size_callback
            )

        except Exception as e:
            logger.error(f"Ошибка вычисления размера директории {directory_path}: {e}")
            return 0

    def get_disk_space(self, path: str = None) -> DiskSpaceInfo:
        """Получение информации о свободном месте на диске"""
        try:
            check_path = path or self.base_download_path
            safe_path = safe_path_join(check_path)

            # Получение статистики диска
            total, used, free = shutil.disk_usage(str(safe_path))
            percentage = (used / total) * 100 if total > 0 else 0

            return DiskSpaceInfo(
                total=total,
                free=free,
                used=used,
                percentage=percentage
            )

        except Exception as e:
            logger.error(f"Ошибка получения информации о диске для {path}: {e}")
            return DiskSpaceInfo(0, 0, 0, 0.0)

    def has_sufficient_space(self, required_size: int, path: str = None) -> bool:
        """Проверка наличия достаточного свободного места"""
        try:
            disk_info = self.get_disk_space(path)
            return disk_info.free >= required_size

        except Exception as e:
            logger.error(f"Ошибка проверки свободного места: {e}")
            return False

    def create_torrent_file(self, source_path: str, trackers: List[str],
                            output_path: str = None, comment: str = None,
                            is_private: bool = False, web_seeds: List[str] = None,
                            piece_size: int = 0) -> str:
        """
        Создание торрент-файла

        Args:
            source_path: Путь к файлу или директории
            trackers: Список трекеров
            output_path: Путь для сохранения торрента
            comment: Комментарий к торренту
            is_private: Приватный торрент
            web_seeds: Web seeds URLs
            piece_size: Размер куска (0 = автоматический)

        Returns:
            Путь к созданному торрент-файлу
        """
        try:
            safe_source = safe_path_join(source_path)

            if not safe_source.exists():
                raise TorrentError(f"Исходный путь не существует: {safe_source}")

            # Генерация имени выходного файла
            if not output_path:
                torrent_name = f"{safe_source.name}.torrent"
                output_path = str(Path(self.base_torrents_path) / torrent_name)

            safe_output = safe_path_join(output_path)

            # Создание директории если нужно
            safe_output.parent.mkdir(parents=True, exist_ok=True)

            def create_torrent_callback(path):
                # Создание file_storage
                fs = lt.file_storage()
                lt.add_files(fs, str(safe_source))

                # Создание торрента
                creator = lt.create_torrent(fs, piece_size=piece_size)

                # Добавление трекеров
                for tracker in trackers:
                    creator.add_tracker(tracker)

                # Добавление web seeds
                if web_seeds:
                    for seed in web_seeds:
                        creator.add_url_seed(seed)

                # Установка метаданных
                creator.set_creator("Torrent Client 8.0")
                creator.set_priv(is_private)

                if comment:
                    creator.set_comment(comment)

                # Генерация хешей
                lt.set_piece_hashes(creator, str(safe_source.parent))

                # Создание и сохранение торрента
                torrent = creator.generate()

                with open(safe_output, 'wb') as f:
                    f.write(lt.bencode(torrent))

                return str(safe_output)

            result_path = self.safe_file_operation(
                FileOperation.CREATE, output_path, create_torrent_callback
            )

            logger.info(f"Торрент-файл создан: {result_path}")
            return result_path

        except Exception as e:
            logger.error(f"Ошибка создания торрент-файла: {e}")
            raise TorrentError(f"Не удалось создать торрент-файл: {e}")

    def inspect_torrent_file(self, torrent_path: str) -> Dict[str, Any]:
        """
        Анализ торрент-файла

        Args:
            torrent_path: Путь к торрент-файлу

        Returns:
            Информация о торренте
        """
        try:
            safe_torrent = safe_path_join(torrent_path)

            def inspect_callback(path):
                if not path.exists():
                    raise TorrentError(f"Торрент-файл не существует: {path}")

                # Загрузка и анализ торрент-файла
                info = lt.torrent_info(str(path))
                files = info.files()

                result = {
                    'name': info.name(),
                    'total_size': info.total_size(),
                    'num_files': info.num_files(),
                    'piece_length': info.piece_length(),
                    'num_pieces': info.num_pieces(),
                    'info_hash': str(info.info_hash()),
                    'creator': info.creator() or 'Не указан',
                    'comment': info.comment() or 'Отсутствует',
                    'is_private': info.priv(),
                    'trackers': [],
                    'files': []
                }

                # Трекеры
                for tracker in info.trackers():
                    result['trackers'].append(tracker.url)

                # Файлы
                for i in range(files.num_files()):
                    file_entry = files.at(i)
                    result['files'].append({
                        'path': str(file_entry.path),
                        'size': file_entry.size,
                        'offset': file_entry.offset,
                        'progress': 0.0
                    })

                return result

            return self.safe_file_operation(
                FileOperation.READ, torrent_path, inspect_callback
            )

        except Exception as e:
            logger.error(f"Ошибка анализа торрент-файла {torrent_path}: {e}")
            raise TorrentError(f"Не удалось проанализировать торрент-файл: {e}")

    def verify_file_integrity(self, file_path: str, expected_checksum: str) -> bool:
        """Проверка целостности файла по контрольной сумме"""
        try:
            safe_file = safe_path_join(file_path)

            def verify_callback(path):
                actual_checksum = self._calculate_checksum(path)
                return actual_checksum == expected_checksum

            return self.safe_file_operation(
                FileOperation.READ, file_path, verify_callback
            )

        except Exception as e:
            logger.error(f"Ошибка проверки целостности файла {file_path}: {e}")
            return False

    def cleanup_temp_files(self, older_than_hours: int = 24) -> int:
        """Очистка временных файлов"""
        try:
            temp_path = Path(self.config.get('temp_path', str(Path(self.base_download_path) / "temp")))
            deleted_count = 0

            if temp_path.exists():
                current_time = time.time()
                cutoff_time = current_time - (older_than_hours * 3600)

                for temp_file in temp_path.rglob('*'):
                    if temp_file.is_file():
                        file_mtime = temp_file.stat().st_mtime
                        if file_mtime < cutoff_time:
                            try:
                                temp_file.unlink()
                                deleted_count += 1
                            except Exception as e:
                                logger.warning(f"Не удалось удалить временный файл {temp_file}: {e}")

            logger.info(f"Очищено временных файлов: {deleted_count}")
            return deleted_count

        except Exception as e:
            logger.error(f"Ошибка очистки временных файлов: {e}")
            return 0

    def get_download_category_path(self, category: str) -> str:
        """Получение пути для категории загрузок"""
        try:
            categories = self.config.get('categories', {})
            if category in categories:
                category_folder = categories[category].get('folder', '')
                if category_folder:
                    category_path = Path(self.base_download_path) / category_folder
                    safe_path_join(str(category_path))  # Валидация
                    return str(category_path)

            return self.base_download_path

        except Exception as e:
            logger.error(f"Ошибка получения пути категории {category}: {e}")
            return self.base_download_path

    def shutdown(self) -> None:
        """Корректное завершение работы"""
        logger.info("Завершение работы FileManager...")

        # Очистка временных файлов
        self.cleanup_temp_files()

        # Очистка кэша
        with self._lock:
            self._file_cache.clear()
            self._file_locks.clear()

        logger.info("FileManager завершен")